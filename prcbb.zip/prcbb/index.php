<!DOCTYPE html>
<html>
    <head>
        <link href="./css/LoginPage.css" rel="stylesheet" type="text/css"/>
        <link rel="icon" type="image/png" href="./img/PRClogo.png">
        <title>Philippine Red Cross</title>

    </head>
    
<body>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img class="img1" src="./img/logoprc.png" alt="notfound"/>
<center>
    <form action="./php/checklogin.php" method="post">
    <div class="tb1">
        <img class="img" src="./img/bloodd.png" alt="notfound"/>
        <h1 class="h1">Blood Bank</h1>
        <h1 class="h1">Management Information System</h1>
        &nbsp;&nbsp;&nbsp; Username &nbsp;
        <input class="urmfld" type="text" name="username" placeholder="&nbsp;Enter Username"/>
        <br><br>
        &nbsp;&nbsp;&nbsp; Password &nbsp;
        <input class="pwdfld" type="password" name="password" placeholder="&nbsp;**********"/>
        <br>
        <br>
          <input class="btn" type="submit" name="login" value="Login"/>   
            <br>
        
    </div>
    


</form>
</center>
</body>
    
</html>
