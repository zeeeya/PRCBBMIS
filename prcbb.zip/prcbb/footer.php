<footer class="text-center">
  <p>&copy; 2016-2017 Information System | <a href="http://www.uno-r.edu.ph/academics/departments/information-technology/">College of Information Technology</a> | <a href="http://www.uno-r.edu.ph/">University of Negros Occidental-Recoletos</a></p> 
</footer>