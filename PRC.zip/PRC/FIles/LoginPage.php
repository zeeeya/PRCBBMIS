<?php
include 'LoginPage.html';
error_reporting(E_ALL ^ E_DEPRECATED);

$con = mysql_connect("localhost", "root", "") or die ("not connected");
mysql_select_db("PRCBBMIS") or die ("no db found");

if(filter_input(INPUT_POST, "Login")){
    $username = (filter_input(INPUT_POST, "username"));
    $password = (filter_input(INPUT_POST, "password"));
    
    $query = "insert into user (username, password) values ('$username', '$password')";
}
?>