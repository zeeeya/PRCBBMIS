<html>
    <head>
        <title>
            Philippine Red Cross Blood Bank Management Information System
        </title>
    </head>
    <body>
        <form action="connection.php" >
        <table>
            <td style="text-align: center">
        <a href="LoginPage.php">
        <img src="../IMG/PRClogo.png" alt="not found"/></a>            
            </td>
        </table>
        </form>
    </body>
</html>

<?php

include 'connection.php';
error_reporting(E_ALL ^ E_DEPRECATED);

$con = mysql_connect("localhost", "root", "") or die ("not connected");
mysql_select_db("PRCBBMIS") or die ("no db found");
 
if($con){
    echo 'established';
 }else{
     echo 'error';
 }