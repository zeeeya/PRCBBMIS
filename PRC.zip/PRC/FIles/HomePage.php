<?php
include 'HomePage.html';
error_reporting(E_ALL ^ E_DEPRECATED);

$con = mysql_connect("localhost", "root", "") or die ("not connected");
mysql_select_db("PRCBBMIS") or die ("no db found");

if(filter_input(INPUT_POST, "bb")){
    include 'BloodBank.html';
}
?>