<?php 
include('php/login_success.php'); 
include('php/links.php');

				$id = $_GET['q'];
				
				include('database.php');
				
				//Getting the REGISTRATION ID from SCHEDULE Table
				$pdo = Database::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "SELECT * FROM schedule WHERE schedid = ?";
				$q = $pdo->prepare($sql);
				$q->execute(array($id));
				$data = $q->fetch(PDO::FETCH_ASSOC);
				$registrationID = $data['regid'];
				//echo $registrationID;
				
				//Getting the data from Participants Table
				Database::disconnect();
				$pdo = Database::connect();
				$sql = 'SELECT * FROM participants WHERE schedid = '. $id;
				
				$PART_ARR = $pdo->query($sql); 
				
				if( $PART_ARR -> rowCount() < 1 ){
					echo '<div class="alert alert-warning" role="alert">Currently this schedule has no participants, you can add participants by clicking the "Add Participant(s)" button.</div>';
				}else{
					echo '<div class="table-responsive">
						<table class="table table-hover">
						
						<thead>
							<tr>
								<th>Name of Participant(s)</th>
								<th class="text-center">Number of Participant(s)</th>
								<th>Action</th>
							</tr>
						</thead>
						
						<tbody>';
					foreach ($PART_ARR as $row) {
						echo '<tr>';
						echo '<td>'. $row['partname'] . '</td>';
						echo '<td class="text-center">'. $row['partnum'] . '</td>';
						
						$vars = array('id' => $row['partid'], 'regid' => $registrationID);
						$querystring = http_build_query($vars);
						//$url = "http://localhost/main.php?" . $querystring;
						echo '<td>
								<a class="btn btn-warning btn-md" href="update_participants.php?'.$querystring.'" data-toggle="tooltip" title="Update"><span class="glyphicon glyphicon-pencil"></span></a>
								<a class="btn btn-danger btn-md" href="delete_participants.php?'.$querystring.'" data-toggle="tooltip" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>
							 </td>';
						echo '</tr>';
					}

					echo	'<script>
								$(document).ready(function(){
									$("[data-toggle="tooltip"]").tooltip();
									$("btn").tooltip();
									});
							</script>


						</tbody>
					</table>
					</div>';					
				}

				Database::disconnect();
			?>
