<?php 
include('php/login_success.php'); 
include('php/links.php');
include('database.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/leaflet.markercluster.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css' rel='stylesheet' />
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css' rel='stylesheet' />

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
		<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
		<style>
			#map 
			{ 	margin:3% 3%;
				width:95%; 
				height:70%; 
			}
		</style>


	 </head>
	<body>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		<!-- <div style="margin-left:350px" id='map'></div> -->
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredmangrove.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			</div>

		</div>
		
		<div class="col-md-9">
			<br />
			<div class="panel panel-primary">
			  <div class="panel-heading">
				<h3 class="panel-title">Monitor Withered Trees</h3>
			  </div>
			  <div class="panel-body">
					<form class="form-horizontal" role="form" action="php/witheredsave.php" method="POST">
					  <div class="form-group">
						<label class="control-label col-sm-3" for="date">Date:</label>
						<div class="col-sm-9">
						  <input type="date" class="form-control" id="date" name="date" placeholder="Enter Date" required="required">
						</div>
					  </div>
					  
						<!-- Activity Code -->
						<div class="form-group row">
							<div class="col-xs-3 text-right"><label for="patch">Patch No.:</label></div>
							<div class="col-xs-9">
								<select class="form-control" required="required" id="patch" name="patch" required="required">
									<option value="Patch001" selected >Patch001</option>';
									<option value="Patch002"  >Patch002</option>';
									<option value="Patch003"  >Patch003</option>';
									<option value="Patch004"  >Patch004</option>';
									<option value="Patch005"  >Patch005</option>';
									<option value="Patch006"  >Patch006</option>';
									<option value="Patch007"  >Patch007</option>';
									<option value="Patch008"  >Patch008</option>';
									<option value="Patch009"  >Patch009</option>';
									<option value="Patch010"  >Patch010</option>';
									<option value="Patch011"  >Patch011</option>';
									<option value="Patch012"  >Patch012</option>';
									<option value="Patch013"  >Patch013</option>';
									<option value="Patch014"  >Patch014</option>';
									<option value="Patch015"  >Patch015</option>';
									<option value="Patch016"  >Patch016</option>';
									<option value="Patch017"  >Patch017</option>';
									<option value="Patch018"  >Patch018</option>';
									<option value="Patch019"  >Patch019</option>';
									<option value="Patch020"  >Patch020</option>';
									<option value="Patch021"  >Patch021</option>';
									<option value="Patch022"  >Patch022</option>';
									<option value="Patch023"  >Patch023</option>';
									<option value="Patch024"  >Patch024</option>';
									<option value="Patch025"  >Patch025</option>';
									<option value="Patch026"  >Patch026</option>';
									<option value="Patch027"  >Patch027</option>';
									<option value="Patch028"  >Patch028</option>';
									<option value="Patch029"  >Patch029</option>';
									<option value="Patch030"  >Patch030</option>';
									<option value="Patch031"  >Patch031</option>';
									<option value="Patch032"  >Patch032</option>';
								</select>
							</div>
						</div>

						<div class="form-group">
							<label class="control-label col-sm-3" for="number">No. of Withered Trees:</label>
							<div class="col-sm-9">
							<input type="text" class="form-control" id="number" name="number" placeholder="No. of Withered trees" required="required">
							</div>
						</div>
						
						<div class="form-group">
							<label class="control-label col-sm-3" for="cause">Cause of death</label>
							<div class="col-sm-9">
							<input type="text" class="form-control" id="cause" name="cause" placeholder="Cause of death" required="required">
							</div>
						</div>						
						
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-9">
								<button type="submit" class="btn btn-info">Submit</button>
							</div>
						</div>
					</form>			  
				</div>
			</div>
		</div>
	</div>
<?php
include('footer.php'); 
?>

</body>
</html>