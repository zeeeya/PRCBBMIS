<script>

</script>
<div class="modal fade" tabindex="-1" role="dialog" id="updateScheduleModal" aria-labelledby="updateScheduleLabel">

	<div class="modal-dialog" role="document" style="margin-top:10%;">
		<div class="modal-content">
			
			<div class="modal-header btn-success">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Update Schedule</h4>
			</div><!-- /.modal-header -->

			<form class="form-horizontal" role="form" action='./php/scheduleUpdate.php?id=<?php echo $_GET['id'] ?>' method="POST">			
			
			<div class="modal-body content">
				<!-- This is where the javascript will place the query data in scheduleUpdateModal.php-->
				<div id="updateDisplayContent" class="row" style="margin:0 5%;"></div>
			
			</div><!-- /.modal-body -->

			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-success">Update Schedule</button>
			</div><!-- /.modal-footer -->
			
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script id="source" language="javascript" type="text/javascript">
$(document).ready(function(){
	
	$("#updateB").click(function(){
		var id = $("#schedule").val();
        
		$.ajax({
			type:"post",
			url:"php/scheduleUpdateModal.php",
			data:"id="+id,
			success:function(data){
				$("#updateDisplayContent").html(data);
			}
		});
	});
});
</script>

<!-- Load jQuery and bootstrap datepicker scripts-->
<link type="text/css" href="css/bootstrap-timepicker.min.css" />
<script src="js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript">
					
// When the document is ready
$(document).ready(function () {
						
	$('#inputTimeStart').timepicker({
		template: false,
		showInputs: false,
		minuteStep: 1
	});
	$('#inputTimeEnd').timepicker({
		template: false,
		showInputs: false,
		minuteStep: 1
	}); 										
			
});
</script>

