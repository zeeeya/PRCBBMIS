<!DOCTYPE html>
<html>
<head>
<meta charset=utf-8 />
<title>Tree Planting Map</title>
<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
<style>
  body { margin:0; padding:0; }
  #map { position:absolute; top:0; bottom:0; width:100%; }
</style>
</head>
<body>
<div id='map'></div>

<script>
L.mapbox.accessToken = 'pk.eyJ1Ijoiam95bWVyaWxsIiwiYSI6ImNpaWgwcW5ndTAycTR2dG0xZnlocHppbG4ifQ.XIsgAOt_JunkNd-8HmZ6-Q';


var map = L.mapbox.map('map', 'joymerill.oi91ibj8')
  .setView([10.66, 123.148], 17);

L.geoJson(geojson, { style: L.mapbox.simplestyle.style }).addTo(map);
</script>
</body>
</html>