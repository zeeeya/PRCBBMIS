
<!DOCTYPE html>
<html>
<head>
	<title>Leaflet Quick Start Guide Example</title>
	<meta charset="utf-8" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="leaflet.css" />
</head>
<body>
	<div id="map" style="width: 600px; height: 400px"></div>

	<script src="leaflet.js"></script>
	<script>

		var map = L.map('map').setView([10.67, 123.162], 14);

		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1Ijoiam95bWVyaWxsIiwiYSI6ImNpaWgwcW5ndTAycTR2dG0xZnlocHppbG4ifQ.XIsgAOt_JunkNd-8HmZ6-Q', {
			maxZoom: 18,
			attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
				'<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
				'Imagery © <a href="http://mapbox.com">Mapbox</a>',
			id: 'mapbox.streets'
		}).addTo(map);


		L.marker([51.51328, -0.08901]).addTo(map)
			.bindPopup("<b>Hello world!</b><br />I am a popup.").openPopup();

		L.circle([51.508, -0.11], 500, {
			color: 'red',
			fillColor: '#f03',
			fillOpacity: 0.5
		}).addTo(map).bindPopup("I am a circle.");

		L.polygon([
			[51.509, -0.08],
			[51.503, -0.06],
			[51.51, -0.047],
			[51.515, -0.048]
		]).addTo(map).bindPopup("I am a polygon.<br><br><a href='#'>Settings</a>");


		var popup = L.popup();

		function onMapClick(e) {
			popup
				.setLatLng(e.latlng)
				.setContent("You clicked the map at " + e.latlng.toString() + "<br><br> <a href='#'>Add Pin Here</a>")
				.openOn(map);
		}

		map.on('click', onMapClick);

	</script>
</body>
</html>
