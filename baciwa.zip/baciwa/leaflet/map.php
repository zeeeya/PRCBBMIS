<!DOCTYPE html>
<html>
<head>
<meta charset=utf-8 />
<title>A simple map</title>
<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
<style>
  body { margin:0; padding:0; }
  #map { position:absolute; top:0; bottom:0; width:100%;}
</style>
</head>
<body>
<div id='map'></div>
<script>
L.mapbox.accessToken = 'pk.eyJ1Ijoiam95bWVyaWxsIiwiYSI6ImNpaWgwcW5ndTAycTR2dG0xZnlocHppbG4ifQ.XIsgAOt_JunkNd-8HmZ6-Q';
var map = L.mapbox.map('map', 'joymerill.ohpd3g9i')
    .setView([10.661, 123.145], 17);
</script>
</body>
</html>