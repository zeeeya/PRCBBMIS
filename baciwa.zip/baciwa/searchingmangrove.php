<?php 
include('php/login_success.php'); 
include('php/links.php');
include('database.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
		<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
		<style>
			#map 
			{ 	margin:3% 3%;
				width:95%; 
				height:62%; 
			}
		</style>
	 </head>
	<body>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		
		
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredregistration.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			</div>
		</div>
		
		<?php

			$str = $_POST['searchInput'];
			//echo $str;
			$item = array();
			
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid";
			foreach ($pdo->query($sql) as $row) {
				if($str === $row['orgname']){
					$sql2 = "SELECT * FROM schedule INNER JOIN participants ON schedule.schedid = participants.schedid WHERE regid = '".$row['regid']."'";
					foreach ($pdo->query($sql2) as $data) {
						if(!empty($data['treepatch'])){
							$item[] = $data['treepatch'];
						}
					}
				}
			}
			
			$result = array_unique($item);
			Database::disconnect();

		?>
		
		<script type="text/javascript">
			var ar = <?php echo json_encode($result) ?>;
		</script>
		
		<div class="col-md-9">
			<br />
			<form  method="post" action="searchingmangrove.php"  name="searchform1"> 
			<div class="row">
				<div class="col-lg-12">
					
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Search Organization..." name="searchInput">
						<span class="input-group-btn">
						<button class="btn btn-default" type="submit">Go!</button>
					  </span>
					</div><!-- /input-group -->
				</div><!-- /.col-lg-6 -->
			</div>	
			</form>
			<div id='map'></div>
		</div>
	</div>
<style>
.map-legend ul {
  list-style: none;
  padding-left: 0;
  }
.map-legend .swatch {
  width:20px;
  height:20px;
  float:left;
  margin-right:10px;
  }
.leaflet-popup-close-button {
  display: none;
  }
.leaflet-popup-content-wrapper {
  pointer-events: none;
  }
</style>

<script src='php/mangroveplanting.php'></script>
<script>
//basemap
L.mapbox.accessToken = 'pk.eyJ1IjoibmF6ZXJjYWx1bXBpYW5vIiwiYSI6ImNpZXd5ZGZpaDA4Yzlza2txNTdrdTc5M3AifQ.-XyoP4Y98GGOAXF3fD8juw#18/10.60858/122.90814';
var map = L.mapbox.map('map', 'mapbox.satellite').setView([10.607, 122.91], 16);

var popup = new L.Popup({ autoPan: false });

  var statesLayer = L.geoJson(patches,  {
      style: getStyle,
      onEachFeature: onEachFeature
  }).addTo(map);

  function getStyle(feature) {
      return {
          weight: 2,
          opacity: 0.1,
          color: 'black',
          fillOpacity: 0.7,
          fillColor: getColor(feature.properties.density)
      };
  }

  // get color depending on population density value
  function getColor(d) {
      return d > 1000 ? '#004d1a' :
          d > 500  ? '#006622' :
          d > 200  ? '#009933' :
          d > 100  ? '#00cc44' :
          d > 50   ? '#00ff55' :
          d > 20   ? '#33ff77' :
          d > 10   ? '#66ff99' :
          '#ccffdd';
  }

  function onEachFeature(feature, layer) {
      layer.on({
          mousemove: mousemove,
          mouseout: mouseout,
          click: zoomToFeature
      });
  }

  var closeTooltip;

  function mousemove(e) {
      var layer = e.target;

      popup.setLatLng(e.latlng);
      popup.setContent('<div class="marker-title"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;Click to view <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;participants in <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + layer.feature.properties.name + '</div>' +
          '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + layer.feature.properties.density + ' Mangrove Trees Planted');

      if (!popup._map) popup.openOn(map);
      window.clearTimeout(closeTooltip);

      // highlight feature
      layer.setStyle({
          weight: 3,
          opacity: 0.3,
          fillOpacity: 0.9
      });

      if (!L.Browser.ie && !L.Browser.opera) {
          layer.bringToFront();
      }
  }

  function mouseout(e) {
      statesLayer.resetStyle(e.target);
      closeTooltip = window.setTimeout(function() {
          map.closePopup();
      }, 100);
  }

  function zoomToFeature(e) {
    //map.fitBounds(e.target.getBounds());
	var layer = e.target;
	window.location = layer.feature.properties.url;
  }

  map.legendControl.addLegend(getLegendHTML());

  function getLegendHTML() {
    var grades = [0, 10, 20, 50, 100, 200, 500, 1000],
    labels = [],
    from, to;

    for (var i = 0; i < grades.length; i++) {
      from = grades[i];
      to = grades[i + 1];

      labels.push(
        '<li><span class="swatch" style="background:' + getColor(from + 1) + '"></span> ' +
        from + (to ? '&ndash;' + to : '+')) + '</li>';
    }

    return '<span> Mnagrove Trees Planted</span><ul>' + labels.join('') + '</ul>';
  }
  
  for(var a = 0; a < ar.length; a++){
		
		switch(ar[a]){
  			case 'Patch001': L.marker([10.6079, 122.9067], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch002': L.marker([10.6085, 122.9070], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch003': L.marker([10.6089, 122.9077], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch004': L.marker([10.6094, 122.9085], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch005': L.marker([10.6097, 122.9093], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch006': L.marker([10.6068, 122.9071], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch007': L.marker([10.6072, 122.9077], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch008': L.marker([10.6075, 122.9084], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch009': L.marker([10.6081, 122.9092], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch010': L.marker([10.6088, 122.9098], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch011': L.marker([10.6088, 122.9112], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch012': L.marker([10.6059, 122.9077], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch013': L.marker([10.6060, 122.9085], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch014': L.marker([10.6065, 122.9091], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch015': L.marker([10.6069, 122.9099], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch016': L.marker([10.6074, 122.9106], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch017': L.marker([10.6078, 122.9114], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch018': L.marker([10.6082, 122.9120], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch019': L.marker([10.6048, 122.9085], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch020': L.marker([10.6051, 122.9092], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch021': L.marker([10.6055, 122.9098], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch022': L.marker([10.6060, 122.9106], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch023': L.marker([10.6063, 122.9113], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch024': L.marker([10.6067, 122.9121], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch025': L.marker([10.6071, 122.9127], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch026': L.marker([10.6037, 122.9093], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch027': L.marker([10.6040, 122.9099], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch028': L.marker([10.6044, 122.9105], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch029': L.marker([10.6048, 122.9113], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch030': L.marker([10.6051, 122.9119], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch031': L.marker([10.6057, 122.9127], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch032': L.marker([10.6059, 122.9134], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;

		}
	}

</script>
	
<?php
include('footer.php'); 
?>
</body>
</html>