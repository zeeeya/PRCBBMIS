<?php 
include('php/login_success.php'); 
include('php/links.php');
include 'database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./jquery-timepicker-1.3.2/jquery.timepicker.min.css">

  
	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jquery-timepicker-1.3.2/jquery.timepicker.min.css"></script>
  
	<!-- Date picker-->
	<link rel="stylesheet" href="css/datepicker.css">
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
	
	<link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
	<?php include('header.php'); ?>

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Reimbursement Expense</h1>
		</div>
	</div>

	<div class="container-fluid">
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="new_reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create Reimbursement Expense</a>
				<a href="reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Reimbursement Expense</a>
			</div>		
		</div>
		
		<!--start of Content -->
		<div class="col-lg-9 content">
					<h2>Reimbursement List</h2>
					<hr />
					
						<div class='container-fluid'>
							<div class='row'>
								<div class='col-md-12'>
								
									<?php
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = 'SELECT * FROM liquidation WHERE liqstat = "Approved" && liqtotal < 0';
										echo '<table class="table table-striped">';
										echo '<thead>
												<tr>
													<th>Liquidation Code</th>
													<th>Subject for Liquidation</th>
													<th>Status</th>
													<th>Action</th>
												</tr>
											  </thead>';
										foreach ($pdo->query($sql) as $row) {
											echo '<tbody>
													<tr>';
													echo '<td>'.$row['liqcode'].'</td>';
													echo '<td>'.$row['liqsub'].'</td>';
													echo '<td>'.$row['liqstat'].'</td>';
													echo '<td>
															<a class="btn btn-primary btn-md" href="reimbursementNew.php?id='.$row['liqcode'].'" data-toggle="tooltip" title="Reimburse liquidation"><span class="glyphicon glyphicon-edit" style="margin-right:10px"></span><strong>Reimburse</strong></a>
													</td>';											  
											echo 	'</tr>';
											echo '</tbody>';
										}
										echo '</table>';
										Database::disconnect();
									?>
									<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip(); 
									$('.btn').tooltip();
								});
								</script>
								</div>
							</div>
						</div>
		</div>
    </div>
<?php include('./footer.php'); ?>
</body>
</html>


<?php /*
	<!-- Status -->
	<div class="form-group">
		<label class="radio-inline"><input type="radio" name="optradio">Pending</label>
		<label class="radio-inline"><input type="radio" name="optradio">Done</label>
		<label class="radio-inline"><input type="radio" name="optradio">Cancelled</label>
		<label class="radio-inline"><input type="radio" name="optradio">Postponed</label>
	</div>
	<!-- Remarks -->
	<div class="form-group">
		<label for="inputProfileRemark">Remarks:</label>
		<textarea class="form-control" id="inputProfileRemark" rows="6" name="remark2" placeholder="Remarks here"></textarea>
	</div>
*/ ?>	