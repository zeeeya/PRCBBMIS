<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
	<div style="margin-left:350px" id='map'></div>
	
	<div class="col-md-3">
		<!-- side bar -->
		<div class="list-group side_bar">
			<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
			<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
		</div>
			<button class="btn btn-primary " type="button" data-toggle="modal" data-target="#myModal" rel="tooltip" title="Add Organization" data-placement="top" style="margin-left:5px;">
			<span class="glyphicon glyphicon-plus" aria-hidden="true">Add</span>
			</button>
		</div>

		<div class="modal fade" tabindex="-1" role="dialog" id="myModal" style="margin-top:20px;font-size:14px;">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header alert-info">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Map Information</h4>
				</div>
				
				
				<form class="form-horizontal" role="form" action='./php/MapCreateModal.php' method="POST">
					<div class="modal-body">
						<div class="row" style="margin:0 25px;"><!-- Schedule -->
							<div class="form-group" >

							<!-- Date -->
							<div class="form-group">
								<label for="inputDate">Date</label>
								<input type="text" class="form-control" required="required" id="inputDate" name="schedule" placeholder="Enter Date">
							</div>
							
							<!-- Organization Name -->									
							<div class="form-group">
								<label class="control-label" for="inputOrgName">Organization Name</label>
									<div class="input-group">
										<span class="input-group-btn">
											<select class="form-control" require="required" id="inputOrgName" name="orgname" onChange="showUser(this.value)">
												<option selected="selected" disabled>-- Select Organization --</option>
											</select>
										</span>
									</div>
								</div>
						
							<!-- Activity -->
							<div class="form-group">
								<label class="control-label" for="inputActivity">Activity</label>
									<select class="form-control" required="required" id="inputActivity" name="activity">
										<option selected="selected" disabled>-- Select Activity --</option>
										<option value="Tree Planting">Tree Planting</option>
										<option value="Mangrove Planting">Mangrove Planting</option>
									</select>
							</div>

							<!-- No. of Participants -->
							<div class="form-group">
								<label for="inputnumPart">Number of Participants</label>
								<input type="text" class="form-control" required="required" id="inputnumPart" name="number" placeholder="Number of Participants" >
							</div>

							<!-- Name of Trees -->
							<div class="form-group">
								<label for="inputNameTree">Name of Trees</label>
								<input type="text" class="form-control" required="required" id="inputNameTree" name="nametrees" placeholder="Name of Trees" >
							</div>

							<!-- Type of Trees -->
							<div class="form-group">
								<label for="inputTypeTree">Type of Trees</label>
								<input type="text" class="form-control" required="required" id="inputTypeTree" name="typetrees" placeholder="Type of Trees" >
							</div>

									<!-- Trees -->
		                  <div class="form-group">
		                    <label for="inputOrg">TREES:</label>
		                  </div>

		                  <!-- Lived -->
		                  <div class="form-group">
		                    <label for="inputAdd">Lived</label>
		                    <input type="text" class="form-control" required="required" id="inputAdd" name="livedTreesPM" placeholder="Lived Trees or Propagules">
		                  </div>

		                  <!-- withered -->
		                  <div class="form-group">
		                    <label for="inputAdd">Withered</label>
		                    <input type="text" class="form-control" required="required" id="inputAdd" name="witheredTreesPM" placeholder="Withered Trees or Propagules">
		                  </div>

                  		  <!-- Remarks -->
						<div class="form-group">
							<label for="inputProfileRemark">Remarks:</label>
							<textarea class="form-control" id="inputProfileRemark" rows="6" name="remark" placeholder="Any Remarks?"></textarea>
						</div>	
					</div>
		  
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->	
