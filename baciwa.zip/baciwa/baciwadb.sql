-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2016 at 10:29 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `baciwadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `budget`
--

CREATE TABLE IF NOT EXISTS `budget` (
  `budcode` varchar(17) NOT NULL,
  `budsub` varchar(150) NOT NULL,
  `buddate` varchar(10) NOT NULL,
  `regid` varchar(17) NOT NULL,
  `budamount` float NOT NULL,
  `budstat` varchar(10) NOT NULL,
  `budgetremarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `budget`
--

INSERT INTO `budget` (`budcode`, `budsub`, `buddate`, `regid`, `budamount`, `budstat`, `budgetremarks`) VALUES
('01-01232016034639', 'budget for unor tree planting', '01/23/2016', '00-01232016032348', 256, 'Done', ''),
('01-01232016052659', 'Budget for LCC Tree Planting Activity', '01/23/2016', '00-01222016101346', 207.4, 'Done', ''),
('01-02062016055036', 'Budget for Pag-Ibig Fund', '02/06/2016', '00-02062016031057', 1456, 'Done', ''),
('01-02072016045606', 'Budget for SSS planting activity', '02/07/2016', '00-02072016045451', 3000, 'Done', ''),
('01-02082016044553', 'Budget for Tree Planting', '02/08/2016', '00-02082016044339', 2250, 'Pending', ''),
('01-02122016020201', 'Cash Advance for Pag-ibig Fund', '02/12/2016', '00-02122016014813', 59000, 'Done', ''),
('01-02172016061903', 'Cash Advance for Asia Link Mangrove Planting', '02/17/2016', '00-02172016060752', 1700, 'Approved', '');

-- --------------------------------------------------------

--
-- Table structure for table `incident`
--

CREATE TABLE IF NOT EXISTS `incident` (
  `incid` int(11) NOT NULL,
  `incname` varchar(100) NOT NULL,
  `incdate` varchar(15) NOT NULL,
  `inctype` varchar(50) NOT NULL,
  `incdesc` varchar(100) NOT NULL,
  `incadd` varchar(100) NOT NULL,
  `incact` varchar(100) NOT NULL,
  `orgid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incident`
--

INSERT INTO `incident` (`incid`, `incname`, `incdate`, `inctype`, `incdesc`, `incadd`, `incact`, `orgid`) VALUES
(1, 'Joy Merill Villagracia', '01/26/2016', 'Minor Injuries', 'Hapo', 'brotherhood', 'Tree Planting', 3);

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `itemcode` int(11) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `itemunit` varchar(50) NOT NULL,
  `itemprice` float NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemcode`, `itemname`, `itemunit`, `itemprice`) VALUES
(2, 'Rice', 'Kilo', 41.2),
(6, 'Propagules', 'Piece(s)', 5),
(7, 'Guide', 'Person', 100),
(8, 'Seedlings', 'Piece(s)', 10),
(9, 'Transportation (Mangrove Planting)', 'Others', 600),
(10, 'Transportation (Tree Planting)', 'Others', 1500);

-- --------------------------------------------------------

--
-- Table structure for table `itembudget`
--

CREATE TABLE IF NOT EXISTS `itembudget` (
  `itembudid` int(11) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `itemquantity` int(11) NOT NULL,
  `itemunit` varchar(100) NOT NULL,
  `itemprice` float NOT NULL,
  `budcode` varchar(17) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itembudget`
--

INSERT INTO `itembudget` (`itembudid`, `itemname`, `itemquantity`, `itemunit`, `itemprice`, `budcode`) VALUES
(3, 'Rice', 2, 'Kilo', 82.4, '01-01232016052659'),
(4, 'Bread', 50, 'piece', 125, '01-01232016052659'),
(5, 'Rice', 5, 'Kilo', 206, '01-01232016034639'),
(6, 'Bread', 20, 'piece', 50, '01-01232016034639'),
(7, 'Chicken', 3, 'kilogram', 750, '01-02062016055036'),
(8, 'Rice', 5, 'Kilo', 206, '01-02062016055036'),
(9, 'Bread', 200, 'piece', 500, '01-02062016055036'),
(10, 'Bread', 200, 'piece', 500, '01-02072016045606'),
(11, 'Chicken', 10, 'kilogram', 2500, '01-02072016045606'),
(20, 'Bread', 100, 'piece', 250, '01-02082016044553'),
(21, 'Chicken', 8, 'kilogram', 2000, '01-02082016044553'),
(22, 'Transportation', 30, 'Others', 18000, '01-02122016020201'),
(23, 'Seedlings', 1500, 'Piece(s)', 15000, '01-02122016020201'),
(24, 'Guide', 10, 'Person', 1000, '01-02122016020201'),
(25, 'Propagules', 5000, 'Piece(s)', 25000, '01-02122016020201'),
(26, 'Transportation', 2, 'Others', 1200, '01-02172016061903'),
(27, 'Propagules', 100, 'Piece(s)', 500, '01-02172016061903');

-- --------------------------------------------------------

--
-- Table structure for table `liquidation`
--

CREATE TABLE IF NOT EXISTS `liquidation` (
  `liqcode` varchar(17) NOT NULL,
  `budcode` varchar(17) NOT NULL,
  `liqdate` varchar(10) NOT NULL,
  `liqamnt` float NOT NULL,
  `liqtotal` float NOT NULL,
  `liqstat` varchar(12) NOT NULL,
  `liqsub` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `liquidation`
--

INSERT INTO `liquidation` (`liqcode`, `budcode`, `liqdate`, `liqamnt`, `liqtotal`, `liqstat`, `liqsub`) VALUES
('02-02172016021355', '01-01232016052659', '02/17/2016', 207.4, 0, 'Received', 'La Consolacion College-Bacolod Budget'),
('02-02172016124242', '01-01232016034639', '02/17/2016', 258.5, -2.5, 'Received', 'UNO-R Tree Planting Budget'),
('02-03082016033617', '01-02122016020201', '03/08/2016', 59000, 0, 'For Approval', 'Liquidation for Pag-Ibig Cash Advance Tree Planting Activity');

-- --------------------------------------------------------

--
-- Table structure for table `liquidationitem`
--

CREATE TABLE IF NOT EXISTS `liquidationitem` (
  `liqitmid` int(11) NOT NULL,
  `liqitmor` varchar(50) NOT NULL,
  `liqitmname` varchar(50) NOT NULL,
  `liqitmprc` float NOT NULL,
  `liqcode` varchar(17) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `liquidationitem`
--

INSERT INTO `liquidationitem` (`liqitmid`, `liqitmor`, `liqitmname`, `liqitmprc`, `liqcode`) VALUES
(8, '2222', 'Bread', 20, '02-02052016043205'),
(9, '12345', 'Rice', 60, '02-02052016043205'),
(10, 'ABC123', 'Rice', 206, '02-02032016111039'),
(11, '123ABC', 'Bread', 250, '02-02032016111039'),
(12, '09876', 'Chicken', 500, '02-02062016062312'),
(13, '12345', 'Bread - Pan de Sal', 200, '02-02062016062312'),
(14, '21181', 'Pan de Sals', 56, '02-02072016050323'),
(15, '12167', 'Pan de Sal', 200, '02-02072016050323'),
(16, '837819', 'Chicken', 2500, '02-02072016054236'),
(17, '129313', 'Bread', 400, '02-02072016054236'),
(18, '124357', 'Tinapay', 100, '02-02072016054236'),
(23, '231414', 'Rice', 206, '02-02082016094445'),
(24, '268821', 'Bread', 50, '02-02082016094445'),
(25, '112726271', 'Bread', 2.5, '02-02092016025639'),
(26, '14262', 'Rice', 41.2, '02-02092016025639'),
(36, '213PQO', 'Bread Store', 125, '02-02172016021355'),
(37, '123ABG', 'Rice Store', 82.4, '02-02172016021355'),
(38, 'AQT', 'Libramart', 2.5, '02-02172016124242'),
(39, 'MAN', 'Foodman Bread and Pastries', 50, '02-02172016124242'),
(40, 'ABC', 'National Food Authority', 206, '02-02172016124242'),
(41, '123503', 'Any Store', 59000, '02-03082016033617');

-- --------------------------------------------------------

--
-- Table structure for table `map`
--

CREATE TABLE IF NOT EXISTS `map` (
  `markerid` int(11) NOT NULL,
  `coordinateX` varchar(15) NOT NULL,
  `coordinateY` varchar(15) NOT NULL,
  `patch` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `map`
--

INSERT INTO `map` (`markerid`, `coordinateX`, `coordinateY`, `patch`) VALUES
(1, '123.146524', '10.661746', 'Patch01'),
(2, '123.14897', '10.664066', 'Patch02'),
(3, '123.150215', '10.662189', 'Patch03'),
(4, '123.14867', '10.66105', 'Patch04'),
(5, '123.152081', '10.662927', 'Patch05'),
(6, '123.153626', '10.661071', 'Patch06'),
(7, '123.150408', '10.659216', 'Patch07'),
(8, '123.14749', '10.658689', 'Patch09'),
(9, '123.149206', '10.657381', 'Patch10'),
(10, '123.146824', '10.657044', 'Patch11'),
(11, '123.152575', '10.657634', 'Patch12'),
(12, '123.147897', '10.655483', 'Patch13'),
(13, '123.149936', '10.655125', 'Patch14'),
(14, '123.151116', '10.656516', 'Patch15');

-- --------------------------------------------------------

--
-- Table structure for table `map_activity`
--

CREATE TABLE IF NOT EXISTS `map_activity` (
  `mapid` int(11) NOT NULL,
  `markerid` int(11) NOT NULL,
  `schedid` int(11) NOT NULL,
  `treesnum` int(11) NOT NULL,
  `partnum` int(5) NOT NULL,
  `orgid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `map_activity`
--

INSERT INTO `map_activity` (`mapid`, `markerid`, `schedid`, `treesnum`, `partnum`, `orgid`) VALUES
(1, 4, 15, 400, 200, 7),
(2, 1, 19, 240, 120, 2),
(3, 2, 16, 455, 230, 6),
(4, 4, 19, 4, 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE IF NOT EXISTS `organization` (
  `orgid` int(11) NOT NULL,
  `orgname` varchar(100) NOT NULL,
  `orgtype` varchar(50) NOT NULL,
  `orgadd` varchar(250) NOT NULL,
  `orgcperson` varchar(50) NOT NULL,
  `orgcnum` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`orgid`, `orgname`, `orgtype`, `orgadd`, `orgcperson`, `orgcnum`) VALUES
(2, 'Bacolod City National High School', 'Private Schools', 'P-Hernaez St., Taculing, Bacolod City', 'Rosalinda C. Ortaleza', '09125615265'),
(3, 'Luisa Medel High School', 'Public Schools', 'Tangub, Bacolod City', 'Juanito D. Altamera', '4430958'),
(5, 'University of St. La Salle', 'Private Company', 'La Salle Avenue, Bacolod City', 'Joseph Christian A. Tan', '7089884'),
(6, 'La Consolacion College-Bacolod', 'Private Schools', 'Bacolod City', 'Rodrigo B. Lakambini', '09285922634'),
(7, 'University of Negros Occidental-Recoletos', 'Private Schools', 'Lizares Ext., Bacolod City', 'Jose C. De la Cruz', '09488723456'),
(8, 'Philippine National Police', 'Government Agency', 'Alijis, Bacolod City', 'Supt. Panfilo O. Lacson', '466-8875'),
(9, 'Pag-IBIG Fund', 'Government Agency', 'Araneta St., Bacolod City', 'Crisendo Pascua', '444-12-34'),
(10, 'Social Security System', 'Government Agency', 'Lacson, Bacolod City', 'Emily Cruz', '09261725161'),
(11, 'Asia Link', 'Private Company', 'Lacson, Bacolod City', 'Juan dela Cruz', '0912837139');

-- --------------------------------------------------------

--
-- Table structure for table `participants`
--

CREATE TABLE IF NOT EXISTS `participants` (
  `partid` int(11) NOT NULL,
  `partname` varchar(100) NOT NULL,
  `partnum` int(11) NOT NULL,
  `schedid` int(11) NOT NULL,
  `partstat` varchar(9) NOT NULL,
  `treepatch` varchar(10) NOT NULL,
  `treeqty` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participants`
--

INSERT INTO `participants` (`partid`, `partname`, `partnum`, `schedid`, `partstat`, `treepatch`, `treeqty`) VALUES
(17, 'University of Negros Occidental-Recoletos', 50, 15, 'Pending', '', 0),
(18, 'West Negros University', 10, 16, 'Pending', '', 0),
(19, 'Collegio de San Agustine', 40, 16, 'Pending', '', 0),
(20, 'ABS-CBN', 10, 15, 'Pending', '', 0),
(21, 'Arfien', 20, 17, 'Pending', '', 0),
(22, 'CIT', 20, 18, 'Pending', 'Patch_01', 50),
(23, 'CIT', 200, 19, 'Pending', 'Patch_02', 50),
(26, 'Social Security System', 100, 24, 'Pending', '', 0),
(27, 'Pag IBIG Fund', 25, 25, 'Pending', 'Patch006', 50),
(28, 'Social Security System', 20, 27, 'Pending', 'Patch_14', 5),
(29, 'Pag IBIG Fund', 30, 28, 'Pending', '', 0),
(30, 'College of Arts and Sciences', 50, 29, 'Pending', 'Patch001', 49),
(31, 'Philippine National Police', 29, 30, 'Pending', 'Patch_14', 5),
(32, 'English Department', 45, 31, 'Pending', 'Patch_01', 5),
(33, 'Marketing and Sales Department', 30, 32, 'Pending', '', 0),
(34, 'Asia Link', 20, 33, 'Pending', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `regid` varchar(17) NOT NULL,
  `regact` varchar(17) NOT NULL,
  `orgid` int(11) NOT NULL,
  `regcperson` varchar(50) NOT NULL,
  `regcnum` varchar(20) NOT NULL,
  `regmemo` varchar(250) NOT NULL,
  `partnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`regid`, `regact`, `orgid`, `regcperson`, `regcnum`, `regmemo`, `partnum`) VALUES
('00-01052016051301', 'Mangrove Planting', 7, 'Jose C. De la Cruz', '09488723456', 'Remarks\r\nPending Approval', 0),
('00-01222016101346', 'Tree Planting', 6, 'Rodrigo B. Lakambini', '09285922634', '', 0),
('00-01232016032348', 'Tree Planting', 7, 'Elmer T. Haro', '09488723456', '', 0),
('00-02052016055249', 'Tree Planting', 7, 'Jose C. De la Cruz', '09488723456', '', 0),
('00-02072016101022', 'Mangrove Planting', 10, 'Emily Cruz', '09261725161', '', 0),
('00-02072016105018', 'Mangrove Planting', 9, 'Crisendo Pascua', '444-12-34', '', 0),
('00-02082016044029', 'Mangrove Planting', 5, 'Joseph Christian A. Tan', '7089884', '', 0),
('00-02082016044339', 'Tree Planting', 8, 'Supt. Panfilo O. Lacson', '466-8875', '', 0),
('00-02082016090420', 'Tree Planting', 3, 'Juanito D. Altamera', '4430958', '', 0),
('00-02082016092348', 'Tree Planting', 10, 'Emily Cruz', '09261725161', '', 0),
('00-02082016094002', 'Mangrove Planting', 9, 'Crisendo Pascua', '444-12-34', '', 0),
('00-02122016014813', 'Tree Planting', 9, 'Crisendo Pascua', '444-12-34', '', 0),
('00-02172016060752', 'Mangrove Planting', 11, 'Juan dela Cruz', '0912837139', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reimbursement`
--

CREATE TABLE IF NOT EXISTS `reimbursement` (
  `rerid` int(11) NOT NULL,
  `rername` varchar(100) NOT NULL,
  `reramount` int(10) NOT NULL,
  `rerpayment` int(10) NOT NULL,
  `rerdate` varchar(15) NOT NULL,
  `rerpayname` varchar(100) NOT NULL,
  `rerremarks` varchar(100) NOT NULL,
  `rerpayadd` varchar(100) NOT NULL,
  `rerpayissue` varchar(100) NOT NULL,
  `rerpaycedula` varchar(100) NOT NULL,
  `rerpaydateissue` varchar(100) NOT NULL,
  `rerwitname` varchar(100) NOT NULL,
  `rerwitadd` varchar(100) NOT NULL,
  `rerwitissue` varchar(100) NOT NULL,
  `rerwitcedula` varchar(100) NOT NULL,
  `rerwitdateissue` varchar(100) NOT NULL,
  `liqcode` varchar(17) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reimbursement`
--

INSERT INTO `reimbursement` (`rerid`, `rername`, `reramount`, `rerpayment`, `rerdate`, `rerpayname`, `rerremarks`, `rerpayadd`, `rerpayissue`, `rerpaycedula`, `rerpaydateissue`, `rerwitname`, `rerwitadd`, `rerwitissue`, `rerwitcedula`, `rerwitdateissue`, `liqcode`) VALUES
(1, 'Mark Heras', 100, 0, '02/17/2016', 'Marcos Aurelios', '', 'Bacolod City', 'Baciwa Water District', '12035648', '02/17/2016', 'Marian Ramos', 'Bacolod City', 'Baciwa Water District', '123546', '02/17/2016', '02-02172016124242');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `schedid` int(11) NOT NULL,
  `regid` varchar(17) NOT NULL,
  `scheddate` varchar(10) NOT NULL,
  `schedtime` varchar(8) NOT NULL,
  `schedend` varchar(8) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedid`, `regid`, `scheddate`, `schedtime`, `schedend`) VALUES
(15, '00-01052016051301', '1/21/2016', '6:00 AM', '7:00 PM'),
(16, '00-01052016051301', '12/15/2015', '4:00 AM', '12:00 PM'),
(17, '00-01222016101346', '1/30/2016', '6:00 AM', '12:00 PM'),
(18, '00-01232016032348', '01/25/2016', '6:00 AM', '12:00 PM'),
(19, '00-01232016032348', '01/27/2016', '3:24 PM', '3:24 PM'),
(20, '00-02052016055249', '02/11/2016', '6:00 AM', '12:00 PM'),
(21, '00-02062016031057', '02/13/2016', '6:00 AM', '12:00 PM'),
(22, '00-02072016045451', '03/02/2016', '6:00 AM', '12:00 PM'),
(23, '00-02072016055145', '03/05/2016', '6:00 AM', '12:00 PM'),
(24, '00-02072016101022', '03/09/2016', '6:00 AM', '12:00 PM'),
(25, '00-02072016105018', '03/09/2016', '6:00 AM', '12:00 PM'),
(27, '00-02082016092348', '2016-03-09', '6:00 AM', '12:00 PM'),
(28, '00-02082016094002', '2016-02-25', '6:00 AM', '12:00 PM'),
(29, '00-02082016044029', '2016-03-12', '6:00 AM', '12:00 PM'),
(30, '00-02082016044339', '2016-03-19', '6:00 AM', '12'),
(31, '00-02082016090420', '2016-03-10', '6:00 AM', '12:00 PM'),
(32, '00-02122016014813', '2016-03-05', '6:00 AM', '12:00 PM'),
(33, '00-02172016060752', '2016-02-27', '6:00 AM', '12:00 PM');

-- --------------------------------------------------------

--
-- Table structure for table `tree`
--

CREATE TABLE IF NOT EXISTS `tree` (
  `treeid` int(11) NOT NULL,
  `treepatch` varchar(10) NOT NULL,
  `treetype` varchar(20) NOT NULL,
  `treeqty` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tree`
--

INSERT INTO `tree` (`treeid`, `treepatch`, `treetype`, `treeqty`) VALUES
(1, 'Patch001', 'Mangrove Planting', 1001),
(2, 'Patch002', 'Mangrove Planting', 143),
(3, 'Patch003', 'Mangrove Planting', 65),
(4, 'Patch004', 'Mangrove Planting', 50),
(5, 'Patch005', 'Mangrove Planting', 11),
(6, 'Patch006', 'Mangrove Planting', 3),
(7, 'Patch007', 'Mangrove Planting', 10),
(8, 'Patch008', 'Mangrove Planting', 87),
(9, 'Patch009', 'Mangrove Planting', 48),
(10, 'Patch010', 'Mangrove Planting', 14),
(11, 'Patch011', 'Mangrove Planting', 250),
(12, 'Patch012', 'Mangrove Planting', 387),
(13, 'Patch013', 'Mangrove Planting', 163),
(14, 'Patch014', 'Mangrove Planting', 430),
(15, 'Patch015', 'Mangrove Planting', 87),
(16, 'Patch016', 'Mangrove Planting', 542),
(17, 'Patch017', 'Mangrove Planting', 632),
(18, 'Patch018', 'Mangrove Planting', 100),
(19, 'Patch019', 'Mangrove Planting', 925),
(20, 'Patch020', 'Mangrove Planting', 1000),
(21, 'Patch021', 'Mangrove Planting', 394),
(22, 'Patch022', 'Mangrove Planting', 832),
(23, 'Patch023', 'Mangrove Planting', 675),
(24, 'Patch024', 'Mangrove Planting', 109),
(25, 'Patch025', 'Mangrove Planting', 358),
(26, 'Patch026', 'Mangrove Planting', 482),
(27, 'Patch027', 'Mangrove Planting', 748),
(28, 'Patch028', 'Mangrove Planting', 125),
(29, 'Patch029', 'Mangrove Planting', 452),
(30, 'Patch030', 'Mangrove Planting', 679),
(31, 'Patch031', 'Mangrove Planting', 502),
(32, 'Patch032', 'Mangrove Planting', 852);

-- --------------------------------------------------------

--
-- Table structure for table `treeplanting`
--

CREATE TABLE IF NOT EXISTS `treeplanting` (
  `treeid` int(11) NOT NULL,
  `treepatch` varchar(10) NOT NULL,
  `treetype` varchar(20) NOT NULL,
  `treeqty` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `treeplanting`
--

INSERT INTO `treeplanting` (`treeid`, `treepatch`, `treetype`, `treeqty`) VALUES
(1, 'Patch_01', 'Tree Planting', 299),
(2, 'Patch_02', 'Tree Planting', 931),
(3, 'Patch_03', 'Tree Planting', 12),
(4, 'Patch_04', 'Tree Planting', 10),
(5, 'Patch_05', 'Tree Planting', 219),
(6, 'Patch_06', 'Tree Planting', 333),
(7, 'Patch_07', 'Tree Planting', 50),
(8, 'Patch_08', 'Tree Planting', 429),
(9, 'Patch_09', 'Tree Planting', 845),
(10, 'Patch_10', 'Tree Planting', 419),
(11, 'Patch_11', 'Tree Planting', 200),
(12, 'Patch_12', 'Tree Planting', 1000),
(13, 'Patch_13', 'Tree Planting', 290),
(14, 'Patch_14', 'Tree Planting', 5),
(15, 'Patch_15', 'Tree Planting', 720);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `unitid` int(11) NOT NULL,
  `unitabbr` varchar(20) NOT NULL,
  `unitdesc` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unitid`, `unitabbr`, `unitdesc`) VALUES
(1, 'kg', 'Kilogram'),
(2, 'g', 'Gram'),
(3, 'pc(s)', 'Piece(s)'),
(4, 'lb(s)', 'Pound(s)'),
(5, 'sack', 'Sack'),
(6, 'bg', 'Bag'),
(7, 'bt', 'Bottle'),
(8, 'cs', 'Case'),
(9, 'L', 'Liter'),
(10, 'Person', 'Person'),
(11, 'Others', 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL,
  `username` varchar(65) NOT NULL,
  `password` varchar(65) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'manager', 'manager');

-- --------------------------------------------------------

--
-- Table structure for table `witheredtrees`
--

CREATE TABLE IF NOT EXISTS `witheredtrees` (
  `wtcode` int(11) NOT NULL,
  `wtdate` varchar(10) NOT NULL,
  `wtpatch` varchar(15) NOT NULL,
  `wtnum` int(11) NOT NULL,
  `wtcause` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `witheredtrees`
--

INSERT INTO `witheredtrees` (`wtcode`, `wtdate`, `wtpatch`, `wtnum`, `wtcause`) VALUES
(1, '2016-02-17', 'Patch_01', 15, 'Earthquake'),
(2, '2016-02-17', 'Patch001', 1, 'Dry Weather');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `budget`
--
ALTER TABLE `budget`
  ADD PRIMARY KEY (`budcode`), ADD UNIQUE KEY `budsub` (`budsub`,`regid`);

--
-- Indexes for table `incident`
--
ALTER TABLE `incident`
  ADD PRIMARY KEY (`incid`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`itemcode`), ADD UNIQUE KEY `itemname` (`itemname`);

--
-- Indexes for table `itembudget`
--
ALTER TABLE `itembudget`
  ADD PRIMARY KEY (`itembudid`);

--
-- Indexes for table `liquidation`
--
ALTER TABLE `liquidation`
  ADD PRIMARY KEY (`liqcode`), ADD UNIQUE KEY `budcode` (`budcode`);

--
-- Indexes for table `liquidationitem`
--
ALTER TABLE `liquidationitem`
  ADD PRIMARY KEY (`liqitmid`);

--
-- Indexes for table `map`
--
ALTER TABLE `map`
  ADD PRIMARY KEY (`markerid`);

--
-- Indexes for table `map_activity`
--
ALTER TABLE `map_activity`
  ADD PRIMARY KEY (`mapid`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`orgid`), ADD UNIQUE KEY `name` (`orgname`);

--
-- Indexes for table `participants`
--
ALTER TABLE `participants`
  ADD PRIMARY KEY (`partid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`regid`);

--
-- Indexes for table `reimbursement`
--
ALTER TABLE `reimbursement`
  ADD PRIMARY KEY (`rerid`), ADD UNIQUE KEY `liqcode` (`liqcode`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedid`);

--
-- Indexes for table `tree`
--
ALTER TABLE `tree`
  ADD PRIMARY KEY (`treeid`), ADD UNIQUE KEY `treepatch` (`treepatch`);

--
-- Indexes for table `treeplanting`
--
ALTER TABLE `treeplanting`
  ADD PRIMARY KEY (`treeid`), ADD UNIQUE KEY `treepatch` (`treepatch`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`unitid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `witheredtrees`
--
ALTER TABLE `witheredtrees`
  ADD PRIMARY KEY (`wtcode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `incident`
--
ALTER TABLE `incident`
  MODIFY `incid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `itemcode` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `itembudget`
--
ALTER TABLE `itembudget`
  MODIFY `itembudid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `liquidationitem`
--
ALTER TABLE `liquidationitem`
  MODIFY `liqitmid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `map`
--
ALTER TABLE `map`
  MODIFY `markerid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `map_activity`
--
ALTER TABLE `map_activity`
  MODIFY `mapid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `orgid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `participants`
--
ALTER TABLE `participants`
  MODIFY `partid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `reimbursement`
--
ALTER TABLE `reimbursement`
  MODIFY `rerid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `schedid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `tree`
--
ALTER TABLE `tree`
  MODIFY `treeid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `treeplanting`
--
ALTER TABLE `treeplanting`
  MODIFY `treeid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `unitid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `witheredtrees`
--
ALTER TABLE `witheredtrees`
  MODIFY `wtcode` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
