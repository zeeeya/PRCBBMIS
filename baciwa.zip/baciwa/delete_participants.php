<?php 
include('php/login_success.php'); 
include('php/links.php');
?>


<?php
    require 'database.php';
	
	$id = $_REQUEST['id'];
	$regid = $_REQUEST['regid'];
		
    if ( !empty($_POST)) {
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM participants  WHERE partid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        Database::disconnect();
        header("Location: ./view_schedule.php?id=".$regid);
        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

</head>

<body>
	<?php include('header.php'); ?>
	
	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>
	
	<div class="container-fluid">
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;View Organization(s)</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
			</div>		
		</div>
				
		<div class="col-lg-9 content">
			<h2>Remove this participant from the schedule?</h2>
			<hr />
			<br />

			<form class="form-horizontal" action="delete_participants.php" method="post">
				<input type="hidden" name="id" value="<?php echo $id;?>"/>
				<input type="hidden" name="regid" value="<?php echo $regid;?>"/>
				<div class="alert alert-danger">Do you really want to remove this participant?
					&nbsp;
					<button type="submit" class="btn btn-danger">Yes</button>
					<a class="btn btn-default" href="view_schedule.php?id=<?php echo $_GET['regid']; ?>">No</a>
				</div>
			</form>
		</div>
	</div>
<?php include('footer.php'); ?>
</body>
</html>

