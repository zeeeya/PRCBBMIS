<?php
	require 'database.php';
	
	$id = $_POST['id'];
	
	if(!empty($id)){
		
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM item where itemcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$item = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		
		echo '
		<form class="form-inline" role="form">
			<div class="form-group">
				<input type="hidden" class="form-control" id="codeItem" value='. $item['itemcode'].'>
			</div>
			<div class="form-group">
				<input type="hidden" class="form-control" id="nameItem" value='. $item['itemname'].'>
			</div>
			<div class="form-group">
				<input type="hidden" class="form-control" id="unitItem" value='. $item['itemunit'].'>
			</div>
			<div class="form-group">
				<input type="hidden" class="form-control" id="priceItem" value='. $item['itemprice'].'>
			</div>
		</form>';
	}else{
		
	}
?>