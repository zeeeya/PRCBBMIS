<div class="container-fluid page_title_container text-right" style="margin-top:30px; position:relative; bottom:-200px; height:30px;color:white;font-size:12px;">
	<span style="position:relative;top:10px;padding: 5px;"><strong>© 2015-2016 Information System | College of Information Technology | University of Negros Occidental-Recoletos</strong></span>
</div>
