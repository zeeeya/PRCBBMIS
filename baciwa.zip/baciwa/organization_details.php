<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: view_organization.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM organization where orgid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/sidebar.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</head>
<body>
<div>

    <div class="navbar navbar-default navbar-fixed-top" style= "z-index:99999">
      <div class="container">
        <div class="navbar-header">          	
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <a class="navbar-brand" href="home.php"><img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" /></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href=" <?php  echo($Home) ?>">HOME</a></li>
            <li><a href=" <?php  echo($Registration) ?>">REGISTRATION</a></li>
            <li><a href=" <?php  echo($Budget) ?>">BUDGET</a></li>
            <li><a href=" <?php  echo($Liquidation) ?>">LIQUIDATION</a></li>
            <li><a href=" <?php  echo($Miscellaneous) ?>">MISCELLANEOUS</a></li>
            <li><a href=" <?php  echo($Report) ?>">REPORTS</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
        	<li><a href=" <?php echo($Signup) ?>"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
        	<li><a href=" <?php echo($Logout) ?>"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      	  </ul>
          
        </div>
      </div>
    </div>

    <div class="jumbotron home-header">
    	<table>
        	<tr>
            	<td><img src="img/baciwa_thesis.png" alt="thesis-logo"/></td>
            	<td>
        			<h1>Bacolod City Water District</h1> 
  					<p>Planting Activity Management System</p>        
                </td>                
            </tr>
  		</table> 
	</div>

</div>

	<div class="container-fluid main-wrapper">

		<div class="row">
			<div class="container-fluid menu-title">
			<h1>Registration</h1>
			</div>
			<div class="row">
				<div class="col-lg-3 menu-sidebar">
					<!-- side bar -->
					<div class="sidebar-nav">
						  <div class="navbar navbar-default" role="navigation">
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							  </button>
							  <span class="visible-xs navbar-brand">Sidebar menu</span>
							</div>
							<div class="navbar-collapse collapse sidebar-navbar-collapse">
							  <ul class="nav navbar-nav">
                              	<li><a href="view_organization.php">Register an Organization</a></li>
								<li><a href="new_registration.php">New Registration</a></li>
								<li><a href="registration.php">View Registration List</a></li>
							  </ul>
							</div><!--/.nav-collapse -->
						  </div>
					</div>
				</div>
				<div class="col-lg-9 main-content">
					
                    <h3>Organization Details</h3>
					<br />
                     
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td><strong>Organization Name</strong></td>
									<td><?php echo $data['orgname'];?></td>					
								</tr>
                                
								<tr>
									<td><strong>Organization Type</strong></td>
									<td><?php echo $data['orgtype'];?></td>					
								</tr>
                                
								<tr>
									<td><strong>Organization Address</strong></td>
									<td><?php echo $data['orgadd'];?></td>					
								</tr>
															
							</tbody>
						</table>
					</div>
					
					<div class="form-actions text-center">
                        <a class="btn btn-info" href="view_organization.php">Back</a>
                    </div>
			

			</div>
		</div>
	</div>

</body>
</html>