<?php 
include('php/login_success.php'); 
include('php/links.php');
include 'database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./jquery-timepicker-1.3.2/jquery.timepicker.min.css">

  
	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jquery-timepicker-1.3.2/jquery.timepicker.min.css"></script>
  
	<!-- Date picker-->
	<link rel="stylesheet" href="css/datepicker.css">
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
	
	<link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
	<?php include('header.php'); ?>

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>

	<div class="container-fluid">
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>
			</div>		
		</div>
		
		<!--start of Content -->
		<div class="col-lg-9 content">
			<div class="row">
				<h2 style="margin-left:10px;">New Registration</h2>
				<br />
			</div>
			
			<form class="form-horizontal" role="form" action='./php/registrationCreate.php' method="POST">	
				<div class="row col-md-10">
					<div class="panel panel-default panel-primary">
						<div class="panel-heading">
							<h4>Profile Information</h4>
						</div>
						
						<div class="panel-body" style="padding-left:30px;">
										
							<div class="col-lg-11 forms">
							<!-- Activity -->
								<div class="form-group">
									<label class="control-label" for="inputActivity">Activity</label>
									<select class="form-control" required="required" id="inputActivity" name="activity">
										<option selected="selected" disabled>-- Select Activity --</option>
										<option value="Tree Planting">Tree Planting</option>
										<option value="Mangrove Planting">Mangrove Planting</option>
									</select>
								</div>
								<!-- Organization Name -->
								
								<div class="form-group">
									<label class="control-label" for="inputOrgName">Organization Name</label>
									<div class="input-group">
										<span class="input-group-btn">
											<select class="form-control" require="required" id="inputOrgName" name="orgname" onChange="showUser(this.value)">
												<option selected="selected" disabled>-- Select Organization --</option>
											<?php
												$pdo = Database::connect();
												$sql = 'SELECT * FROM organization ORDER BY orgname';
												foreach ($pdo->query($sql) as $row) {
													echo '<option value="'. $row['orgid'] . '" >' . $row['orgname'] . '</option>';
												}
												Database::disconnect();
											?>
											</select>
											<button class="btn btn-primary " type="button" data-toggle="modal" data-target="#myModal" rel="tooltip" title="Add Organization" data-placement="top" style="margin-left:5px;">
												<span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
											</button>
										</span>
									</div>
								</div>

								<script type="text/javascript">
									function showUser(str) {
										if (str == "") {
											document.getElementById("orgprofile").innerHTML = "";
											return;
										} else { 
											if (window.XMLHttpRequest) {
												// code for IE7+, Firefox, Chrome, Opera, Safari
												xmlhttp = new XMLHttpRequest();
											} else {
												// code for IE6, IE5
												xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
											}
											xmlhttp.onreadystatechange = function() {
												if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
													document.getElementById("orgprofile").innerHTML = xmlhttp.responseText;
												}
											};
											xmlhttp.open("GET","getuser.php?id="+str,true);
											xmlhttp.send();
										}
									}
								</script>
								<script>
									$(document).ready(function(){
										$('[data-toggle="tooltip"]').tooltip();   
									});
								</script>
								
								<div id="orgprofile">
								
								
									<!-- Organization Type -->
									<div class="form-group">
										<label class="control-label" for="inputActivity">Organization Type</label>
										<input type="text" class="form-control" required="required" id="inputActivity" name="type" placeholder="Organization Type" >
									</div>
													
									<!-- Address -->
									<div class="form-group">
										<label for="inputAddress">Organization Address</label>
										<input type="text" class="form-control" required="required" id="inputAddress" name="address" placeholder="Organization Address" >
									</div>
	
									<!-- Contact Person -->
									<div class="form-group">
										<label for="inputPerson">Contact Person</label>
										<input type="text" class="form-control" required="required" id="inputPerson" name="person" placeholder="Contact Person">
									</div>
									
									<!-- Contact Number -->
									<div class="form-group">
										<label for="inputNumber">Contact Number</label>
										<input type="text" class="form-control" required="required" id="inputNumber" name="number" placeholder="Contact Number">
									</div>
								</div>
								
								<!-- Remarks -->
								<div class="form-group">
									<label for="inputProfileRemark">Remarks:</label>
									<textarea class="form-control" id="inputProfileRemark" rows="6" name="remark" placeholder="Any Remarks?"></textarea>
								</div>								
							</div>
						</div>
					</div>
				</div>		

				
				<div class="row col-md-10">	

					<div class="panel panel-default panel-primary">
						<div class="panel-heading"><h4>Schedule</h4></div>
						<div class="panel-body">
							<div class="col-md-11">
								<div class="row input_fields_wrap">
									<button class="btn add_field_button btn-primary" style="margin-bottom:15px;"><span class="glyphicon glyphicon-calendar"></span>&nbsp;Add Schedule</button>
									<div class="row">
										<div class="col-md-5"><strong>Date Schedule</strong></div>
										<div class="col-md-3"><strong>Time Start</strong></div>
										<div class="col-md-3"><strong>Time End</strong></div>
										<div class="col-md-1"></div>
									</div>
									<div class="row" style="margin-top:5px">
										<div class="col-md-5"><input type="text" class="form-control" id = "inputDateIssueR" name="SCHED_ARR[]" required="required"></div>
										<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputDateIssueR').datepicker({
												format: "yyyy-mm-dd"
											});  
										
										});
									</script>
										<div class="col-md-3"><input type="text" class="form-control" id= "timeStart" name="STIME_ARR[]" required="required" placeholder = "HH:MM"></div>
										<div class="col-md-3"><input type="text" class="form-control" name="ETIME_ARR[]" required="required"></div>
										<div class="col-md-1"></div>
									</div>
								</div>
							</div>
						</div> <!-- end of body panel -->
					</div>
					<!-- javascript for dyanamically add forms -->
					<script>
						$(document).ready(function() {
							var max_fields      = 10; //maximum input boxes allowed
							var wrapper         = $(".input_fields_wrap"); //Fields wrapper
							var add_button      = $(".add_field_button"); //Add button ID
							
							var x = 1; //initlal text box count
							$(add_button).click(function(e){ //on add input button click
								e.preventDefault();
								if(x < max_fields){ //max input box allowed
									x++; //text box increment
									$(wrapper).append('<div class="row" style="margin-top:5px">'
										+ '<div class="col-md-5"><input type="text" class="form-control" name="SCHED_ARR[]" required="required"></div>'
										+ '<div class="col-md-3"><input type="text" class="form-control" name="STIME_ARR[]" required="required"></div>'
										+ '<div class="col-md-3"><input type="text" class="form-control" name="ETIME_ARR[]" required="required"></div>'
										+ '<div class="col-md-1"><button type="button" class="btn btn-danger remove_field"><span class="glyphicon glyphicon-remove-sign"></span></button></div>'
										+ '</div>'); //add input box
								}
							});
						
							$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
								e.preventDefault(); $(this).parent('div').parent('div').remove(); x--;
							})
						});
					</script>
			
					<div class="form-actions text-center forms">
						<button type="submit" class="btn btn-success">Register</button>
					</div>
				</div>
			</form>
		</div><!-- end of schedule -->
	</div>
	

	
	<!-- modal window -->
	<div class="modal fade" tabindex="-1" role="dialog" id="myModal" style="margin-top:20px;font-size:14px;">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header alert-info">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Add New Organization</h4>
				</div>
				
				
				<form class="form-horizontal" role="form" action='./php/organizationCreateModal.php' method="POST">
					<div class="modal-body">
						<div class="row" style="margin:0 25px;">
							
							
										
							<!-- Organization Name -->
							<div class="form-group">
								<label for="inputOrgName">Name</label>
								<input type="text" class="form-control" required id="inputOrgName" name="orgname" placeholder="Organization Name">
							</div>
							
							<!-- Organization Type -->
							<div class="form-group">
							<label class="control-label" for="inputActivity">Type of Organization</label>
								<select class="form-control" required="required" id="inputActivity" name="orgtype">
									<option selected="selected" disabled>-- Select Organization Type --</option>
									<option value="Government Agency">Government Agency</option>
									<option value="Non-Government Organization">Non-Government Organization</option>
									<option value="Private Company">Private Company</option>
									<option value="Public Schools">Public Schools</option>
									<option value="Private Schools">Private Schools</option>
									<option value="Individual Volunteer">Individual Volunteer</option>
									<option value="Others">Others...</option>
								</select>
							</div>
					
							<!-- Address -->
							<div class="form-group">
								<label for="inputAddress">Address</label>
								<input type="text" class="form-control" required id="inputAddress" name="orgadd" placeholder="Organization Address">
							</div>
							
							<!-- Contact Person -->
							<div class="form-group">
								<label for="inputPerson">Contact Person</label>
								<input type="text" class="form-control" required="required" id="inputPerson" name="orgcperson" placeholder="Contact Person">
							</div>
							
							<!-- Contact Number -->
							<div class="form-group">
								<label for="inputNumber">Contact Number</label>
								<input type="text" class="form-control" required="required" id="inputNumber" name="orgcnum" placeholder="Contact Number">
							</div>
						</div>	
					</div>
		  
					<div class="modal-footer">
						
						<button type="submit" class="btn btn-primary">Save</button>
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</form>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>
</body>
</html>


<?php /*
	<!-- Status -->
	<div class="form-group">
		<label class="radio-inline"><input type="radio" name="optradio">Pending</label>
		<label class="radio-inline"><input type="radio" name="optradio">Done</label>
		<label class="radio-inline"><input type="radio" name="optradio">Cancelled</label>
		<label class="radio-inline"><input type="radio" name="optradio">Postponed</label>
	</div>
	<!-- Remarks -->
	<div class="form-group">
		<label for="inputProfileRemark">Remarks:</label>
		<textarea class="form-control" id="inputProfileRemark" rows="6" name="remark2" placeholder="Remarks here"></textarea>
	</div>
*/ ?>	