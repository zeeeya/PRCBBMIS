<?php
	require 'database.php';
	
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE regid = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($_POST['id']));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();
?>	
<table class="table table-condensed" style="margin-top:20px">
	<tr>
		<td><strong>Registration No.:</strong></td>
		<td><?php echo $data['regid']?></td>

		<td><strong>Address:</strong></td>
		<td><?php echo $data['orgadd']?></td>
	</tr>
	<tr>
		<td><strong>Activity Type:</strong></td>
		<td><?php echo $data['regact']?></td>
		<td><strong>Contact Person:</strong></td>
		<td><?php echo $data['regcperson']?></td>
	</tr>
	<tr>
		<td><strong>Sponsored Organization:</strong></td>
		<td><?php echo $data['orgname']?></td>
		<td><strong>Contact Number:</strong></td>
		<td><?php echo $data['regcnum']?></td>
	</tr>
	<tr>
		<td><strong>Organization Type:</strong></td>
		<td><?php echo $data['orgtype']?></td>
		<td><strong>Remarks:</strong></td>
		<td><?php echo $data['regmemo']?></td>
	</tr>
</table>

<br/>
<!-- Schedule and Participants -->
<strong>Schedule and Participants</strong>
<?php
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM schedule WHERE regid = '".$_POST['id']."'";
								
	foreach ($pdo->query($sql) as $row){
		$pdo1 = Database::connect();
		$pdo1->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql1 = "SELECT * FROM participants WHERE schedid = '".$row['schedid']."'";
		
		echo 	'<div class="panel panel-primary">
					<div class="panel-heading">'.$row['scheddate'].', '.$row['schedtime'].'-'.$row['schedend'].'</div>
					<div class="panel-body">';
					echo 	'<table class="table table-condensed">
								<thead>
									<tr>
										<th class="col-sm-5">Participant(s)</th>
										<th class="col-sm-3">No. of Participants</th>
										<th class="col-sm-2">Patch</th>
										<th class="col-sm-2">No. of Planted Seeds</th>
									</tr>
								</thead>
								<tbody>';
					foreach ($pdo1->query($sql1) as $row1){
						
					echo			'<tr>
										<td>
											<input type="hidden" class="form-control" value="'.$row1['partid'].'" readonly name="id[]">
											<input type="text" class="form-control" value="'.$row1['partname'].'" readonly >
										</td>
										<td>
											<input type="text" class="form-control" value="'.$row1['partnum'].'" readonly >
										</td>
										<td>';

										echo	'<select class="form-control" required="required" name="p[]">
													<option value="" disabled>-- Patch --</option>';
														
															if($data['regact'] === 'Mangrove Planting'){
																$pdo2 = Database::connect();
																$pdo2->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
																$sql2 = "SELECT * FROM tree";
																	foreach ($pdo2->query($sql2) as $row2){
																			$option = $row2['treepatch'];
																			$selected = "";
																			if($row2['treepatch'] == $row1['treepatch'])
																				$selected = 'selected="selected"';
																			echo '<option value="'.$row2['treepatch'].'" '.$selected.' >'.$option.'</option>';
																	}
																			
																Database::disconnect();
															}else{
																$pdo2 = Database::connect();
																$pdo2->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
																$sql2 = "SELECT * FROM treeplanting";
																	foreach ($pdo2->query($sql2) as $row2){
																			$option = $row2['treepatch'];
																			$selected = "";
																			if($row2['treepatch'] == $row1['treepatch'])
																				$selected = 'selected="selected"';
																			echo '<option value="'.$row2['treepatch'].'" '.$selected.' >'.$option.'</option>';
																	}
																			
																Database::disconnect();
															}
														
										echo	'</select>';
										
					echo				'</td>
										<td><input type="number" class="form-control" min="1" max="9999" required="required" name="treeqty[]" value="'.$row1['treeqty'].'"></td>
									</tr>';
					}
					echo		'</tbody>
							</table>';
		echo		'</div>
				</div>';
		Database::disconnect();		
	}
	
	Database::disconnect();
?>


