<?php 
include('php/login_success.php'); 
include('php/links.php');
require 'database.php';
?>

<?php
	$id = $_GET['id'];
	
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM budget where budcode = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();

	function getParticipantsNo($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM schedule WHERE regid = '".$id."'";
		
		$total_no_of_participants = 0;
		foreach ($pdo->query($sql) as $dataSched) {
			$sql = 'SELECT * FROM participants WHERE schedid = '.$dataSched['schedid'];
				foreach ($pdo->query($sql) as $dataPart) {
					$total_no_of_participants += $dataPart['partnum'];
				}
			}
		Database::disconnect();
			
		if($total_no_of_participants > 0){
			return $total_no_of_participants;
		}else{
			return '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;"><strong>Attention! </strong>Please enter participants <a href="view_schedule.php?id='.$_GET['id'].'" class="alert-link">Click Here!</a></div>';
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- Modal for error -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:10%">
		<div class="modal-content">
			<div class="modal-header btn-danger">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">System Error</h4>
			</div>
			<div class="modal-body content" id="errormodal">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
			</div>
		</div>
	</div>
</div>


<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Budget</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid content">
	
	<div class="row">
		<div class="col-sm-12" id="dateDisplay"></div>
		<div class="col-sm-12" id="clockDisplay"></div>
	</div>
	<br />
	<script type="text/javascript" language="javascript">
		function renderTime(){
			
			var currentTime = new Date();
			var diem = "AM";
			var month = currentTime.getMonth() + 1;
			var year = currentTime.getFullYear();
			var day = currentTime.getDate();
			var h = currentTime.getHours();
			var m = currentTime.getMinutes();
			var s = currentTime.getSeconds();
			
			if(h == 0){
				h=12;
			}else if(h > 12){
				h = h -12;
				diem = "PM";
			}
			
			if(h < 10){
				h = "0"+ h;
			}
			if(m < 10){
				m = "0"+ m;
			}
			if(s < 10){
				s = "0"+ s;
			}
			
			var myClock = document.getElementById('clockDisplay');
			myClock.textContent = "Time: " + h + ":" + m + ":" + s + " " + diem;
			
			var myDate = document.getElementById('dateDisplay');
			myDate.textContent = "Date: " + month + "/" + day + "/" + year;
			setTimeout('renderTime()', 1000);
		}
		renderTime();
	</script>

	<div class="row">
		<div class="col-sm-6" >
			<div class="panel panel-primary">
			
				<div class="panel-heading">
					<h3 class="panel-title"><strong>Budget Proposal</strong></h3>
				</div>
				<div class="panel-body">

					<!-- Budget Code -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="budcode">Budget Code</label></div>
						<div class="col-xs-7">
							<input type="text" class="form-control" required="required" id="budcode" name="budget_code" value="<?php echo $id; ?>" readonly >
						</div>
					</div>
					
					<!-- Activity Code -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="regOption">Registration Code</label></div>
						<div class="col-xs-7">
							<input type="text" class="form-control" required="required" id="regOption" name="activity_budget" value="<?php echo $data['regid']; ?>" readonly >
						</div>
					</div>
					
					<!-- Subject of the Budget -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="inputSubject">Subject of the Budget</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="inputSubject" name="subject_budget" value="<?php echo $data['budsub']; ?>" readonly ></div>
					</div>

					<!-- Date Issue -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="inputDateIssue">Date Issue</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="inputDateIssue" name="dateissueb" placeholder="Date Issue" value='<?php echo date("m/d/Y"); ?>' readonly></div>
					</div>
										
					<div class="panel panel-info">
						<div class="panel-heading">
							<h3 class="panel-title">Registration Details</h3>
						</div>
						<div class="panel-body" id="registrationPanel">
							<?php
								$pdo = Database::connect();
								$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								//SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid
								$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE registration.regid = ?";
								$q = $pdo->prepare($sql);
								$q->execute(array($data['regid']));
								$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
								Database::disconnect();
							?>	

							
							<div class="table-responsive">
								<table class="table">
									<tbody>
										<tr>
											<td><strong>Organization</strong></td>
											<td><?php echo $dataOrg['orgname'] ?></td>					
										</tr>
									
										<tr>
											<td><strong>Address</strong></td>
											<td><?php echo $dataOrg['orgadd'] ?></td>					
										</tr>
										
										<tr>
											<td><strong>Type of Activity</strong></td>
											<td><?php echo $dataOrg['regact'] ?></td>					
										</tr>
								
										<tr>
											<td><strong>Organization Type</strong></td>
											<td><?php echo $dataOrg['orgtype'] ?></td>					
										</tr>
								
										<tr>
											<td style="vertical-align:text-top"><strong>No. of Participants</strong></td>
											<td><?php echo getParticipantsNo($dataOrg['regid']) ?></td>					
										</tr>
										
										<tr>
											<td><strong>Contact Person</strong></td>
											<td><?php echo $dataOrg['regcperson'] ?></td>					
										</tr>
										
										<tr>
											<td><strong>Contact Number</strong></td>
											<td><?php echo $dataOrg['regcnum'] ?></td>					
										</tr>
										
										<tr>
											<td style="vertical-align:text-top"><strong>Remarks</strong></td>
											<td style="vertical-align:text-top"><?php echo $dataOrg['regmemo'] ?></td>					
										</tr>
										
										<tr>
											<td style="vertical-align:text-top"><strong>Schedule(s)</strong></td>
											<td style="vertical-align:text-top">
												<?php
													$pdo = Database::connect();
													$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
													$sql = "SELECT * FROM schedule WHERE regid = '".$data['regid']."'";
															
														foreach ($pdo->query($sql) as $row){
															echo $row['scheddate'].'<br />';
														}
														
													Database::disconnect();
												?>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							
							
							
						</div>
					</div>
				</div>
			</div>

		</div>
		<div class="col-sm-6" >
			<div class="panel panel-success">
				<div class="panel-heading">
					<h3 class="panel-title"><strong>Items</strong></h3>
				</div>
			  
				<div class="panel-body">
					
					<div class="row">
						<div class="col-md-12">
							
								<div class="col-xs-7">
									<label for="itemOption">Item Name:</label>
									<select class="form-control" required="required" id="itemOption" name="activity_budget">
										<option value="0" selected disabled>-- Select Item --</option>
										<?php
											$pdo = Database::connect();
											$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
											$sql = "SELECT * FROM item";
												
											foreach ($pdo->query($sql) as $row){
												$option = $row['itemname'];
												echo '<option value="'.$row['itemcode'].'">'.$option.'</option>';
											}
										
											Database::disconnect();
										?>
									</select>
								</div>
								
								<div class="col-xs-4">
									<label for="quantity">Quantity:</label>
									<input type="text" class="form-control" id="quantity">
								</div>
							
								<div class="col-xs-1" >
									<button type="button" class="btn btn-danger" id="addItem" style="position: relative; bottom:-25px;left:-25px"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span></button>
								</div>
							
						</div>
					</div>
				
				
					<br />
				
					<!--- this div is used to display item -->
					<div class="row" id='displayItem'>
						<form class="form-inline" role="form">
							<div class="form-group">
								<input type="hidden" class="form-control" id="codeItem" value=''>
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="nameItem" value=''>
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="unitItem" value=''>
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="priceItem" value=''>
							</div>
						</form>
					</div>

				<!--- this div is used to display item error-->				
				<div class="row" id='displayItemError'></div>
				
				<div class="row">
					<div class="col-md-12">
						<table class="table table-bordered" id="myTable">
							<thead>
								<tr>
									<th class="col-sm-2">Code</th>
									<th class="col-sm-4">Name</th>
									<th class="col-sm-2">Quantity</th>
									<th class="col-sm-2">Unit</th>
									<th class="col-sm-2">Price</th>
									<th class="col-sm-1"></th>
								</tr>
							</thead>
							<tbody>
								<?php
									$pdo = Database::connect();
									$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
									$sql = "SELECT * FROM itembudget WHERE budcode = '".$id."'";
									$total = 0;	
									foreach ($pdo->query($sql) as $row){
										echo '<tr><td>'.$row['itembudid'].'</td>';
										echo '<td>'.$row['itemname'].'</td>';
										echo '<td>'.$row['itemquantity'].'</td>';
										echo '<td>'.$row['itemunit'].'</td>';
										echo '<td>'.$row['itemprice'].'</td>';
										echo '<td><button class="btn btn-default btn-xs removeItem"><span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span></button></td></tr>';
										$total = $total + $row['itemprice'];
									}
									
									Database::disconnect();
								?>
							</tbody>
						</table>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<div class="col-md-8 text-right"><label for="total">Total Amount in Php.</label></div>
						<div class="col-md-4"><input type="text" class="form-control" id="total" value="<?php echo number_format($total,2); ?>"readonly></div>
					</div>
				</div>
				
				</div>
			</div>
		</div>
	</div>
	<div class="row text-center">
		<div class="col-md-12">
			<button type="button" class="btn btn-primary" id="saveButton">Resubmit</button>
			<a type="button" class="btn btn-info" href="view_budget.php">Back</a>
		</div>
	</div>
	
<script>
$(document).ready(function(){
	$('#regOption').change(function(){
		
		var d = "id="+$( "#regOption" ).val();
		console.log(d);
		$.ajax({
			url   : 'budget_registration_query.php',
			data  : d,
			type : 'POST',
			success : function(data){
                $('#registrationPanel').html(data);
			}
		})
	})
})

$(document).ready(function(){
	$('#itemOption').change(function(){
		
		var d = "id="+$( "#itemOption" ).val();
		$.ajax({
			url   : 'item_query.php',
			data  : d,
			type : 'POST',
			success : function(data){
                $('#displayItem').html(data);
			}
		})
	})
})

$(document).ready(function(){
	$('#addItem').click(function(){
		
		var a = '--';
		console.log(a);
		var b = $( "#nameItem" ).val();
		var c = $( "#priceItem" ).val();
		var u = $( "#unitItem" ).val();
		var q = $( "#quantity" ).val();
		
		if(a !== null  && $.isNumeric(q) && q > 0){
			
			if(itemExist(b)){
				
				var size = document.getElementById("myTable").rows.length;
				var index = 0;
				for(var i = 0;i < size;i++){
					var d = document.getElementById("myTable").rows[i].cells[1].innerHTML;
					if(d === b)
						index = i;
				}
				
				if(index > 0){
					var oldQuantity = document.getElementById("myTable").rows[index].cells[2].innerHTML;
					var oldPrice = document.getElementById("myTable").rows[index].cells[3].innerHTML;
					
					var updatedQuantity = (parseInt(oldQuantity ) + parseInt(q));
					var updatedPrice = parseFloat(c * updatedQuantity).toFixed(2);
					
					console.log(updatedQuantity);
					console.log(updatedPrice);
					
					var x = document.getElementById("myTable").rows[index].cells;
					x[2].innerHTML = updatedQuantity;
					x[4].innerHTML = updatedPrice;
					
					cleardata();
				}
			}else{
				var table = document.getElementById("myTable");
				var row = table.insertRow(1);
				
				var cell1 = row.insertCell(0);
				var cell2 = row.insertCell(1);
				var cell3 = row.insertCell(2);
				var cell4 = row.insertCell(3);
				var cell5 = row.insertCell(4);
				var cell6 = row.insertCell(5);
				
				cell1.innerHTML = a;
				cell2.innerHTML = b;
				cell3.innerHTML = q;
				cell4.innerHTML = u;
				cell5.innerHTML = parseFloat(c * q).toFixed(2);
				cell6.innerHTML = '<button class="btn btn-default btn-xs removeItem"><span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span></button>';
				
				cleardata();
			}
			
		
		}else if(a === null){
			data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Please select item first</div><br/>';
			$('#displayItemError').html(data);
		}else{
			data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Please check your quantity</div><br/>';
			$('#displayItemError').html(data);
		}
	})

})

$(document).on('click', 'button.removeItem', function () { // <-- changes
    $(this).closest('tr').remove();
	$("#total").val(getTotal());
    return false;
 });


function cleardata(){
	$("#quantity").val("");
	$("#codeItem").val("");
	$("#nameItem").val("");
	$("#priceItem").val("");
	$("#unitItem").val("");
	
	document.getElementById("itemOption").selectedIndex = "0";
	$("#total").val(getTotal());
	
	$('#displayItemError').html("");
}

function itemExist(itemName){
	
	var size = document.getElementById("myTable").rows.length;
	var exist = false;
	for(var i = 0;i < size;i++){
		var d = document.getElementById("myTable").rows[i].cells[1].innerHTML;
		if(d === itemName)
			exist = true;
	}
	
	return exist;
		
}

function getTotal(){
	
	var size = document.getElementById("myTable").rows.length;
	var total = 0;

	if(size > 0)
		for(var i = 1;i < size;i++){
			var d = document.getElementById("myTable").rows[i].cells[4].innerHTML;
			total += parseFloat(d);
		}
	
	return parseFloat(total).toFixed(2);
		
}

//Getting the data from the table
function storeTblValues()
{
    var TableData = new Array();

    $('#myTable tr').each(function(row, tr){
        TableData[row]={
            "id" : $(tr).find('td:eq(0)').text()
            , "name" :$(tr).find('td:eq(1)').text()
            , "quantity" : $(tr).find('td:eq(2)').text()
            , "unit" : $(tr).find('td:eq(3)').text()
			, "price" : $(tr).find('td:eq(4)').text()
        }    
    }); 
    TableData.shift();  // first row will be empty - so remove
    return TableData;
}

$(document).ready(function(){
	$('#saveButton').click(function(){
		
		
		var TableData;
		TableData = JSON.stringify(storeTblValues());
		a = $("#budcode").val();
		d = $("#total").val();
		
		if($.trim(d) == '' || d == 0){
			data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><span class="glyphicon glyphicon-alert" aria-hidden="true" style="margin-right:10px"></span>No item(s) in the table</div><br/>';
			$('#errormodal').html(data);
			$('#myModal').modal('show');
		}else{

			$.ajax({
				url   : 'php/budgetUpdate.php?id='+$('#budcode').val(),
				data  : {pTableData: TableData, budcode: a, totalamount: d},
				type : 'POST',
				success : function(data){
					$('#displayItem').html(data);
					$('#errormodal').html('');
					window.location = "view_budget.php";
				}
			})
		}
	})
})

</script>

<!-- Tooltip -->
<script>
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();
		$('.btn').tooltip();
	});
</script>

<div class="row">
	<?php
	include('footer.php'); 
	?>
</div>
</body>
</html>