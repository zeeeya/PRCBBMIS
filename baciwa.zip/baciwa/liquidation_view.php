<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: view_liquidation.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM liquidation where liquidationid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/sidebar.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</head>
<body>
<div>

    <div class="navbar navbar-default navbar-fixed-top" style= "z-index:99999">
      <div class="container">
        <div class="navbar-header">          	
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <a class="navbar-brand" href="home.php"><img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" /></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href=" <?php  echo($Home) ?>">HOME</a></li>
            <li><a href=" <?php  echo($Registration) ?>">REGISTRATION</a></li>
            <li><a href=" <?php  echo($Budget) ?>">BUDGET</a></li>
            <li><a href=" <?php  echo($Liquidation) ?>">LIQUIDATION</a></li>
            <li><a href=" <?php  echo($Miscellaneous) ?>">MISCELLANEOUS</a></li>
            <li><a href=" <?php  echo($Report) ?>">REPORTS</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
        	<li><a href=" <?php echo($Signup) ?>"><span class="glyphicon glyphicon-user"></span> Add Account</a></li>
        	<li><a href=" <?php echo($Logout) ?>"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      	  </ul>
          
        </div>
      </div>
    </div>

    <div class="jumbotron home-header">
    	<table>
        	<tr>
            	<td><img src="img/baciwa_thesis.png" alt="thesis-logo"/></td>
            	<td>
        			<h1>Bacolod City Water District</h1> 
  					<p>Planting Activity Management System</p>        
                </td>                
            </tr>
  		</table> 
	</div>

</div>

	<div class="container-fluid main-wrapper">

		<div class="row">
			<div class="container-fluid menu-title">
			<h1>Liquidation</h1>
			</div>
			<div class="row">
				<div class="col-lg-3 menu-sidebar">
					<!-- side bar -->
					<div class="sidebar-nav">
						  <div class="navbar navbar-default" role="navigation">
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							  </button>
							  <span class="visible-xs navbar-brand" style="padding-top:16px;">Menu</span>
							</div>
							<div class="navbar-collapse collapse sidebar-navbar-collapse">
							  <ul class="nav navbar-nav">
								<li><a href="liquidation.php">New Liquidation</a></li>
								<li><a href="view_liquidation.php">View Liquidation List</a></li>
							  </ul>
							</div><!--/.nav-collapse -->
						  </div>
					</div>
				</div>
				
				<!-- start of Details -->
				<div class="col-lg-9 main-content">
					
                    <h3>Liquidation Details</h3>
					<br />
                     
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td><strong>Subject of Liquidation</strong></td>
									<td><?php echo $data['subjectliquidation'];?></td>					
								</tr>
								<tr>
									<td><strong>Activity</strong></td>
									<td><?php echo $data['activityliquidation'];?></td>					
								</tr>
								<tr>
									<td><strong>Date of Issue - Liquidation</strong></td>
									<td><?php echo $data['dateissueliquidation'];?></td>					
								</tr>
								<tr>
									<td><strong>Date of Activity</strong></td>
									<td><?php echo $data['dateactivityliquidation'];?></td>					
								</tr>
								<tr>
									<td><strong>Status</strong></td>
									<td><?php echo $data['statusliquidation'];?></td>					
								</tr>
								<tr>
									<td><strong>Remarks</strong></td>
									<td><?php echo $data['remarksliquidation'];?></td>					
								</tr>								
							</tbody>
						</table>
					</div>
					
					<div class="form-actions text-center">
                        <a class="btn btn-info" href="view_liquidation.php">Back</a>
                    </div>
			

			</div>
		</div>
	</div>

</body>
</html>