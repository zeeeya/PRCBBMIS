<?php
	$connection = mysqli_connect("localhost", "root", "", "dcaems");
	if(isset($_POST['submit'])){
			$username = mysqli_real_escape_string($connection, $_POST['username']);
			$password = mysqli_real_escape_string($connection, $_POST['password']);
			$query = "SELECT * FROM account WHERE username = '$username' AND password = '$password'";
			$result_set = mysqli_query($connection, $query);
			$check_user = mysqli_num_rows($result_set);
			if($check_user == 1){
				//$_SESSION [‘user_email’] = $username;
				header("Location: ../dcaems/check.php");
			}else {
				header("Location: ../dcaems/index.php");
			}
		
		
		
	}
?>
<html class="full">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>

    <link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="css/the-big-picture.css" rel="stylesheet">
</head>
<body>
</br></br></br></br></br></br>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">DENR Citizen Action Environmental Management System</h3>
                    </div>
                    <div class="panel-body">
                        <form action=""	 role="form" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="username" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="" required>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
								<input type="submit" name="submit" value="Login" class="btn btn-lg btn-success" />
								<a href="signup.php" class="btn btn-lg btn-success">Sign Up</a>
								<a href="Index.php" class="btn btn-lg">Back</a>
								
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <script src="js/jquery-2.1.4.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>

</html>
