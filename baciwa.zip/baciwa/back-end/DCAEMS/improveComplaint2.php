<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Department of Environment and Natural Resources</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link href="css/logo-nav.css" rel="stylesheet">
	<link href="css/sb-admin.css" rel="stylesheet">
	<link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="css/plugins/timeline/timeline.css" rel="stylesheet">
	<link href="css/big.css" rel="stylesheet">
	<link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
</head>

<body>
	
<div id="wrapper">

        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand logo-nav" href="Back-End.php"><img src="img/name.png"></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                   
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="login.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
        </nav>
        <!-- /.navbar-static-top -->

        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!-- /input-group -->
                    </li>
              
                    <li>
                        <a href="#"></i> Complaints<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="Letter.php">List of Complaints</a>
                            </li>
                            <li>
                                <a href="complainant.php">Complainant and Violator</a>
                            </li>
							<li>
                                <a href="evidences.php">Evidences</a>
                            </li>
							<li>
                                <a href="agencies.php">Forwarded Agencies</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
					
					<li>
                        <a href="#"></i> Map<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="map.php">Complaint Status Per Area</a>
                            </li>
                            <li>
                                <a href="map1.php">Number of Complaints Per Area</a>
                            </li>
							<li>
                                <a href="map2.php">Number of Complainants Per Area</a>
                            </li>
							<li>
                                <a href="map3.php">Number of Violators Per Area</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
                    
                    <li>
                        <a href="#"></i> Sanctions and Violations<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="sanctions.php">List of Sanctions and Violations</a>
                            </li>
                            <li>
                                <a href="resolution.php">Resolution</a>
                            </li>
						</ul>
                        <!-- /.nav-second-level -->
                    </li>
					
					<li>
                        <a href="#"></i> Reports<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="Statistical.php">Statistical Report</a>
                            </li>
                            <li>
                                <a href="geotagging.php">Geo-Tagging Report</a>
                            </li>
							<li>
                                <a href="investigation.php">Investigational Report</a>
                            </li>
						</ul>
                        <!-- /.nav-second-level -->
                    </li>
					
					<li>
						<a href="hearing.php"></i> Hearing Schedule</a>
					</li>
					<li>
						<a href="cms.php"></i> CMS</a>
					</li>
					<li>
						<a href="accounts"></i> Accounts</a>
					</li>
					<li>
                    
                </ul>
                <!-- /#side-menu -->
            </div>
            <!-- /.sidebar-collapse -->
        </nav>
        <!-- /.navbar-static-side -->

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Update Complaint</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			
			<div class="row">
				<div class="col-lg-4">
					<div class="form-group">
                                            <label>Action Taken</label>
                                            <select class="form-control">
												<option></option>
                                                <option>For Your Information</option>
                                                <option>Appropriate Action</option>
                                                <option>Compliance</option>
                                                <option>Review/Comments</option>
                                                <option>Dissemination</option>
												<option>For Schedule</option>
												<option>Retype/Finalize</option>
												<option>Verify</option>
                                            </select>
                    </div>
				
					<div class="form-group">
                                            <label>Remarks</label>
                                            <textarea class="form-control" rows="10"></textarea>
                    </div>
					
				</div>
				
				
				<div class="col-lg-8">
					<div class="panel panel-default">
                        <div class="panel-heading">
                            Complainants
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Address</th>
                                            <th>Contact Details</th>
                                            <th>Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>DD/MM/YYYY </td>
                                            <td>Firstname Lastname </td>
                                            <td>Address address address </td>
                                            <td>090909090900909 </td>
                                            <td><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td>DD/MM/YYYY </td>
                                            <td>Firstname Lastname </td>
                                            <td>Address address address </td>
                                            <td>090909090900909 </td>
                                            <td><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td>DD/MM/YYYY </td>
                                            <td>Firstname Lastname </td>
                                            <td>Address address address </td>
                                            <td>090909090900909 </td>
                                            <td><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                        </tr>
										
										
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
						<div class="panel-footer">
                            <a href="newComplainant.php"><button type="button" class="btn btn-primary btn-sm">Add Complainant</button></a>
                        </div>
                    </div>
                    <!-- /.panel -->
					
					<div class="panel panel-default">
                        <div class="panel-heading">
                            Violator
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Violation</th>
                                            <th>Contact Details</th>
                                            <th>Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>Firstname LastName</td>
                                            <td>Violation violation</td>
                                            <td>09262678901</td>
                                            <td><a href="violatorProfile.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>Firstname Lastname</td>
                                            <td>Violation violation</td>
                                            <td>09262678901</td>
                                            <td><a href="violatorProfile.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>CompanyName/ComplanyRep</td>
                                            <td>Violation violation</td>
                                            <td>09262678901</td>
                                            <td><a href="violatorProfile.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
										
										<tr>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
						<div class="panel-footer">
                            <a href="newViolator.php"><button type="button" class="btn btn-primary btn-sm">Add Violator</button></a>
                        </div>
                    </div>
                    <!-- /.panel -->
				</div>
				
				<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-default">
                        <div class="panel-heading">
                            Evidences
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Item</th>
                                            <th>Owner</th>
                                            <th>Quantity</th>
                                            <th>Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>MM/DD/YYYY </td>
                                            <td>Name of Evidence </td>
                                            <td>Firstname Lastname </td>
                                            <td>Pcs/vol/mass/desity </td>
                                            <td><a href="evidences.php"><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY </td>
                                            <td>Name of Evidence </td>
                                            <td>Firstname Lastname </td>
                                            <td>Pcs/vol/mass/desity </td>
                                            <td><a href="evidences.php"><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY </td>
                                            <td>Name of Evidence </td>
                                            <td>Firstname Lastname </td>
                                            <td>Pcs/vol/mass/desity </td>
                                            <td><a href="evidences.php"><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY </td>
                                            <td>Name of Evidence </td>
                                            <td>Firstname Lastname </td>
                                            <td>Pcs/vol/mass/desity </td>
                                            <td><a href="evidences.php"><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY </td>
                                            <td>Name of Evidence </td>
                                            <td>Firstname Lastname </td>
                                            <td>Pcs/vol/mass/desity </td>
                                            <td><a href="evidences.php"><button type="button" class="btn btn-primary btn-sm">View</button> </td>
                                        </tr>
										
										
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
						<div class="panel-footer">
                            <a href="newEvidence.php"><button type="button" class="btn btn-primary btn-sm">Add Evidence</button></a>
                        </div>
                    </div>
						</div>
				</div>
				
				<div class="row">
					<div class="col-lg-12">
						<div class="panel panel-default">
                        <div class="panel-heading">
                            Hearing Schedule
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Complaint</th>
                                            <th>Venue</th>
                                            <th>Administrator</th>
                                            <th>Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>Complaint Title</td>
                                            <td>Place of the Hearing</td>
                                            <td>PENRO/EMB</td>
                                            <td><a href="hearingDetails.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>Complaint Title</td>
                                            <td>Place of the Hearing</td>
                                            <td>PENRO/EMB</td>
                                            <td><a href="hearingDetails.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>Complaint Title</td>
                                            <td>Place of the Hearing</td>
                                            <td>PENRO/EMB</td>
                                            <td><a href="hearingDetails.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
										<tr>
                                            <td>MM/DD/YYYY</td>
                                            <td>Complaint Title</td>
                                            <td>Place of the Hearing</td>
                                            <td>PENRO/EMB</td>
                                            <td><a href="hearingDetails.php"><button type="button" class="btn btn-primary btn-sm">View</button></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
						<div class="panel-footer">
                            <a href="newHearing.php"><button type="button" class="btn btn-primary btn-sm">Add Hearing</button></a>
                        </div>
                    </div>
					</div>
				</div>
				
				<a href="updatedComplaint2.php"><button type="button" class="btn btn-primary">Save</button></a>
					<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Submit</button>
					 <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Submit to</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Regional Director
                                                </label>
                                            </div>
											<div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">PENR Officer
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Information System Analyst
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">SEMS
                                                </label>
                                            </div>
											<div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Enforcement
                                                </label>
                                            </div>
											<div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Conservation and Development
                                                </label>
                                            </div>
											<div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">EMB
                                                </label>
                                            </div>
                                        </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
							
					<a href="#"><button type="button" class="btn btn-primary">Cancel</button></a>
				
				</div>
			</div>
			
			
        </div>
        <!-- /#page-wrapper -->

    </div>

	<script src="js/jquery-2.1.4.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
	<script src="js/sb-admin.js"></script>
	<script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
	<script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>
</body>
</html>