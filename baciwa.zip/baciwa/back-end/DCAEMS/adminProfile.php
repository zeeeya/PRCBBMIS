<!DOCTYPE html>
<html lang="en">
<head>
	<title>Profile</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link href="css/logo-nav.css" rel="stylesheet">
	<link href="css/sb-admin.css" rel="stylesheet">
	<link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="css/modern-business.css" rel="stylesheet">
	<link href="css/round-about.css" rel="stylesheet">
</head>

<body>
	<!-- navigation bar -->
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand logo-nav" href="Back-End.php">
					<img src="img/name.png">
				</a>
			</div>
			<div class="navbar-collapse collapse">
			<ul class="nav nav-pills">
					<li><a href="Back-End.php">Home</a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Complaint<b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="Letter.php">Letters</a></li>
						<li><a href="complainant.php">Complainants and Violators</a></li>
						<li><a href="evidences.php">Evidences</a></li>
					</ul>
				</li>
				<li><a href="back-map.php">Map</a></li>
				<li><a href="back-sanctions.php">Sanctions and Violations</a></li>
				<li><a href="report.php">Report</a></li>
				<li><a href="Index.php">View Front-End</a></li>
				<li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
			</ul>
			</div>
		</div>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<img class="img-square img-responsive" src="img/photo2.jpg">
				<h1 class="page-header">Kenji Shinoda
					<small>Enforcement Chief</small>
				</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1">
				<h4>
					Gender: 
				</h4>
			</div>
			<div class="col-lg-8">
				<h4>
					Female
				</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1">
				<h4>
					Contact Details: 
				</h4>
			</div>
			<div class="col-lg-8">
				<h4>
					708-2155
				</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1">
				<h4>
					Birthdate: 
				</h4>
			</div>
			<div class="col-lg-8">
				<h4>
					February 16, 1994
				</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1">
				<h4>
					Address: 
				</h4>
			</div>
			<div class="col-lg-8">
				<h4>
					#11 St. Gabriel Ave. Dona Juliana Subd. Bacolod City
				</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1">
				<h4>
					Occupation: 
				</h4>
			</div>
			<div class="col-lg-8">
				<h4>
					Full-Time Enforcement Chief of the Department of Environment and Natural Resource
				</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1">
				<h4>
					Citizenship: 
				</h4>
			</div>
			<div class="col-lg-8">
				<h4>
					Filipino
				</h4>
			</div>
		</div>
		</br>
		<div class="row">
		 <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Of Complaints Involved
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Complaints</th>
                                            <th>Information</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Title of Complaint</td>
                                            <td><button type="button" class="btn btn-primary btn-xs">View</button></td>
                                        </tr>
                                    </tbody>
									<tbody>
                                        <tr>
                                            <td>2</td>
                                            <td>Title of Complaint</td>
                                            <td><button type="button" class="btn btn-primary btn-xs">View</button></td>
                                        </tr>
                                    </tbody>
									<tbody>
                                        <tr>
                                            <td>3</td>
                                            <td>Title of Complaint</td>
                                            <td><button type="button" class="btn btn-primary btn-xs">View</button></td>
                                        </tr>
                                    </tbody>
									<tbody>
                                        <tr>
                                            <td>4</td>
                                            <td>Title of Complaint</td>
                                            <td><button type="button" class="btn btn-primary btn-xs">View</button></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
			</div>
	</div>
	
	<script src="js/jquery-2.1.4.js"></script>
	<script src="js/bootstrap.js"></script>
</body>
</html>