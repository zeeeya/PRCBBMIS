<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Department of Environment and Natural Resources</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link href="css/logo-nav.css" rel="stylesheet">
	<link href="css/sb-admin.css" rel="stylesheet">
	<link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="css/plugins/timeline/timeline.css" rel="stylesheet">
	<link href="css/big.css" rel="stylesheet">
	<link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
</head>

<body>
	
<div id="wrapper">

        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand logo-nav" href="Back-End.php"><img src="img/name.png"></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                   
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
        </nav>
        <!-- /.navbar-static-top -->

        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!-- /input-group -->
                    </li>
              
                    <li>
                        <a href="#"></i> Complaints<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="Letter.php">List of Complaints</a>
                            </li>
                            <li>
                                <a href="complainant.php">Complainant and Violator</a>
                            </li>
							<li>
                                <a href="evidences.php">Evidences</a>
                            </li>
							<li>
                                <a href="agencies.php">Forwarded Agencies</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
					
					<li>
                        <a href="#"></i> Map<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="map.php">Complaint Status Per Area</a>
                            </li>
                            <li>
                                <a href="map1.php">Number of Complaints Per Area</a>
                            </li>
							<li>
                                <a href="map2.php">Number of Complainants Per Area</a>
                            </li>
							<li>
                                <a href="map3.php">Number of Violators Per Area</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
                    
                    <li>
                        <a href="#"></i> Sanctions and Violations<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="sanctions.php">List of Sanctions and Violations</a>
                            </li>
                            <li>
                                <a href="resolution.php">Resolution</a>
                            </li>
						</ul>
                        <!-- /.nav-second-level -->
                    </li>
					
					<li>
                        <a href="#"></i> Reports<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="Statistical.php">Statistical Report</a>
                            </li>
                            <li>
                                <a href="geotagging.php">Geo-Tagging Report</a>
                            </li>
							<li>
                                <a href="investigation.php">Investigational Report</a>
                            </li>
						</ul>
                        <!-- /.nav-second-level -->
                    </li>
					
					<li>
						<a href="hearing.php"></i> Hearing Schedule</a>
					</li>
					<li>
						<a href="cms.php]"></i> CMS</a>
					</li>
					<li>
						<a href="accounts"></i> Accounts</a>
					</li>
					<li>
                    
                </ul>
                <!-- /#side-menu -->
            </div>
            <!-- /.sidebar-collapse -->
        </nav>
        <!-- /.navbar-static-side -->

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add New Schedule</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			<div class="row">
				<div class="col-lg-4">
					<div class="form-group">
                                            <label>Date/Time</label>
                                            <input class="form-control" placeholder="Date/Time">
					</div>
					<div class="form-group">
                                            <label>Complaint</label>
                                            <button type="button" class="btn btn-primary">Select</button>
                    </div>
					
				</div>
			</div>
				
			<div class="row">
				<div class="col-lg-6">
					<div class="panel panel-default">
                        <div class="panel-heading">
                            Participating Complainants
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Contact #</th>
                                            <th>Profile</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										<tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										<tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										<tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
						<div class="panel-footer">
                            <a href="newComplainant.php"><button type="button" class="btn btn-primary btn-sm">Add Complainant</button></a>
                        </div>
                    </div>
                    <!-- /.panel -->
				</div>
					
				<div class="col-lg-6">
					<div class="panel panel-default">
                        <div class="panel-heading">
                            Participating Violators
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Contact #</th>
                                            <th>Profile</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										<tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										<tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
										
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
						<div class="panel-footer">
                            <a href="newViolator.php"><button type="button" class="btn btn-primary btn-sm">Add Violator</button></a>
                        </div>
                    </div>
                    <!-- /.panel -->
				</div>					
			</div>
					<a href="HearingSchedule.php"><button type="button" class="btn btn-primary">Save</button></a>
					<a href="#"><button type="button" class="btn btn-primary">Cancel</button></a>
			
			
			</div>
				
				</div>
			</div>

        </div>
        <!-- /#page-wrapper -->

    </div>

	<script src="js/jquery-2.1.4.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
	<script src="js/sb-admin.js"></script>
	<script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
	<script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>
</body>
</html>