<?php
	$connection = mysqli_connect("localhost", "root", "", "dcaems");
	if(isset($_POST['submit'])){
		$username = mysqli_real_escape_string($connection, $_POST['username']);
		$password = mysqli_real_escape_string($connection, $_POST['password']);
		$fname = mysqli_real_escape_string($connection, $_POST['fname']);
		$lname = mysqli_real_escape_string($connection, $_POST['lname']);
		$address = mysqli_real_escape_string($connection, $_POST['address']);
		$contact = mysqli_real_escape_string($connection, $_POST['contact']);
		$query = "INSERT INTO account (username, password, type) VALUES ('$username', '$password', 'User')";
		$result_set = mysqli_query($connection, $query);
		$query2 = "INSERT INTO complainant (fname, lname, address, contactNum) VALUES ('$fname', '$lname', '$address', '$contact')";
		$result_set2 = mysqli_query($connection, $query2);
		if($result_set && $result_set2){
			echo "<div id=\"modal\" class=\"modal hide\">
				<div class=\"modal-header\">
					<h2>You have been registered</h2>
				</div>
			</div>";
		}
	}
?>

<html class="full">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sign Up</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="css/logo-nav.css" rel="stylesheet">
	<link href="css/big.css" rel="stylesheet">
	<link href="css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="css/plugins/timeline/timeline.css" rel="stylesheet">
	<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="css/sb-admin.css" rel="stylesheet"> 
	<link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
</head>

<body>

	<!-- navigation bar -->
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand logo-nav" href="index.php">
					<img src="img/name.png">
				</a>
			</div>
			<div class="navbar-collapse collapse">
			<ul class="nav nav-pills">
				<li><a href="Index.php">Home</a></li>
				<li><a href="complaint.php">Complaint</a></li>
				<li><a href="map.php">Map</a></li>
				<li><a href="sanction.php">Sanctions and Violations</a></li>
				<li><a href="about.php">About Us</a></li>
				<li class= "active"><a href="Login.php">Sign In</a></li>
			</ul>
			</div>
		</div>
	</nav>

	
<div class="container">
	<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Sign Up</h1>
                </div>
                <!-- /.col-lg-12 -->
    </div>
	<div class="row">
		<form action=""	 role="form" method="post">
		<div class="col-lg-4">
			<div class="form-group">
                <label>Username</label>
                <input class="form-control" placeholder="Username" name="username">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
                <label>Password</label>
                <input class="form-control" placeholder="password" name="password" type="password">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
                <label>First Name</label>
                <input class="form-control" placeholder="First Name" name="fname">
			</div>
			<div class="form-group">
                <label>Last Name</label>
                <input class="form-control" placeholder="Last Name" name="lname">
			</div>
			<div class="form-group">
				<label>Address</label>
                <input class="form-control" placeholder="Address" name="address">
			</div>
		</div>
	</div>	
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
                <label>Contact Number</label>
                <input class="form-control" placeholder="Contact Number" name="contact">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-4">
			<input type="submit" name="submit" value="Sign Up" class="btn btn-lg btn-primary"/>
			<a href="Index.php" class="btn btn-lg btn-primary">Cancel</a>
		</div>
		</form>
	</div>	
</div>

	<script src="js/jquery-2.1.4.js"></script>
	<script src="js/bootstrap.js"></script>
</body>
</html>