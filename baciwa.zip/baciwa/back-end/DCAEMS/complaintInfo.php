<!DOCTYPE html>
<html lang="en">
<head>
	<title>DENR Citizen Action Environmental Management System</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="css/logo-nav.css" rel="stylesheet">
	<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="css/plugins/social-buttons/social-buttons.css" rel="stylesheet">
</head>

<body>
	<!-- navigation bar -->
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand logo-nav" href="index.php">
					<img src="img/name.png">
				</a>
			</div>
			<div class="navbar-collapse collapse">
			<ul class="nav nav-pills">
				<li><a href="Back-End.php">Home</a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Complaint<b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="Letter.php">Letters</a></li>
						<li><a href="complainant.php">Complainant and Violator</a></li>
						<li><a href="evidences.php">Evidences</a></li>
					</ul>
				</li>
				<li><a href="back-map.php">Map</a></li>
				<li><a href="back-sanctions.php">Sanctions and Violations</a></li>
				<li><a href="report.php">Report</a></li>
				<li><a href="Index.php">View Front-End</a></li>
				<li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
			</ul>
			</div>
		</div>
	</div>
	
<div class="container">	
	<div class="row">
		<div class="col-lg-8">
			<h1 class="page-title">
				Manufacturing of Furniture Shops  
			</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-2">
			<h4 class="page-body">
				Complaintant:  
			</h4>
		</div>
		<div class="col-lg-6">
			<h4 class="page-body">
				Firstname LastName  
			</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-2">
			<h4 class="page-body">
				Nature:  
			</h4>
		</div>
		<div class="col-lg-6">
			<h4 class="page-body">
				Wood, Land  
			</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-2">
			<h4 class="page-body">
				Status:  
			</h4>
		</div>
		<div class="col-lg-2">
			<select class = "form-control">
				<option>Pending</option>
				<option>Verified</option>
				<option>Verified by Regional Director</option>
				<option>Discarded</option>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-2">
			<h4 class="page-body">
				Photo:  
			</h4>
		</div>
		<div class="col-lg-6">
			<h4 class="page-body">
				N/A  
			</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-2">
			<h4 class="page-body">
				Description:  
			</h4>
		</div>
		<div class="col-lg-6">
			<h4 class="page-body">
			This has reference to the complaint of concerned citizens of Brgy. Punta Taytay, Bacolod City against the construction activities of Mr Froncis Ray Cabuga within his property in the aforesaid barangay.
			</h4>
		</div>
	</div>
	</br>
	<div class="row">
		<div class="col-lg-3">
			<div class="form-group">
				<label>Send To: </label>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Regional Director
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Information Systems Analyst
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">SEMS
					</label>
				</div>
				<div class="checkbox">	
					<label>
						<input type="checkbox" value="">Enforcement
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Conservation and Development
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">EMB
					</label>
				</div>
			</div>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
				<label>Action Taken: </label>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">For Your Information
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Appropriate Action
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Compliance
					</label>
				</div>
				<div class="checkbox">	
					<label>
						<input type="checkbox" value="">Review/Comments
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Please Attend/Take Up With Me
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Dissemination
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">For Schedule
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Retype/Finalize
					</label>
				</div>
				<div class="checkbox">
					<label>
						<input type="checkbox" value="">Verify
					</label>
				</div>
			</div>
		</div>
		<div class="col-lg-3">
			<label>Remarks: </label>
			<textarea class="form-control" rows="5"></textarea>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<button type = "submit" class = "btn btn-primary">Submit</button>
			<button type = "clear" class = "btn btn-default" > Clear </button>
		</div>
	</div>
</div>	
	
<script src="js/jquery-2.1.4.js"></script>
	<script src="js/bootstrap.js"></script>
</body>
</html>	