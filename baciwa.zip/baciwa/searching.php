<?php 
include('php/login_success.php'); 
include('php/links.php');
include('database.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/leaflet.markercluster.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css' rel='stylesheet' />
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css' rel='stylesheet' />

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
		<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
		<style>
			#map 
			{ 	margin:3% 3%;
				width:95%; 
				height:70%; 
			}
		</style>


	 </head>
	<body>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		<!-- <div style="margin-left:350px" id='map'></div> -->
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredregistration.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			
			</div>

		</div>
		<?php

			$str = $_POST['searchInput'];
			//echo $str;
			$item = array();
			
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid";
			foreach ($pdo->query($sql) as $row) {
				if($str === $row['orgname']){
					$sql2 = "SELECT * FROM schedule INNER JOIN participants ON schedule.schedid = participants.schedid WHERE regid = '".$row['regid']."'";
					foreach ($pdo->query($sql2) as $data) {
						if(!empty($data['treepatch'])){
							$item[] = $data['treepatch'];
						}
					}
				}
			}
			
			$result = array_unique($item);
			Database::disconnect();

		?>
		
		<script type="text/javascript">
			var ar = <?php echo json_encode($result) ?>;
		</script>
		
		<div class="col-md-9">
			<br />
			<form  method="post" action="searching.php"  id="searchform"> 
			<div class="row">
				<div class="col-lg-12">
					<div class="input-group">
					  <input type="text" class="form-control" placeholder="Search Organization..." name="searchInput">
					  <span class="input-group-btn">
						<button class="btn btn-default" type="submit">Go!</button>
					  </span>
					</div><!-- /input-group -->
				</div><!-- /.col-lg-6 -->
			</div>	
			</form>
			<div id='map'></div>
		</div>
	</div>
<style>
.map-legend ul {
  list-style: none;
  padding-left: 0;
  }
.map-legend .swatch {
  width:20px;
  height:20px;
  float:left;
  margin-right:10px;
  }
.leaflet-popup-close-button {
  display: none;
  }
.leaflet-popup-content-wrapper {
  pointer-events: none;
  }
</style>

<script src='php/treeplanting.php'></script>
	
<script>
L.mapbox.accessToken = 'pk.eyJ1Ijoiam95bWVyaWxsIiwiYSI6ImNpaWgwcW5ndTAycTR2dG0xZnlocHppbG4ifQ.XIsgAOt_JunkNd-8HmZ6-Q';
var map = L.mapbox.map('map', 'mapbox.satellite').setView([10.66, 123.148], 16);

var popup = new L.Popup({ autoPan: false });

  var statesLayer = L.geoJson(treepatches,  {
      style: getStyle,
      onEachFeature: onEachFeature
  }).addTo(map);

  function getStyle(feature) {
      return {
          weight: 2,
          opacity: 0.1,
          color: 'black',
          fillOpacity: 0.7,
          fillColor: getColor(feature.properties.density),
      };
  }

  // get color depending on population density value
  function getColor(d) {
      return d > 1000 ? '#004d1a' :
          d > 500  ? '#006622' :
          d > 200  ? '#009933' :
          d > 100  ? '#00cc44' :
          d > 50   ? '#00ff55' :
          d > 20   ? '#33ff77' :
          d > 10   ? '#66ff99' :
          '#ccffdd';
  }

  function onEachFeature(feature, layer) {
      layer.on({
          mousemove: mousemove,
          mouseout: mouseout,
          click: zoomToFeature
      });
  }

  var closeTooltip;

  function mousemove(e) {
      var layer = e.target;

      popup.setLatLng(e.latlng);
       popup.setContent('<div class="marker-title"><span class="glyphicon glyphicon-tree-conifer" aria-hidden="true"></span>&nbsp;Click to view <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;participants in <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + layer.feature.properties.name + '</div>' +
          '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + layer.feature.properties.density + ' Trees Planted');

      if (!popup._map) popup.openOn(map);
      window.clearTimeout(closeTooltip);

      // highlight feature
      layer.setStyle({
          weight: 3,
          opacity: 0.3,
          fillOpacity: 0.9
      });

      if (!L.Browser.ie && !L.Browser.opera) {
          layer.bringToFront();
      }
  }

  function mouseout(e) {
      statesLayer.resetStyle(e.target);
      closeTooltip = window.setTimeout(function() {
          map.closePopup();
      }, 100);
  }

  function zoomToFeature(e) {
    //map.fitBounds(e.target.getBounds());
	var layer = e.target;
	window.location = layer.feature.url;
  }

  map.legendControl.addLegend(getLegendHTML());

  function getLegendHTML() {
    var grades = [0, 10, 20, 50, 100, 200, 500, 1000],
    labels = [],
    from, to;

    for (var i = 0; i < grades.length; i++) {
      from = grades[i];
      to = grades[i + 1];

      labels.push(
        '<li><span class="swatch" style="background:' + getColor(from + 1) + '"></span> ' +
        from + (to ? '&ndash;' + to : '+')) + '</li>';
    }

    return '<span>Trees Planted</span><ul>' + labels.join('') + '</ul>';
  }
  

	
	for(var a = 0; a < ar.length; a++){
		
		switch(ar[a]){
  			case 'Patch_01': L.marker([10.6629, 123.1470], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_02': L.marker([10.6613, 123.14851], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_03': L.marker([10.6641, 123.1489], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_04': L.marker([10.6623, 123.1503], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_05': L.marker([10.6630, 123.1523], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_06': L.marker([10.6588, 123.1475], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_07': L.marker([10.6569, 123.1467], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_08': L.marker([10.6575, 123.1492], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_09': L.marker([10.6594, 123.1505], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_10': L.marker([10.6602, 123.1524], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_11': L.marker([10.6613, 123.1535], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_12': L.marker([10.6575, 123.1525], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_13': L.marker([10.6555, 123.1478], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_14': L.marker([10.6564, 123.1510], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;
			case 'Patch_15': L.marker([10.6550, 123.1497], {icon: L.mapbox.marker.icon({'marker-size': 'large','marker-symbol': 'park','marker-color': '#00b3b3'})}).addTo(map); break;

		}
	}
	
</script>

<?php
include('footer.php'); 
?>

</body>
</html>


