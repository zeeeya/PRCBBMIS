<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">          	
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <a class="navbar-brand" href="home.php"><img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" /></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="#">HOME</a></li>
            <li><a href="reg.php">REGISTRATION</a></li>
            <li><a href="#">BUDGET</a></li>
            <li><a href="#">LIQUIDATION</a></li>
            <li><a href="#">MISCELLANEOUS</a></li>
            <li><a href="#">REPORTS</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
        	<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
        	<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      	  </ul>
          
        </div>
      </div>
    </nav>
    <div class="jumbotron home-header">
    	<table>
        	<tr>
            	<td><img src="img/baciwa_thesis.png" alt="thesis-logo"/></td>
            	<td>
        			<h1>Bacolod City Water District</h1> 
  					<p>Planting Activity Management System</p>        
                </td>                
            </tr>
		</table>			
	</div>
	<div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center">
                        <strong>Registration</strong>
                    </h2>
                    <hr>
                    <form class="formbox" style="width:70%" >
                        <label>Registration ID: </label>
                        <input type="number" name="registration ID"></br>
                        <label>Activity: </label>
                        <input type="text" name="activity"></br>
                        <label>Organization Name: </label>
                        <input type="text" name="org name"></br>
                        <label>Organization Type: </label>
                        <input type="text" name="org type"></br>
                        <label>Number of Participants: </label>
                        <input type="text" name="num participants"></br>
                        <label>Contact Number: </label>
                        <input type="number" name="con num"></br>
                        <label>Contact Person: </label>
                        <input type="text" name="con name"></br>
                        </br></br></br></br>
                        <label>Remarks: </label>
                        <textarea rows="4" cols="45"></textarea></br>
                    </form>
                    <form class="formbox" style="width:70%"  >
                        <label>Schedule: </label>
                        <input type="date" name="sched"></br>
                        <label>Time Starts: </label>
                        <input type="time" name="start"></br>
                        <label>Time Ends: </label>
                        <input type="text" name="end">
                        </br></br></br>
                        <label>Status: </label>
                        <select name="--------" Style="width:32.5%">
                            <option>It's complicated</option>
                            <option>Single</option>
                            <option>Married</option>
                            <option>Widow</option>
                        </select></br></br>
                        <label>Remarks: </label>
                        <textarea rows="4" cols="40"></textarea></br>
                    </form>
                    <input type="submit" value="Save" onclick="alert('Successfully saved')">
                    <input type="button" value="Cancel">
                </div>
</body>
</html>