<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: registration.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM registration where regid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
		
		//for organization profile
		
        Database::disconnect();
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
	<?php include('header.php'); ?>
	
	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>
	
	<div class="container-fluid">

		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;View Organization(s)</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>		
			</div>
		</div>
		
		<div class="container col-lg-9 content">
			<div class="col-lg-12">
				<div class="row">
					<h2 style="margin-left:10px;">Update Registration</h2>
					<br />
				</div>

				<div class="row">
					<form class="form-horizontal" role="form" action='./php/registrationUpdate.php?id=<?php echo $id?>' method="POST">
								
						<div class="col-lg-7 forms">
								
									<?php
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM organization where orgid = ?";
										$q = $pdo->prepare($sql);
										$q->execute(array($data['orgid']));
										$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
										
										//for organization profile
										
										Database::disconnect();
									?>
									<!-- Organization Name -->
									<div class="form-group">
										<label for="inputOrgName">Organization Name<span style="font-size:smaller;color:red"> (cannot be edited)</span></label>
										<div class="input-group">
											<input type="text" class="form-control" required="required" id="inputOrgName" name="orgname" placeholder="Organization Name" value="<?php echo $dataOrg['orgname'];?>" readonly>
											<span class="input-group-btn">	
												<a href="#myModal" id="myBtn" class="btn btn-info btn-md" style="height:34px" data-toggle="tooltip modal" title="View Info"><span class="glyphicon glyphicon-modal-window" aria-hidden="true"></span></a>
											</span>
										</div>
										
										
										<!-- Modal -->
										<div id="myModal" class="modal fade" role="dialog" style="top:20%;z-index:99999">
											<div class="modal-dialog">

												<!-- Modal content-->
												<div class="modal-content">
													<div class="modal-header alert-success">
														<button type="button" class="close" data-dismiss="modal">&times;</button>
														<strong>The Organization's Profile.</strong> 
													</div>
													<div class="modal-body">
														<table class="table table-striped">
															<tbody>
																<tr>
																	<td><strong>Organization Name:</strong></td>
																	<td><?php echo $dataOrg['orgname'];?></td>
																</tr>
																<tr>
																	<td><strong>Organization Address:</strong></td>
																	<td><?php echo $dataOrg['orgadd'];?></td>
																</tr>
																<tr>
																	<td><strong>Organization Type:</strong></td>
																	<td><?php echo $dataOrg['orgtype'];?></td>
																</tr>
															</body>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
									
									
									<script>
										$(document).ready(function(){
											$('[data-toggle="tooltip"]').tooltip();   
										});
									</script>
																	
									<!-- Activity -->
									<div class="form-group">
										<label class="control-label" for="inputActivity">Activity</label>
										<select class="form-control" required="required" id="inputActivity" name="activity" value="<?php echo $data['regact'];?>">
											<option></option>
											<option <?php if($data['regact'] == 'Tree Planting')echo 'selected="selected"'; ?> value="Tree Planting">Tree Planting</option>
											<option <?php if($data['regact'] == 'Mangrove Planting')echo 'selected="selected"'; ?> value="Mangrove Planting">Mangrove Planting</option>
										</select>
									</div>
																
									<!-- Contact Person -->
									<div class="form-group">
										<label for="inputPerson">Contact Person</label>
										<input type="text" class="form-control" required="required" id="inputPerson" name="person" placeholder="Contact Person" value="<?php echo $data['regcperson'];?>">
									</div>
									
									<!-- Contact Number -->
									<div class="form-group">
										<label for="inputNumber">Contact Number</label>
										<input type="text" class="form-control" required="required" id="inputNumber" name="number" placeholder="Contact Number" value="<?php echo $data['regcnum'];?>">
									</div>
				
									<!-- Remarks -->
									<div class="form-group">
										<label for="inputProfileRemark">Remarks:</label>
										<textarea class="form-control" id="inputProfileRemark" rows="6" name="remark2" placeholder="Remarks here"><?php echo $data['regmemo'];?></textarea>
									</div>	

									<div class="form-actions text-center forms">
										<button type="submit" class="btn btn-success">Update</button>
										<a class="btn btn-default" href="./registration.php">Back</a>
									</div>									
						</div>
					</form>
				</div>
				<br />
				
					
			</div><!-- end of class span10 offset1-->
		</div><!-- end of class container-->


	</div>

	<?php include('footer.php'); ?>
	
	<!-- script for modal -->
	<script>
		$(document).ready(function(){
			$("#myBtn").click(function(){
				$("#myModal").modal();
			});
		});
	</script>
</body>
</html>