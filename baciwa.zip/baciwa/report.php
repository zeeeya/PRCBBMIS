<?php 
include('php/login_success.php'); 
include('php/links.php');
?>


	<html lang="en">
	<head>
	  <title>Planting Activity Management System</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  
	  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

	  <link rel="stylesheet" href="./css/custom_style.css">

	 </head>
	<body>
	<?php include('header.php'); //nav bar and header?> 

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Planting Activity Maps</h1>
		</div>
	</div>
	
	<div class = "container-fluid content">
	<br>
		<div class="panel panel-primary">
			<div class="panel-heading content">
				<strong> Generate Report</strong>
			</div>
			
			<div class="panel-body" style="margin:0 5%;">
				<label class="control-label" for="inputActivity">Organization List&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<a href="orgreport.php" class="btn btn-success btn-md"><span class="glyphicon glyphicon-plus-sign"></span> Generate Report</a>
				</br>
				</br>
				<label class="control-label" for="inputActivity">List of Items &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<a href="itemreport.php" class="btn btn-success btn-md"><span class="glyphicon glyphicon-plus-sign"></span> Generate Report</a>
				</br>
				</br>
				<label class="control-label" for="inputActivity">List of Icident &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<a href="incidentreport.php" class="btn btn-success btn-md"><span class="glyphicon glyphicon-plus-sign"></span> Generate Report</a>
			<div>
		</div>
	</div>
	
	
<script>
	$(document).ready(function(){
	$('.deleteB').click(function(){
		var value = $( this ).val();
		console.log(value);
		$('#deleteTextField').val(value);
	}); 
});
</script>
<?php
include('footer.php'); 
?>
</body>
</html>