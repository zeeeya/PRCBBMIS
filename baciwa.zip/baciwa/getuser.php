<?php
include('database.php');
// get the q parameter from URL
$id = $_REQUEST['id'];

$pdo = Database::connect();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "SELECT * FROM organization where orgid = ?";
$q = $pdo->prepare($sql);
$q->execute(array($id));
$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
Database::disconnect();

	echo '<div class="form-group">
		<label class="control-label" for="inputActivity">Organization Type</label>
		<input type="text" class="form-control" required="required" id="inputActivity" name="type" placeholder="Organization Type" value="'. $dataOrg['orgtype'] .'">
	</div>
	
	
	<!-- Address -->
	<div class="form-group">
		<label for="inputAddress">Organization Address</label>
		<input type="text" class="form-control" required="required" id="inputAddress" name="address" placeholder="Organization Address" value="' . $dataOrg['orgadd'] . '">
	</div>
									
	<!-- Contact Person -->
	<div class="form-group">
		<label for="inputPerson">Contact Person</label>
		<input type="text" class="form-control" required="required" id="inputPerson" name="person" placeholder="Contact Person" value="' . $dataOrg['orgcperson'] . '">
	</div>
						
	<!-- Contact Number -->
	<div class="form-group">
		<label for="inputNumber">Contact Number</label>
		<input type="text" class="form-control" required="required" id="inputNumber" name="number" placeholder="Contact Number" value="' . $dataOrg['orgcnum'] . '">
	</div>';
								
?>