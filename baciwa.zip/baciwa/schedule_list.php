<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Registration</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid">
	
	<div class="col-md-3">
		<!-- side bar -->
		<div class="list-group side_bar">
			<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
			<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
			<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
			<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>
		</div>		
	</div>
	
	<div class="col-md-9 content">
		<h2>Schedule List</h2>
		<hr />
		<br />
					
			<div class='container-fluid'>
				<div class='row'>
					<div class='col-md-12'>
					
						<div class="table-responsive">
							<table  style = "font-size:10px" class="table table-hover">
								<thead>
									<tr>
										<th>Date</th>
										<th>Activity</th>
										<th>Organization</th>
										<th>Participants</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
											<?php
											require 'database.php'; 
											$pdo = Database::connect();
											$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
											$sql = 'SELECT * FROM participants INNER JOIN schedule ON participants.schedid = schedule.schedid ORDER BY scheddate ASC';
											foreach ($pdo->query($sql) as $row) {
													echo '<tr>';
													
													
													//query organization name
													$id = $row['regid'];
													$sqlQuery = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE regid = ?";
													$q = $pdo->prepare($sqlQuery);
													$q->execute(array($id));
													$data = $q->fetch(PDO::FETCH_ASSOC);
													
													echo '<td>'. $row['scheddate'] . '</td>';
													echo '<td>'. $data['regact'] . '</td>';
													echo '<td>'. $data['orgname'] . '</td>';
													echo '<td>'. $row['partname'] . '</td>';
													
													$done = '';
													$pending = '';
													$postponed = '';
													$cancelled = '';
													
													if($row['partstat'] == 'Done')
														$done = 'selected="selected"';
													if($row['partstat'] == 'Cancelled')
														$cancelled = 'selected="selected"';
													if($row['partstat'] == 'Pending')
														$pending = 'selected="selected"';
													if($row['partstat'] == 'Postponed')
														$postponed = 'selected="selected"';
													echo	'<form role="form" action="php/update_status.php?id='.$row['partid'].'" method="POST">';
													echo '<td>
													
															<select class="form-control" required="required" name="optradio'.$row['partid'].'">
																<option value="Done" '.$done.'>Done</option>
																<option value="Pending" '.$pending.'>Pending</option>
																<option value="Cancelled" '.$cancelled.'>Cancelled</option>
																<option value="Postponed" '.$postponed.'>Postponed</option>
															</select>
														  </td>';
													echo	'<td><button type="submit" class="btn btn-success btn-sm">Update</button></td>';
													echo  '</form>';
													echo '</tr>';
											}
											Database::disconnect();
											?>
								<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip(); 
									$('.btn').tooltip();
								});
								</script>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>
<!-- Status: Done, Pending, Cancelled, Postponed -->
<?php
include('footer.php'); 
?>
												   
</body>
</html>