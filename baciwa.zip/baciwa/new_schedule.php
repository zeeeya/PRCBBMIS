<div class="modal fade" tabindex="-1" role="dialog" id="newScheduleModal" aria-labelledby="newScheduleLabel">

	<div class="modal-dialog" role="document" style="margin-top:10%;">
		<div class="modal-content">
			
			<div class="modal-header btn-primary">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Add New Schedule</h4>
			</div><!-- /.modal-header -->

			<form class="form-horizontal" role="form" action='./php/scheduleCreate.php?id=<?php echo $_GET['id'] ?>' method="POST">			
			
			<div class="modal-body content">

				<div class="row" style="margin:0 5%;">
						<!-- Schedule -->
						<div class="form-group">
							<label for="inputDate">Date</label>
							<input type="date" class="form-control" required="required" id="inputDate" name="schedule" placeholder="Enter Date">
						</div>
						
						<!-- Time Start -->
						<div class="form-group">
							<label for="inputTimeStart">Time Start</label>
							<input type="text" class="form-control" required="required" id="inputTimeStart" name="timestart" placeholder="Time Start">
						</div>
							
						<!-- Time End -->
						<div class="form-group">
							<label for="inputTimeEnd">Time End</label>
							<input type="text" class="form-control" required="required" id="inputTimeEnd" name="timeend" placeholder="Time End">
						</div>
				</div>
			</div><!-- /.modal-body -->

			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Add Schedule</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				
			</div><!-- /.modal-footer -->
			
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Load jQuery and bootstrap datepicker scripts-->
<link type="text/css" href="css/bootstrap-timepicker.min.css" />
<script src="js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript">
					
// When the document is ready
$(document).ready(function () {
						
	$('#inputTimeStart').timepicker({
		template: false,
		showInputs: false,
		minuteStep: 1
	});
	$('#inputTimeEnd').timepicker({
		template: false,
		showInputs: false,
		minuteStep: 1
	}); 										
			
});
</script>