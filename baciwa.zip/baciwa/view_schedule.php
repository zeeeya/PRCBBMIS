<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

</head>

<body>
	<?php include('header.php'); ?>
	
	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>
	
	<div class="container-fluid">
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>
			</div>		
		</div>
				
		<div class="col-lg-9 content">
				
				<div class="row">
					<h2 style="margin-left:10px;"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Schedule List</h2>
					<hr />
				</div>
				
				<div class="panel panel-success">
					<div class="panel-heading">
						<strong><span class="glyphicon glyphicon-tasks" aria-hidden="true"></span>&nbsp;Registration Details</strong>
					</div>
					<div class="panel panel-body">
						<table class="table table-condensed">
						
							<?php
								require 'database.php';

								$pdo = Database::connect();
								$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								$sql = "SELECT * FROM registration WHERE regid = ?";
								$q = $pdo->prepare($sql);
								$q->execute(array($_GET['id']));
								$data = $q->fetch(PDO::FETCH_ASSOC);
								Database::disconnect();

								$pdo = Database::connect();
								$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								$sql = "SELECT * FROM organization WHERE orgid = ?";
								$q = $pdo->prepare($sql);
								$q->execute(array($data['orgid']));
								$ORG_ARR = $q->fetch(PDO::FETCH_ASSOC);
								Database::disconnect();
							?>
				
						
							<tr>
								<td><strong>Registration No.:</strong></td>
								<td><?php echo $_GET['id']?></td>
								<td><strong>Address:</strong></td>
								<td><?php echo $ORG_ARR['orgadd']?></td>
							</tr>
							<tr>
								<td><strong>Activity Type:</strong></td>
								<td><?php echo $data['regact']?></td>
								<td><strong>Contact Person:</strong></td>
								<td><?php echo $data['regcperson']?></td>
							</tr>
							<tr>
								<td><strong>Sponsored Organization:</strong></td>
								<td><?php echo $ORG_ARR['orgname']?></td>
								<td><strong>Contact Number:</strong></td>
								<td><?php echo $data['regcnum']?></td>
							</tr>
							<tr>
								<td><strong>Organization Type:</strong></td>
								<td><?php echo $ORG_ARR['orgtype']?></td>
								<td><strong>Remarks:</strong></td>
								<td><?php echo $data['regmemo']?></td>
							</tr>
						</table>
					</div>
				</div>

				<div class="panel panel-info">
					<div class="panel-heading">
						<strong><span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;Schedule and Participants</strong>
					</div>
						<div class="panel panel-body">
							<div class="row">
								<div class="col-md-6">

									<select class="form-control" id= "schedule" name="schedule" onChange="showParticipants(this.value)">
										<option value="" selected >Select Schedule</option>';
										<?php
											$pdo = Database::connect();
											$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
											$sql = "SELECT * FROM schedule WHERE regid = '".$_GET['id']."'";
											
											foreach ($pdo->query($sql) as $row){
												$option = 'Schedule: '.$row['scheddate'].', Time: '.$row['schedtime'].' - '.$row['schedend'];
												echo '<option value="'.$row['schedid'].'">'.$option.'</option>';
											}
											
											Database::disconnect();
										?>
									</select>
									<script>
										var id = null;
										function showParticipants(str) {
											id = str;
											if (str == "") {
												document.getElementById("participants").innerHTML = "";
												document.getElementById("schedid").value = "";
												document.getElementById("deleteschedid").value = "";
												return;
											} else { 
												if (window.XMLHttpRequest) {
													// code for IE7+, Firefox, Chrome, Opera, Safari
													xmlhttp = new XMLHttpRequest();
												} else {
													// code for IE6, IE5
													xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
												}
												xmlhttp.onreadystatechange = function() {
													if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
														document.getElementById("participants").innerHTML = xmlhttp.responseText;
														document.getElementById("schedid").value = str;
														document.getElementById("deleteschedid").value = str;
													}
												};
												xmlhttp.open("GET","view_participants.php?q="+str,true);
												xmlhttp.send();
											}
										}

										function addParticipants() {
											
											if (id == null || id == "") {
												//document.getElementById("participants").innerHTML = "";
												console.log('null id');
												return;
											}else { 
												if (window.XMLHttpRequest) {
													// code for IE7+, Firefox, Chrome, Opera, Safari
													xmlhttp = new XMLHttpRequest();
												} else {
													// code for IE6, IE5
													xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
												}
												xmlhttp.onreadystatechange = function() {
													if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
														document.getElementById("participants").innerHTML = xmlhttp.responseText;
													}
												};
												xmlhttp.open("GET","view_participants.php?q="+id,true);
												xmlhttp.send();
											}
										}									
									</script>
								</div>
								
								<div class="col-md-6">
									<div class="btn-group text-left">
										<button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>&nbsp;Options&nbsp;
											<span class="caret"></span>
										</button>
										<ul class="dropdown-menu">
											<li><a href="#" data-toggle="modal" data-target="#newScheduleModal">Add Schedule</a></li>
											<li><a href="#" data-toggle="modal" data-target="#updateScheduleModal" id="updateB" >Update Schedule</a></li>
											<li role="separator" class="divider"></li>
											<li><a href="#" data-toggle="modal" data-target="#deleteScheduleModal">Remove Schedule</a></li>
										</ul>
									</div>
									
									<button class="btn btn-info" data-toggle="modal" data-target="#myModal">Add Participant(s)</button>
								</div>
							</div>
						
						<div class="row" style="margin-top:20px;">
							<div class="col-md-12" id="participants">
								<div class="alert alert-warning" role="alert">No schedule selected</div>
							</div>
						</div>
						</div>
				</div>
				<div class="form-actions text-center">
					<a class="btn btn-success" href="./registration.php">Back to Registration List</a>
				</div>
		</div>
	</div>

	<?php 
		include('footer.php'); 
		include('new_schedule.php'); //modal form to add new schedule
		include('delete_schedule.php'); //modal form to delete schedule
	?>
	
	<!-- Modal -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="margin-top:5%;">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header btn-primary">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Participant</h4>
				</div>
				
				<form class="form-horizontal" role="form" action='./php/participantsCreate.php?id=<?php echo $_GET['id'] ?>' method="POST">

				<div class="modal-body">
					<div class="col-md-12 content">
						<input type="hidden" class="form-control" id="schedid" name="scheduleid">
						
						<!-- Participants Name -->
						<div class="form-group">
							<label for="inputDate">Participants Name </label>
							<input type="text" class="form-control" required="required" id="inputDate" name="participantsname" placeholder="Enter Name">
						</div>
						
						<!-- No. of Participants -->
						<div class="form-group">
							<label for="inputTimeStart">No. of Participants</label>
							<input type="text" class="form-control" required="required" id="inputTimeStart" name="noofparticipants" placeholder="Enter Number">
						</div>
					</div>
				</div>
			  
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Save</button>
				
				</div>
				
				</form>
			</div>
		</div>
	</div>
	
	<?php include('update_schedule.php'); //modal form to update schedule ?>
	
</body>
</html>


<?php 
/*
	<div class="row">
		<span><strong>Status<strong></span><br>
		<label class="radio-inline">
			<input name="radioGroup" id="radio1" value="Done" type="radio"> Done
		</label>
		<label class="radio-inline">
			<input name="radioGroup" id="radio2" value="Postponed" checked="" type="radio"> Postponed
		</label>
		<label class="radio-inline">
			<input name="radioGroup" id="radio3" value="Cancelled" type="radio"> Cancelled
		</label>
		<label class="radio-inline">
			<input name="radioGroup" id="radio3" value="Pending" type="radio"> Pending
		</label>
	</div>
*/ ?>