<!-- Modal -->
<div class="modal fade" id="addItem" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:5%;">
		<div class="modal-content">
			<div class="modal-header btn-info">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">New Item</h4>
			</div>
			
			<form class="form-horizontal" role="form" action='./php/itemCreate.php' method="POST">
			
			<div class="modal-body content" style="margin:0 20px;">
				
				<!-- Item Name -->
				<div class="form-group">
					<label for="inputName">Item Name</label>
					<input type="text" class="form-control" required id="inputName" name="itemname" placeholder="Name">
				</div>	
									
				<!-- Item Unit -->
				<div class="form-group">
				<label class="control-label" for="inputItemUnit">Item Unit</label>
				<div class="input-group">
					<span class="input-group-btn">
						<select class="form-control" require="required" id="inputItemUnit" name="itemunit" onChange="showUser(this.value)">
												<option selected="selected" disabled>-- Select Unit --</option>
											<?php
												$pdo = Database::connect();
												$sql = 'SELECT * FROM unit ORDER BY unitdesc';
												foreach ($pdo->query($sql) as $row) {
													echo '<option value="'. $row['unitdesc'] . '" >' . $row['unitdesc'] . '</option>';
												}
												Database::disconnect();
											?>
											</select>
					</div>		
</div>					
				<!-- Item Price -->
				<div class="form-group">
					<label for="inputPrice">Item Price</label>
					<input type="text" class="form-control" required="required" id="inputPrice" name="itemprice" placeholder="Item Price">
				</div>
				
			</div>
			
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Save</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
			
			</form>
		</div>
	</div>
</div>