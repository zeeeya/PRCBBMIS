<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />

</head>
<body>
	<?php require 'database.php'; ?>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		
		
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredregistration.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			</div>
		</div>
	
		<div class="col-md-9">
			<br/>
			<div class="alert alert-success">
			  <strong>Success!</strong> Participants successfully assign to patch.
			</div>
		</div>
	</div>

<?php
include('footer.php'); 
?>
</body>
</html>