<!-- Modal -->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:5%;">
		<div class="modal-content">
			<div class="modal-header btn-warning">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Update Item</h4>
			</div>
			
			<form class="form-horizontal" role="form" action='./php/itemUpdate.php' method="POST">
			
			<div class="modal-body content" style="margin:0 20px;" id="updateDisplayContent">

			</div>
			
			<div class="modal-footer">
				<button type="submit" class="btn btn-warning">Save</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
			
			</form>
		</div>
	</div>
</div>

<script id="source" language="javascript" type="text/javascript">
$(document).ready(function(){
	
	$(".updateB").click(function(){
		var id = $( this ).val();
        console.log(id);
		$.ajax({
			type:"post",
			url:"php/itemUpdateModal.php",
			data:"id="+id,
			success:function(data){
				$("#updateDisplayContent").html(data);
			}
		});
	});
});
</script>