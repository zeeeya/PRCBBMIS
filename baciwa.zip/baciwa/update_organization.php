<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: view_organization.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM organization where orgid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
<!-- Header (to edit see header.php) -->
<?php include('header.php'); ?>

	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>
	
	<div class="container-fluid">
		
		<!-- side bar -->
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>		
			</div>		
		</div>	

		<!--start of Content -->
		<div class="col-lg-9 content">
		
			<div class="row">
				<div>
					<h2>View/Update Organization Profile</h2>
					<hr>
				</div>
			</div>
			
			<form class="form-horizontal" role="form" action='./php/organizationUpdate.php?id=<?php echo $id?>' method="POST">
				<div class="col-lg-10">
					<!-- Organization Name -->
					<div class="form-group">
						<label for="inputOrgName">Name</label>
						<input type="text" class="form-control" required id="inputOrgName" name="orgname" placeholder="Organization Name" value="<?php echo $data['orgname']?>">
					</div>
					
					<!-- Organization Type -->
					<div class="form-group">
						<label class="control-label" for="inputActivity">Type of Organization</label>
						<select class="form-control" required="required" id="inputActivity" name="orgtype">
							<option></option>
							<option <?php if($data['orgtype'] == 'Government Agency')echo 'selected="selected"'; ?> value="Government Agency">Government Agency</option>
							<option <?php if($data['orgtype'] == 'Non-Government Organization')echo 'selected="selected"'; ?> value="Non-Government Organization">Non-Government Organization</option>
							<option <?php if($data['orgtype'] == 'Private Company')echo 'selected="selected"'; ?> value="Private Company">Private Company</option>
							<option <?php if($data['orgtype'] == 'Public Schools')echo 'selected="selected"'; ?>value="Public Schools">Public Schools</option>
							<option <?php if($data['orgtype'] == 'Private Schools')echo 'selected="selected"'; ?> value="Private Schools">Private Schools</option>
							<option <?php if($data['orgtype'] == 'Individual Volunteer')echo 'selected="selected"'; ?> value="Individual Volunteer">Individual Volunteer</option>
							<option <?php if($data['orgtype'] == 'Others')echo 'selected="selected"'; ?> value="Others">Others...</option>
						</select>
					</div>
	
					<!-- Address -->
					<div class="form-group">
						<label for="inputAddress">Address</label>
						<input type="text" class="form-control" required id="inputAddress" name="orgadd" placeholder="Organization Address" value="<?php echo $data['orgadd']?>">
					</div>
		
					<!-- Contact Person -->
					<div class="form-group">
						<label for="inputPerson">Contact Person</label>
						<input type="text" class="form-control" required="required" id="inputPerson" name="orgcperson" placeholder="Contact Person" value="<?php echo $data['orgcperson']?>">
					</div>
						
					<!-- Contact Number -->
					<div class="form-group">
						<label for="inputNumber">Contact Number</label>
						<input type="text" class="form-control" required="required" id="inputNumber" name="orgcnum" placeholder="Contact Number" value="<?php echo $data['orgcnum']?>">
					</div>
			
					<div class="form-actions text-center forms">
						<button type="submit" class="btn btn-warning btn-md">Update</button>
						<a class="btn" href="view_organization.php">Back</a>
					</div>								
				</div>					
			</form>
		</div><!-- end of class container-->
	</div>
	
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>
</body>
</html>