<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document" >
    <div class="modal-content" style="margin-top:10%;">
      <div class="modal-header btn-danger">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Delete Registration</h4>
      </div>
	  
	  <form class="form-horizontal" action="./php/itemDelete.php" method="post">
      
		  <div class="modal-body content">
			<input type="hidden" name="delid" id="deleteTextField" value="<?php echo $id;?>"/>
			<div class="alert alert-danger" role="alert">Are you sure you want to remove this registration from the system?</div>
		  </div>
		  
		  <div class="modal-footer">
			<button type="submit" class="btn btn-danger">Delete</button>
			<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		  </div>
	  
	  </form>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){
	$('.deleteB').click(function(){
		var value = $( this ).val();
		console.log(value);
		$('#deleteTextField').val(value);
	}); 
});
</script>