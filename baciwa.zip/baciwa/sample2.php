<?php
if(isset($_POST)==true && empty($_POST)==false): 
	$BX_NAME=$_POST['mytext'];
	
	foreach($BX_NAME as $a => $b){ 
	
	echo ($a+1).'. ';
	echo $BX_NAME[$a];
	}
else:
	echo 'something went wrong';
endif;
?>