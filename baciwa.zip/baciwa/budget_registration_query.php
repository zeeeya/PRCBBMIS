<?php
	require 'database.php';
	
	$id = $_POST['id'];
	
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM budget where regid = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	$budgetCode = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();
	
	if(!empty($budgetCode['regid'])){
		echo '<input type="hidden" class="form-control" id="budgetCode" value="0">';
		echo '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;">
				<strong>Attention! </strong>You\'ve already proposed a budget to this activity
			  </div>';
	}else{
		echo '<input type="hidden" class="form-control" id="budgetCode" value="1">';
		function getParticipantsNo($id){
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM schedule WHERE regid = '".$id."'";
			
			$total_no_of_participants = 0;
			foreach ($pdo->query($sql) as $dataSched) {
				$sql = 'SELECT * FROM participants WHERE schedid = '.$dataSched['schedid'];
				foreach ($pdo->query($sql) as $dataPart) {
					$total_no_of_participants += $dataPart['partnum'];
				}
			}
			Database::disconnect();
			
			if($total_no_of_participants > 0){
				return $total_no_of_participants;
			}else{
				return '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;"><strong>Attention! </strong>Please enter participants <a href="view_schedule.php?id='.$_GET['id'].'" class="alert-link">Click Here!</a></div>';
			}
		}

		if(!empty($id)){
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM registration where regid = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($id));
			$data = $q->fetch(PDO::FETCH_ASSOC);
			Database::disconnect();
			
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM organization where orgid = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($data['orgid']));
			$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
			Database::disconnect();
			
				echo '<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td><strong>Organization</strong></td>
									<td>'. $dataOrg['orgname'] .'</td>					
								</tr>
								<tr>
									<td><strong>Address</strong></td>
									<td>'. $dataOrg['orgadd'].'</td>					
								</tr>
								<tr>
									<td><strong>Type of Activity</strong></td>
									<td>'.$data['regact'].'</td>					
								</tr>
								<tr>
									<td><strong>Organization Type</strong></td>
									<td>'.$dataOrg['orgtype'].'</td>					
								</tr>
								<tr>
									<td style="vertical-align:text-top"><strong>No. of Participants</strong></td>
									<td>'.getParticipantsNo($id).'</td>					
								</tr>
								<tr>
									<td><strong>Contact Person</strong></td>
									<td>'.$data['regcperson'].'</td>					
								</tr>							
								<tr>
									<td><strong>Contact Number</strong></td>
									<td>'.$data['regcnum'].'</td>					
								</tr>
								<tr>
									<td style="vertical-align:text-top"><strong>Remarks</strong></td>
									<td style="vertical-align:text-top">'.$data['regmemo'].'</td>					
								</tr>
								<tr>
									<td style="vertical-align:text-top"><strong>Schedule(s)</strong></td>
									<td style="vertical-align:text-top">';
										
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM schedule WHERE regid = '".$id."'";
												
											foreach ($pdo->query($sql) as $row){
												echo $row['scheddate'].'<br />';
											}
											
										Database::disconnect();
									
						echo	   '</td>
								</tr>
							</tbody>
						</table>
					</div>';
					
			
		}else{
			
		}
	}
	
?>