<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

 </head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Registration</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid">
	
	<div class="col-md-3">
		<!-- side bar -->
		<div class="list-group side_bar">
			<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
			<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
			<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
		</div>		
	</div>
	
	<div class="col-md-9 content">
		<h2>Registration List</h2>
		<hr />
		<br />
					
			<div class='container-fluid'>
				<div class='row'>
					<div class='col-md-12'>
							
						<div class="table-responsive">
							<table class="table table-hover">
								<thead>
									<tr>
										<th>Activity Code</th>
										<th>Activity</th>
										<th>Organization</th>
										<th>Schedule</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
									include 'database.php';
									$pdo = Database::connect();
									$sql = 'SELECT * FROM registration ORDER BY regid DESC';
									foreach ($pdo->query($sql) as $row) {
											echo '<tr>';
											echo '<td>'. $row['regid'] . '</td>';
											echo '<td>'. $row['regact'] . '</td>';
											echo '<td>'. $row['regname'] . '</td>';
											echo '<td>'. $row['regsdate'] . '</td>';
											echo '<td>'. $row['regstat'] . '</td>';
											echo '<td>
													<a class="btn btn-primary btn-md" href="view_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="View Details"><span class="glyphicon glyphicon-book"></span></a>
													<a class="btn btn-warning btn-md" href="update_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="Update"><span class="glyphicon glyphicon-pencil"></span></a>
													<a class="btn btn-danger btn-md" href="delete_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>
												  </td>';
											echo '</tr>';
									}
									Database::disconnect();
								?>
									
								<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip();   
								});
								</script>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>

</body>
</html>