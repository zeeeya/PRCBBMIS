<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSS import Files -->
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/sidebar.css">
  <link rel="stylesheet" href="./jquery-timepicker-1.3.2/jquery.timepicker.min.css">

  
  <!-- JQuery and Javascript File -->
  <script type="text/javascript" src=".js/jquery-1.11.3.min.js"></script>
  <script type="text/javascript" src="./js/bootstrap.min.js"></script>
  <script type="text/javascript" src="./jquery-timepicker-1.3.2/jquery.timepicker.min.css"></script>
  
	<!-- Date picker-->
	<link rel="stylesheet" href="css/datepicker.css">
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">

</head>
<body>
<div>

    <div class="navbar navbar-default navbar-fixed-top" style= "z-index:99999"> <!-- navbar-fixed-top -->
      <div class="container">
        <div class="navbar-header">          	
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <a class="navbar-brand" href="home.php"><img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" /></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href=" <?php  echo($Home) ?>">HOME</a></li>
            <li><a href=" <?php  echo($Registration) ?>">REGISTRATION</a></li>
            <li><a href=" <?php  echo($Budget) ?>">BUDGET</a></li>
            <li><a href=" <?php  echo($Liquidation) ?>">LIQUIDATION</a></li>
            <li><a href=" <?php  echo($Miscellaneous) ?>">MISCELLANEOUS</a></li>
            <li><a href=" <?php  echo($Report) ?>">REPORTS</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
        	<li><a href=" <?php echo($Signup) ?>"><span class="glyphicon glyphicon-user"></span> Add Account</a></li>
        	<li><a href=" <?php echo($Logout) ?>"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      	  </ul>
          
        </div>
      </div>
    </div>

    <div class="jumbotron home-header">
    	<table>
        	<tr>
            	<td><img src="img/baciwa_thesis.png" alt="thesis-logo"/></td>
            	<td>
        			<h1>Bacolod City Water District</h1> 
  					<p>Planting Activity Management System</p>        
                </td>                
            </tr>
  		</table> 
	</div>

</div>

	<div class="container-fluid main-wrapper">

		<div class="row">
			<div class="container-fluid menu-title">
			<h1>Budget</h1>
			</div>
			<div class="row">
				<div class="col-lg-3 menu-sidebar">
					<!-- side bar -->
					<div class="sidebar-nav">
						  <div class="navbar navbar-default" role="navigation">
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							  </button>
							  <span class="visible-xs navbar-brand" style="padding-top:16px;">Menu</span>
							</div>
							<div class="navbar-collapse collapse sidebar-navbar-collapse">
							  <ul class="nav navbar-nav">
								<li><a href="new_budget.php">New Budget</a></li>
								<li><a href="budget.php">View Budget List</a></li>
							  </ul>
							</div><!--/.nav-collapse -->
						  </div>
					</div>
				</div>
				
				<!-- start sang Coding sang body content -->
				<div class="container col-lg-9 main-content">
					<div class="col-lg-12">
						<div class="row">
							<h2 style="margin-left:10px;">New Budget</h2>
							<br />
						</div>

						<div class="row">
							<div class="col-lg-12">
							<h3>Budget Information</h3>
							<hr />
							</div>
						</div>
						
						<div class="row">
							<form class="form-horizontal" role="form" action='./php/budgetCreate.php' method="POST">
								
								<div class="col-lg-7 forms">
								
								<!-- Subject of the Budget -->
									<div class="form-group">
										<label for="inputSubject">Subject of the Budget</label>
										<input type="text" class="form-control" required="required" id="inputSubject" name="subject_budget" placeholder="Subject of the Budget">
									</div>
									<!-- Activity -->
									<div class="form-group">
										<label class="control-label" for="inputActivity">Activity</label>
										<select class="form-control" required="required" id="inputActivity" name="activity_budget">
											<option></option>
											<option value="Tree Planting">Tree Planting</option>
											<option value="Mangrove Planting">Mangrove Planting</option>
										</select>
									</div>

									<!-- Date Issue -->
									<div class="form-group">
										<label for="inputDateIssue">Date Issue</label>
										<input type="text" class="form-control" required="required" id="inputDateIssue" name="dateissueb" placeholder="Date Issue">
									</div>
									<!-- Load jQuery and bootstrap datepicker scripts -->
									<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputDateIssue').datepicker({
												format: "mm/dd/yyyy"
											});  
										
										});
									</script>
									
									<!-- Date of activity -->
									<div class="form-group">
										<label for="inputDateActivity">Date of activity</label>
										<input type="text" class="form-control" required="required" id="inputDateActivity" name="dateactivityb" placeholder="Date of activity">
									</div>
									<!-- Load jQuery and bootstrap datepicker scripts -->
									<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputDateActivity').datepicker({
												format: "mm/dd/yyyy"
											});  
										
										});
									</script>
									
									<!-- Status -->
									<div class="form-group">
										<label class="control-label" for="inputStatusB">Status</label>
										<select class="form-control" required="required" id="inputStatusB" name="status_budget">
											<option></option>
											<option value="Done">Done</option>
											<option value="Pending}">Pending</option>
											<option value="Cancelled">Cancelled</option>
											<option value="Postponed">Postponed</option>
										</select>
									</div>
									
									
									<!-- Remarks -->
									<div class="form-group">
										<label for="inputProfileRemark">Remarks:</label>
										<textarea class="form-control" id="inputProfileRemark" rows="6" name="remarks_budget" placeholder="Remarks here"></textarea>
									</div>								
								
								</div>
						</div>
						
						<!-- start sang Items na content-->
						<br />
						<div class="row">
							<h3>Items</h3>
							<hr />
						</div>
							<div class="row">	
								<div class="col-lg-7 forms">
								
								<!-- start sang table -->
								<div class='container-fluid'>
						<div class='row'>
							<div class='col-md-12'>
							
								<div class="table-responsive">
									<table class="table table-hover">
										<thead>
											<tr>
												<th>Item Id</th>
												<th>Item Name</th>
												<th>Quantity</th>
												<th>Price</th>
											</tr>
										</thead>
										<tbody>
											<!-- <?php
											include 'database.php';
											$pdo = Database::connect();
											$sql = 'SELECT * FROM registration ORDER BY regid DESC';
											foreach ($pdo->query($sql) as $row) {
													echo '<tr>';
													echo '<td>'. $row['regid'] . '</td>';
													echo '<td>'. $row['regact'] . '</td>';
													echo '<td>'. $row['regname'] . '</td>';
													echo '<td>'. $row['regsdate'] . '</td>';
													echo '<td>'. $row['regstat'] . '</td>';
													echo '<td>
															<a class="btn btn-primary btn-md" href="view_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="View Details"><span class="glyphicon glyphicon-book"></span></a>
															<a class="btn btn-warning btn-md" href="update_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="Update"><span class="glyphicon glyphicon-pencil"></span></a>
															<a class="btn btn-danger btn-md" href="delete_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>
														  </td>';
													echo '</tr>';
											}
											Database::disconnect();
											?> 
											
											<script>
											$(document).ready(function(){
												$('[data-toggle="tooltip"]').tooltip();   
											});
											</script>
											
											-->

										</tbody>
									</table>
								</div>
							
							
							</div>
						</div>
					</div>
								<!-- end sang table of items -->
								
									
								</div>
							</div>
							<div class="form-actions text-center forms">
								<button type="submit" class="btn btn-success">Create</button>
							</div>
							
					 </form>
					</div><!-- end of class span10 offset1-->
				</div><!-- end of class container-->
			</div>
		</div>
	</div>

</body>
</html>