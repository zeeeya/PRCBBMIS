<?php
	require 'database.php';
	
	$id = $_POST['id'];
	
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM liquidation where budcode = ?";//$sql = "SELECT * FROM budget where regid = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	$liquidationCode = $q->fetch(PDO::FETCH_ASSOC);//$budgetCode = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();
	
	if(!empty($liquidationCode['budcode'])){
		echo '<input type="hidden" class="form-control" id="liquidationCode" value="0">';
		echo '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;">
				<strong>Attention! </strong>You\'ve already proposed a liquidation to this budget
			  </div>';
	}else{
		echo '<input type="hidden" class="form-control" id="liquidationCode" value="1">';
		/*function getParticipantsNo($id){
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM schedule WHERE regid = '".$id."'";
			
			$total_no_of_participants = 0;
			foreach ($pdo->query($sql) as $dataSched) {
				$sql = 'SELECT * FROM participants WHERE schedid = '.$dataSched['schedid'];
				foreach ($pdo->query($sql) as $dataPart) {
					$total_no_of_participants += $dataPart['partnum'];
				}
			}
			Database::disconnect();
			
			if($total_no_of_participants > 0){
				return $total_no_of_participants;
			}else{
				return '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;"><strong>Attention! </strong>Please enter participants <a href="view_schedule.php?id='.$_GET['id'].'" class="alert-link">Click Here!</a></div>';
			}
		}*/

		if(!empty($id)){
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM budget where budcode = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($id));
			$data = $q->fetch(PDO::FETCH_ASSOC);
			Database::disconnect();
			
			/*$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "SELECT * FROM organization where orgid = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($data['orgid']));
			$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
			Database::disconnect();*/
			
				echo '<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td><strong>Budget Code</strong></td>
									<td>'. $data['budcode'] .'</td>					
								</tr>
								<tr>
									<td><strong>Subject of the Budget</strong></td>
									<td>'. $data['budsub'].'</td>					
								</tr>
								<tr>
									<td><strong>Date Issue</strong></td>
									<td>'.$data['buddate'].'</td>					
								</tr>
								<tr>
									<td><strong>Budget Status</strong></td>
									<td>'.$data['budstat'].'</td>					
								</tr>
								<tr>
									<td style="vertical-align:text-top"><strong>Items</strong></td>
									<td style="vertical-align:text-top">';
										
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM itembudget WHERE budcode = '".$id."'";
												
											foreach ($pdo->query($sql) as $row){
												echo $row['itemname'] . " || Quantity: " . $row['itemquantity'] . " " .$row['itemunit'] . "   || Price: P". $row['itemprice'].'<br />';
											}
											
										Database::disconnect();
									
						echo	   '</td>
								</tr>
								<tr>
									<td><strong>Total Budget Amount</strong></td>
									<td>'.$data['budamount'].'</td>					
								</tr>
							</tbody>
						</table>
					</div>';
					
			
		}else{
			
		}
	}
	
?>