<?php 
include('php/login_success.php'); 
include('php/links.php');
?>


	<html lang="en">
	<head>
	  <title>Planting Activity Management System</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  
	  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

	  <link rel="stylesheet" href="./css/custom_style.css">

		<style>
		.panel {
			border: 1px solid #1a8cff; 
			border-radius:0;
			transition: box-shadow 0.5s;
		}
		.panel:hover {
			box-shadow: 5px 0px 40px rgba(0,0,0, .2);
		}
		.panel-heading {
			color: #fff !important;
			background-color: #1a8cff !important;
			padding: 10px;
			border-bottom: 1px solid transparent;
			border-top-left-radius: 0px;
			border-top-right-radius: 0px;
			border-bottom-left-radius: 0px;
			border-bottom-right-radius: 0px;
		}
		
		.panel:hover .panel-heading {
			color: #fff !important;
			background-color: #0066cc !important;
		}
		
		/* Add a dark background color to the footer */
		footer {
			background-color: #2d2d30;
			color: #f5f5f5;
			padding: 10px;
		}

		footer a {
			color: #f5f5f5;
		}

		footer a:hover {
			color: #777;
			text-decoration: none;
		}
		
		img {
			opacity: 0.8;
			filter: alpha(opacity=40); /* For IE8 and earlier */
		}

		img:hover {
			opacity: 1.0;
			filter: alpha(opacity=100); /* For IE8 and earlier */
		}
		</style>
	</head>
	<body>
	<?php include('header.php'); //nav bar and header?> 

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Planting Activity Maps</h1>
		</div>
	</div>
	<div class="container-fluid bg-1 text-center">
		<div class="col-md-2"></div>
		<div class="col-md-4">
			<br/>
			<div class="panel panel-success text-center">
				<div class="panel-heading"><h3>Tree Planting</h3></div>
				<div class="panel-body">
					<a href="treeplanting.php"><img src="./images/tree.jpg" class="img-circle" alt="Tree" height="40%" ></a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<br/>
			<div class="panel panel-success text-center">
				<div class="panel-heading"><h3>Mangrove Planting</h3></div>
				<div class="panel-body">
					<a href="mangroveplanting.php"><img src="./images/mangrove.jpg" class="img-circle" alt="Mangrove" height="40%" ></a>
				</div>
			</div>
		</div>
		<div class="col-md-2"></div>
	</div>
	
	<!--
	<div class="container-fluid">
		<h1 style="margin-left:280px;">Tree Planting Map&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mangrove Planting Map</h1> 
		<a href="treeplanting.php">
		<img src="./images/tree.jpg" style="width:250px;height:250px;margin:10px;margin-left:300px;margin-bottom:0px;"</img>
		</a>
		<a href="mangroveplanting.php">
		<img src="./images/mangrove.jpg" style="width:250px;height:250px;margin:10px;margin-left:200px;margin-bottom:0px;"</img>
		</a>
	</div>
	-->
<footer class="text-right">
  <p>© 2015-2016 Information System | <a href="http://www.uno-r.edu.ph/academics/departments/information-technology/">College of Information Technology</a> | <a href="http://www.uno-r.edu.ph/">University of Negros Occidental-Recoletos</a></p> 
</footer>

</body>
</html>