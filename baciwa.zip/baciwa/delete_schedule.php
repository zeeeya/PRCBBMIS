<div class="modal fade" tabindex="-1" role="dialog" id="deleteScheduleModal" aria-labelledby="deleteScheduleLabel">

	<div class="modal-dialog" role="document" style="margin-top:10%;">
		<div class="modal-content">
			
			<div class="modal-header btn-danger">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Remove Schedule</h4>
			</div><!-- /.modal-header -->

			<form class="form-horizontal" role="form" action='./php/scheduleDelete.php?id=<?php echo $_GET['id'] ?>' method="POST">			
			
			<div class="modal-body content">

				<div class="row" style="margin:0 5%;">
					
					<div class="alert alert-warning">Are you sure you want to delete this schedule?</div>
					<input type="hidden" name="deleteschedid" id="deleteschedid"/>
					
				</div>
			</div><!-- /.modal-body -->

			<div class="modal-footer">
				<button type="submit" class="btn btn-danger">Yes</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
			</div><!-- /.modal-footer -->
			
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Load jQuery and bootstrap datepicker scripts-->
<link type="text/css" href="css/bootstrap-timepicker.min.css" />
<script src="js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript">
					
// When the document is ready
$(document).ready(function () {
						
	$('#inputTimeStart').timepicker({
		template: false,
		showInputs: false,
		minuteStep: 1
	});
	$('#inputTimeEnd').timepicker({
		template: false,
		showInputs: false,
		minuteStep: 1
	}); 										
			
});
</script>
