<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
<!-- Header (to edit see header.php) -->
<?php include('header.php'); ?>

	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>


	<div class="container-fluid">
	
		<!-- side bar -->
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>
			</div>		
		</div>
				
		<!--start of Content -->
				
		<div class="container col-lg-7 content">
				
			<div class="row">
				<h2 style="margin-left:10px;">Register New Organization</h2>
				<br />
			</div>
					
			<div class="panel panel-info">
					
				<div class="panel-heading">
					<h4>Organization Profile</h4>
				</div>
				
				<div class="panel-body">
					<form class="form-horizontal" role="form" action='./php/organizationCreate.php' method="POST">
					<div class="col-md-12">
						<!-- Organization Name -->
						<div class="form-group">
							<label for="inputOrgName">Name</label>
							<input type="text" class="form-control" required id="inputOrgName" name="orgname" placeholder="Organization Name">
						</div>
							
						<!-- Organization Type -->
						<div class="form-group">
							<label class="control-label" for="inputActivity">Type of Organization</label>
							<select class="form-control" required="required" id="inputActivity" name="orgtype">
								<option></option>
								<option value="Government Agency">Government Agency</option>
								<option value="Non-Government Organization">Non-Government Organization</option>
								<option value="Private Company">Private Company</option>
								<option value="Public Schools">Public Schools</option>
								<option value="Private Schools">Private Schools</option>
								<option value="Individual Volunteer">Individual Volunteer</option>
								<option value="Others">Others...</option>
								</select>
						</div>
						
						<!-- Address -->
						<div class="form-group">
							<label for="inputAddress">Address</label>
							<input type="text" class="form-control" required id="inputAddress" name="orgadd" placeholder="Organization Address">
						</div>	
								
						<!-- Contact Person -->
						<div class="form-group">
							<label for="inputPerson">Contact Person</label>
							<input type="text" class="form-control" required="required" id="inputPerson" name="orgcperson" placeholder="Contact Person">
						</div>
							
						<!-- Contact Number -->
						<div class="form-group">
							<label for="inputNumber">Contact Number</label>
							<input type="text" class="form-control" required="required" id="inputNumber" name="orgcnum" placeholder="Contact Number">
						</div>
					</div>	
				</div>
				<div class="panel-footer">	
						<div class="form-actions text-center forms">
							<button type="submit" class="btn btn-success">Create</button>
							<a class="btn" href="view_organization.php">Back</a>
						</div>								
													
					</form>		
				</div>		
			</div><!-- panel -->

		</div><!-- end of class container-->
	</div>
	
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>
</body>
</html>