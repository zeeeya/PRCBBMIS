<!DOCTYPE html>
<html>
<head>
<meta charset=utf-8 />
<title>Choropleth</title>
<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
<script src='https://api.mapbox.com/mapbox.js/v2.2.4/mapbox.js'></script>
<link href='https://api.mapbox.com/mapbox.js/v2.2.4/mapbox.css' rel='stylesheet' />
<style>
  body { margin:0; padding:0; }
  #map { position:absolute; top:0; bottom:0; width:100%; }
</style>
</head>
<body>


<div id='map'></div>

<style>
.map-legend ul {
  list-style: none;
  padding-left: 0;
  }
.map-legend .swatch {
  width:20px;
  height:20px;
  float:left;
  margin-right:10px;
  }
.leaflet-popup-close-button {
  display: none;
  }
.leaflet-popup-content-wrapper {
  pointer-events: none;
  }
</style>
<script src='php/mangroveplanting.php'></script>
<script>
//basemap
L.mapbox.accessToken = 'pk.eyJ1IjoibmF6ZXJjYWx1bXBpYW5vIiwiYSI6ImNpZXd5ZGZpaDA4Yzlza2txNTdrdTc5M3AifQ.-XyoP4Y98GGOAXF3fD8juw#18/10.60858/122.90814';
var map = L.mapbox.map('map', 'mapbox.satellite').setView([10.608, 122.91], 17);

var popup = new L.Popup({ autoPan: false });

  var statesLayer = L.geoJson(patches,  {
      style: getStyle,
      onEachFeature: onEachFeature
  }).addTo(map);

  function getStyle(feature) {
      return {
          weight: 2,
          opacity: 0.1,
          color: 'black',
          fillOpacity: 0.7,
          fillColor: getColor(feature.properties.density)
      };
  }

  // get color depending on population density value
  function getColor(d) {
      return d > 1000 ? '#004d1a' :
          d > 500  ? '#006622' :
          d > 200  ? '#009933' :
          d > 100  ? '#00cc44' :
          d > 50   ? '#00ff55' :
          d > 20   ? '#33ff77' :
          d > 10   ? '#66ff99' :
          '#ccffdd';
  }

  function onEachFeature(feature, layer) {
      layer.on({
          mousemove: mousemove,
          mouseout: mouseout,
          click: zoomToFeature
      });
  }

  var closeTooltip;

  function mousemove(e) {
      var layer = e.target;

      popup.setLatLng(e.latlng);
      popup.setContent('<div class="marker-title"><a>' + layer.feature.properties.name + '</a></div>' +
          layer.feature.properties.density + ' Trees Planted');

      if (!popup._map) popup.openOn(map);
      window.clearTimeout(closeTooltip);

      // highlight feature
      layer.setStyle({
          weight: 3,
          opacity: 0.3,
          fillOpacity: 0.9
      });

      if (!L.Browser.ie && !L.Browser.opera) {
          layer.bringToFront();
      }
  }

  function mouseout(e) {
      statesLayer.resetStyle(e.target);
      closeTooltip = window.setTimeout(function() {
          map.closePopup();
      }, 100);
  }

  function zoomToFeature(e) {
      //map.fitBounds(e.target.getBounds());
	  var layer = e.target;
	  window.location = layer.feature.properties.url;
  }

  map.legendControl.addLegend(getLegendHTML());

  function getLegendHTML() {
    var grades = [0, 10, 20, 50, 100, 200, 500, 1000],
    labels = [],
    from, to;

    for (var i = 0; i < grades.length; i++) {
      from = grades[i];
      to = grades[i + 1];

      labels.push(
        '<li><span class="swatch" style="background:' + getColor(from + 1) + '"></span> ' +
        from + (to ? '&ndash;' + to : '+')) + '</li>';
    }

    return '<span>Trees Planted</span><ul>' + labels.join('') + '</ul>';
  }
  

</script>

</body>
</html>
