<?php 
include('php/login_success.php'); 
include('php/links.php');
include 'database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 
 
<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		  <h1>Incident Monitoring</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid">
	
	<div class="col-md-3">
		<!-- side bar -->
		<div class="list-group side_bar">
			<a href="new_incident.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create new Incident Report</a>
			<a href="incident.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Incident List</a>
		</div>		
	</div>

	<!--start of Content -->
		<div class="col-lg-9 content">
			<div class="row">
				<h2 style="margin-left:10px;">New Incident Report</h2>
				<br />
			</div>
			
			<form class="form-horizontal" role="form" action='./php/incident_create.php' method="POST">

				<div class="row col-md-10">
					<div class="panel panel-default panel-primary">
						<div class="panel-heading">
							<h4>Profile Information</h4>
						</div>
						<div class="panel-body" style="padding-left:50px;">

							<div class="col-lg-11 forms">

								<!-- Date of Incident -->
									<div class="form-group">
										<label for="inputIncDate">Date of Incident</label>
										<input type="text" class="form-control" required="required" id="inputIncDate" name="incdate" placeholder="Enter Date">
										<!-- <input type="text" id="inputSchedule" > -->
									</div>
									<!-- Load jQuery and bootstrap datepicker scripts -->
									<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputIncDate').datepicker({
												format: "mm/dd/yyyy"
											});  
										
										});
									</script>

									<div class="form-group">
										<label for="orgnameInput">Organization Name</label>
										<div class="input-group">
											<span class="input-group-btn">
												<select class="form-control" require="required" id="orgnameInput" name="incorg" onChange="showUser(this.value)">
												<option selected="selected" disabled>-- Select Organization --</option>
												<?php
												$pdo = Database::connect();
												$sql = 'SELECT * FROM organization ORDER BY orgname';
												foreach ($pdo->query($sql) as $row) {
													echo '<option value="'. $row['orgid'] . '" >' . $row['orgname'] . '</option>';
												}
												Database::disconnect();?>
												</select>
											</span>
										</div> 
									</div>

									<!-- Name -->
									<div class="form-group">
										<label for="inputName">Name</label>
										<input type="text" class="form-control" required="required" id="inputName" name="name" placeholder="Name">
									</div>

									<!-- Address -->
									<div class="form-group">
										<label for="inputAdd">Address</label>
										<input type="text" class="form-control" required="required" id="inputAdd" name="add" placeholder="Address">
									</div>
									
									<!-- Type -->
									<div class="form-group">
										<label for="inputType">Type of Incident</label>
										<input type="text" class="form-control" required="required" id="inputType" name="type" placeholder="Type of Incident">
									</div>
									
									<!-- Description -->
									<div class="form-group">
										<label for="inputDesc">Description</label>
										<input type="text" class="form-control" required="required" id="inputDesc" name="desc" placeholder="Description">
									</div>

									<!-- Planting Activity -->
									<div class="form-group">
										<label class="control-label" for="inputAct">Activity</label>
										<select class="form-control" required="required" id="inputAct" name="act">
											<option></option>
											<option value="Tree Planting">Tree Planting</option>
											<option value="Mangrove Planting">Mangrove Planting</option>
										</select>
									</div>

									<div class="form-actions text-center forms">
            						<button type="submit" class="btn btn-success">Create</button>
    								</div>
								 
								</div>
							</div>
						</div> 
					</div>

			</form>
        </div>
</div>


<!-- footer (to edit see footer.php) -->
<?php include('./footer.php'); ?>
</body>
</html>