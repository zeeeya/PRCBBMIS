<?php
    require '../database.php';
 
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: ../incident.php");
    }
     
    if ( !empty($_POST)) {
        // keep track validation errors
        $nameError = null;
        $emailError = null;
        $mobileError = null;
         
        // keep track post values
		$incdate = $_POST['incdate'];
        $orgid = $_POST['incorg'];
        $incname = $_POST['name'];
        $incadd = $_POST['add'];
        $inctype = $_POST['type'];
        //$regstat = $_POST['status'];
        $incdesc = $_POST['desc'];
        $incact = $_POST['act'];
         
        // validate input
        $valid = true;
         
        // update data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE incident set incdate = ?, orgid=?, incname=?, incadd=?, inctype=?, incdesc=?, incact=? WHERE incid = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($incdate, $orgid, $incname, $incadd, $inctype, $incdesc, $incact, $id));
            Database::disconnect();
            header("Location: ../incident.php");
        }
    }
?>