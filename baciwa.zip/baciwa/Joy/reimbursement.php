<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Reimbursement Expense</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid">
	
	<div class="col-md-3">
		<!-- side bar -->
		<div class="list-group side_bar">
			<a href="new_reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create Reimbursement Expense</a>
				<a href="reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Reimbursement Expense</a>
		</div>		
	</div>

	<div class="col-md-9 content">
		<h2>Reimbursement Expense List</h2>
		<hr />
		<br />
					
			<div class='container-fluid'>
				<div class='row'>
					<div class='col-md-12'>
							
						<div class="table-responsive">
							<table class="table table-hover">
								<thead>
									<tr>
										<th>Date</th>
										<th>Name</th>
										<th>Amount</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
											include 'database.php';
											$pdo = Database::connect();
											$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
											$sql = 'SELECT * FROM reimbursement ORDER BY rerdate DESC';
											foreach ($pdo->query($sql) as $row) {
													echo '<tr>';
													echo '<td>'. $row['rerdate'] . '</td>';
													echo '<td>'. $row['rername'] . '</td>';
													echo '<td>'. $row['reramount'] . '</td>';
													echo '<td>															
															<a class="btn btn-info btn-md" href="view_reimbursement.php?id='.$row['rerid'].'" data-toggle="tooltip" title="View Reimbursement Details"><span class="glyphicon glyphicon-book"></span></a>
															<button type="button" class="btn btn-danger btn-md deleteB" rel="tooltip" title="Delete Reimbursement" data-toggle="modal" data-target="#myModal" value="'.$row['rerid'].'"><span class="glyphicon glyphicon-trash"></span></button>
														  </td>';
													echo '</tr>';
											}
											Database::disconnect();
											?>
								<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip(); 
									$('.btn').tooltip();
								});
								</script>

								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document" >
    <div class="modal-content" style="margin-top:10%;">
      <div class="modal-header btn-danger">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Delete Reimbursement</h4>
      </div>
	  
	  <form class="form-horizontal" action="delete_reimbursement.php" method="post">
      
	  <div class="modal-body content">
		<input type="hidden" name="delid" id="deleteTextField" value="<?php echo $id;?>"/>
		<div class="alert alert-danger" role="alert">Are you sure you want to remove this reimbursement from the system?</div>
      </div>
	  
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
	  
	  </form>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){
	$('.deleteB').click(function(){
		var value = $( this ).val();
		console.log(value);
		$('#deleteTextField').val(value);
	}); 
});
</script>

</br>
</br>
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>
</body>
</html>

