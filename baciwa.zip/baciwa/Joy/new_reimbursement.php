<?php 
include('php/login_success.php'); 
include('php/links.php');
include 'database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./jquery-timepicker-1.3.2/jquery.timepicker.min.css">

  
	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jquery-timepicker-1.3.2/jquery.timepicker.min.css"></script>
  
	<!-- Date picker-->
	<link rel="stylesheet" href="css/datepicker.css">
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
	
	<link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
	<?php include('header.php'); ?>

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Reimbursement Expense</h1>
		</div>
	</div>

	<div class="container-fluid">
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="new_reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create Reimbursement Expense</a>
				<a href="reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Reimbursement Expense</a>
			</div>		
		</div>
		
		<!--start of Content -->
		<div class="col-lg-7 content">
			<div class="row">
				<h2 style="margin-left:10px;">New Reimbursement Expense</h2>
				<br />
			</div>
			
			<form class="form-horizontal" role="form" action='./php/reimbursementCreate.php' method="POST">	

        <!-- Date of Issue -->
        <div class="row col-md-7">
        <label for='name' >Date: </label>
        <input type="text" required="required" id="inputPayDate" name="paydate" placeholder="Enter Date"/>
        </div>
        <!-- Load jQuery and bootstrap datepicker scripts -->
                  <script src="js/jquery-1.9.1.min.js"></script>
                  <script src="js/bootstrap-datepicker.js"></script>
                  <script type="text/javascript">
                    // When the document is ready
                    $(document).ready(function () {
                      
                      $('#inputPayDate').datepicker({
                        format: "mm/dd/yyyy"
                      });  
                    
                    });
                  </script>
        

      </br>
      </br>
				<div class="row col-md-10">
					<div class="panel panel-default panel-primary">
						<div class="panel-heading">
							<h4>Reimbursement Information</h4>
						</div>
						<div class="panel-body" style="padding-left:30px;">
							<div class="col-lg-11 forms">

					<!-- Name -->
                  <div class="form-group">
                    <label for="inputName">Name</label>
                    <input type="text" class="form-control" required="required" id="inputName" name="name" placeholder="Name">
                  </div>

                  <!-- Amount -->
                  <div class="form-group">
                    <label for="inputAmt">Amount</label>
                    <input type="text" class="form-control" required="required" id="inputAmt" name="amt" placeholder="Amount">
                  </div>

                  <!-- Payment For -->
                  <div class="form-group">
                    <label for="inputPayment">Payment For</label>
                    <input type="text" class="form-control" required="required" id="inputPayment" name="payment" placeholder="Payment For">
                  </div>

                  <!-- Remarks -->
                  <div class="form-group">
                    <label for="inputRemark">Remarks</label>
                    <textarea class="form-control" id="inputRemark" rows="6" name="remark" placeholder="What's on your mind"></textarea>
                  </div>

                  <!--Payee Information-->
                  <div class="row">
              		<h3>Payee Information</h3>
              			<hr />
            	  </div>
                  <div class="row" style="padding-left:10%"> 
                <div class="col-lg-10 forms">

                  <!-- Payee Name -->
                  <div class="form-group">
                    <label for="inputPayName">Name</label>
                    <input type="text" class="form-control" required="required" id="inputPayName" name="payname" placeholder="Payee Name">
                  </div>

                  <!-- Payee Address -->
                  <div class="form-group">
                    <label for="inputPayAdd">Address</label>
                    <input type="text" class="form-control" required="required" id="inputPayAdd" name="payadd" placeholder="Payee Address">
                  </div>

                  <!-- Place of Issue -->
                  <div class="form-group">
                    <label for="inputPayIssue">Place of Issue</label>
                    <input type="text" class="form-control" required="required" id="inputPayIssue" name="payissue" placeholder="Place of Issue">
                  </div>

                  <!-- Cedula-->
                  <div class="form-group">
                    <label for="inputPayCedula">Residence Certificate Number</label>
                    <input type="text" class="form-control" required="required" id="inputPayCedula" name="paycedula" placeholder="Residence Number">
                  </div>

                  <!-- Date of Issue -->
                  <div class="form-group">
                    <label for="inputPayDate">Date of Issue</label>
                    <input type="text" class="form-control" required="required" id="inputPayDate" name="paydate" placeholder="Enter Date">
                    <!-- <input type="text" id="inputSchedule" > -->
                  </div>
                  <!-- Load jQuery and bootstrap datepicker scripts -->
                  <script src="js/jquery-1.9.1.min.js"></script>
                  <script src="js/bootstrap-datepicker.js"></script>
                  <script type="text/javascript">
                    // When the document is ready
                    $(document).ready(function () {
                      
                      $('#inputPayDate').datepicker({
                        format: "mm/dd/yyyy"
                      });  
                    
                    });
                  </script>

                </div>
              </div>

              <!--Witness Information-->
              <div class="row">
              	<h3>Witness Information</h3>
              	<hr />
              </div>
              <div class="row" style="padding-left:10%"> 
                <div class="col-lg-10 forms">

                  <!-- Witness Name -->
                  <div class="form-group">
                    <label for="inputWitName">Name</label>
                    <input type="text" class="form-control" required="required" id="inputWitName" name="witname" placeholder="Witness Name">
                  </div>

                  <!-- Witness Address -->
                  <div class="form-group">
                    <label for="inputWitAdd">Address</label>
                    <input type="text" class="form-control" required="required" id="inputWitAdd" name="witadd" placeholder="Witness Address">
                  </div>

                  <!-- Place of Issue -->
                  <div class="form-group">
                    <label for="inputWitIssue">Place of Issue</label>
                    <input type="text" class="form-control" required="required" id="inputWitIssue" name="witissue" placeholder="Place of Issue">
                  </div>

                  <!-- Cedula-->
                  <div class="form-group">
                    <label for="inputWitCedula">Residence Certificate Number</label>
                    <input type="text" class="form-control" required="required" id="inputWitCedula" name="witcedula" placeholder="Residence Number">
                  </div>

                  <!-- Date of Issue -->
                  <div class="form-group">
                    <label for="inputWitDate">Date of Issue</label>
                    <input type="text" class="form-control" required="required" id="inputWitDate" name="witdate" placeholder="Enter Date">
                    <!-- <input type="text" id="inputSchedule" > -->
                  </div>
                  <!-- Load jQuery and bootstrap datepicker scripts -->
                  <script src="js/jquery-1.9.1.min.js"></script>
                  <script src="js/bootstrap-datepicker.js"></script>
                  <script type="text/javascript">
                    // When the document is ready
                    $(document).ready(function () {
                      
                      $('#inputWitDate').datepicker({
                        format: "mm/dd/yyyy"
                      });  
                    
                    });
                  </script>
                </div>
              </div>

						</div>
						</div>
					</div>
					</div>
				</div>
				</div>
        <div class="form-actions text-center forms">
            <button type="submit" class="btn btn-success">Create</button>
				</form>	

					

			</div>
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>
</body>
</html>


<?php /*
	<!-- Status -->
	<div class="form-group">
		<label class="radio-inline"><input type="radio" name="optradio">Pending</label>
		<label class="radio-inline"><input type="radio" name="optradio">Done</label>
		<label class="radio-inline"><input type="radio" name="optradio">Cancelled</label>
		<label class="radio-inline"><input type="radio" name="optradio">Postponed</label>
	</div>
	<!-- Remarks -->
	<div class="form-group">
		<label for="inputProfileRemark">Remarks:</label>
		<textarea class="form-control" id="inputProfileRemark" rows="6" name="remark2" placeholder="Remarks here"></textarea>
	</div>
*/ ?>	