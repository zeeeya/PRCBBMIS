<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: incident.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM incident where incid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
		
		//for organization profile
		
        Database::disconnect();
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
	<?php include('header.php'); ?>
	
	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Incident Monitoring</h1>
		</div>
	</div>
	
	<div class="container-fluid">

		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="new_incident.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create new Incident Report</a>
				<a href="incident.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Incident List</a>		
			</div>
		</div>
		
		<div class="container col-lg-9 content">
			<div class="col-lg-12">
				<div class="row">
					<h2 style="margin-left:10px;">Update Incident</h2>
					<br />
				</div>

				<div class="row">
					<form class="form-horizontal" role="form" action='./php/registrationUpdate.php?id=<?php echo $id?>' method="POST">
								
						<div class="col-lg-7 forms">
						
									<!-- Date of Incident -->
									<div class="form-group">
										<label for="inputIncDate">Date of Incident</label>
										<input type="text" class="form-control" required="required" id="inputIncDate" name="incdate" placeholder="Enter Date" value="<?php echo $data['incdate'];?>">
										<!-- <input type="text" id="inputSchedule" > -->
									</div>
									<!-- Load jQuery and bootstrap datepicker scripts -->
									<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputIncDate').datepicker({
												format: "mm/dd/yyyy"
											});  
										
										});
									</script>

									<!-- Organization Name -->
									<!--<div class="form-group">
										<label for="orgnameInput">Organization Name</label>
										<div class="input-group">
											<span class="input-group-btn">
												<input type="text" class="form-control" required="required" id="inputOrgName" name="orgname" placeholder="Organization Name" value="<?php echo $dataOrg['orgname'];?>">
												<select class="form-control" require="required" id="orgnameInput" name="incorg" onChange="showUser(this.value)">
												<option selected="selected" disabled>-- Select Organization --</option>
												<?php
												$pdo = Database::connect();
												$sql = 'SELECT * FROM organization ORDER BY orgname';
												foreach ($pdo->query($sql) as $row) {
													echo '<option value="'. $row['orgid'] . '" >' . $row['orgname'] . '</option>';
												}
												Database::disconnect();?>
												</select>
											</span>
										</div> 
									</div>-->
									<?php
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM organization where orgid = ?";
										$q = $pdo->prepare($sql);
										$q->execute(array($data['orgid']));
										$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
										
										//for organization profile
										
										Database::disconnect();
									?>

									<div class="form-group">
										<label for="inputOrgName">Organization Name<span style="font-size:smaller;color:red"> (cannot be edited)</span></label>
										<div class="input-group">
											<input type="text" class="form-control" required="required" id="inputOrgName" name="orgname" placeholder="Organization Name" value="<?php echo $dataOrg['orgname'];?>" readonly>
											<span class="input-group-btn">	
												<!--<a href="#myModal" id="myBtn" class="btn btn-info btn-md" style="height:34px" data-toggle="tooltip modal" title="View Info"><span class="glyphicon glyphicon-modal-window" aria-hidden="true"></span></a>-->
											</span>
										</div>
									</div>

									<!-- Name -->
									<div class="form-group">
										<label for="inputName">Name</label>
										<input type="text" class="form-control" required="required" id="inputName" name="name" placeholder="Name" value="<?php echo $data['incname'];?>">
									</div>

									<!-- Address -->
									<div class="form-group">
										<label for="inputAdd">Address</label>
										<input type="text" class="form-control" required="required" id="inputAdd" name="add" placeholder="Address" value="<?php echo $data['incadd'];?>">
									</div>
									
									<!-- Type -->
									<div class="form-group">
										<label for="inputType">Type of Incident</label>
										<input type="text" class="form-control" required="required" id="inputType" name="type" placeholder="Type of Incident" value="<?php echo $data['inctype'];?>">
									</div>
									
									<!-- Description -->
									<div class="form-group">
										<label for="inputDesc">Description</label>
										<input type="text" class="form-control" required="required" id="inputDesc" name="desc" placeholder="Description" value="<?php echo $data['incdesc'];?>">
									</div>

									<!-- Planting Activity -->
									<div class="form-group">
										<label class="control-label" for="inputAct">Activity</label>
										<select class="form-control" required="required" id="inputActivity" name="activity" value="<?php echo $data['incact'];?>">
											<option></option>
											<option <?php if($data['incact'] == 'Tree Planting')echo 'selected="selected"'; ?> value="Tree Planting">Tree Planting</option>
											<option <?php if($data['incact'] == 'Mangrove Planting')echo 'selected="selected"'; ?> value="Mangrove Planting">Mangrove Planting</option>
										</select>
									</div>

				<br />
				<div class="form-actions text-center forms">
										<button type="submit" class="btn btn-success">Update</button>
										<a class="btn btn-default" href="./registration.php">Back</a>
									</div>
				</div></div></div>
			</div><!-- end of class span10 offset1-->
		</div><!-- end of class container-->


	</div>

	<?php include('footer.php'); ?>
	
	<!-- script for modal -->
	<script>
		$(document).ready(function(){
			$("#myBtn").click(function(){
				$("#myModal").modal();
			});
		});
	</script>
</body>
</html>