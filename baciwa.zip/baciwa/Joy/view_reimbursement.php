<?php 
include('php/login_success.php'); 
include('php/links.php');
?>


<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: reimbursement.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM reimbursement where rerid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
	<?php include('header.php'); ?>

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Reimbursement Expense</h1>
		</div>
	</div>

	<div class="container-fluid">
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="new_reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create Reimbursement Expense</a>
				<a href="reimbursement.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Reimbursement Expense</a>
			</div>
		</div>
		<div class="col-md-9 content">
			<div class="row" style="margin-top:15px">
				<div class="col-md-12"><strong style="font-size:24px">Reimbursement Details</strong>
				<hr>
				</div>
			</div>
			<script>
			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip(); 
			});
			</script>
				<div class="col-lg-9 main-content">
					<br />
                     
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td><strong>Date</strong></td>
									<td><?php echo $data['rerdate'];?></td>					
								</tr>

								<tr>
									<td><strong>Name</strong></td>
									<td><?php echo $data['rername'];?></td>					
								</tr>
								<tr>
									<td><strong>Amount</strong></td>
									<td><?php echo $data['reramount'];?></td>					
								</tr>
								<tr>
									<td><strong>In Payment For</strong></td>
									<td><?php echo $data['rerpayment'];?></td>					
								</tr>
								<tr>
									<td><strong>Payee Name</strong></td>
									<td><?php echo $data['rerpayname'];?></td>					
								</tr>
								<tr>
									<td><strong>Date of Issue</strong></td>
									<td><?php echo $data['rerpaydateissue'];?></td>					
								</tr>
								<tr>
									<td><strong>Witness Name</strong></td>
									<td><?php echo $data['rerwitname'];?></td>					
								</tr>
								<tr>
									<td><strong>Date of Issue</strong></td>
									<td><?php echo $data['rerwitdateissue'];?></td>					
								</tr>								
							</tbody>
						</table>
					</div>
					
					<div class="row text-center">
				<div class="form-actions">
					<a class="btn btn-info" href="reimbursement.php"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> &nbsp; Back</a>
					<a class="btn btn-info" href="?id=<?php echo $_GET['id'] ?>">View Liquidation &nbsp;<span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span></a>
				</div>
			</div>
		</div>
	</div>
</div>
	<?php include('footer.php'); ?>
</body>
</html>