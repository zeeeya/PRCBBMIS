<?php
     
    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
        $rerdate = $_POST['date'];
        $rername = $_POST['name'];
        $reramount = $_POST['amt'];
        $rerpayment = $_POST['payment'];
        $rerremarks = $_POST['remark'];

        $rerpayname  = $_POST['payname'];
        $rerpayadd = $_POST['payadd'];
        $rerpayissue = $_POST['payissue'];
        $rerpaycedula = $_POST['paycedula'];
        $rerpaydateissue = $_POST['paydate'];

        $rerwitname  = $_POST['witname'];
        $rerwitadd = $_POST['witadd'];
        $rerwitissue = $_POST['witissue'];
        $rerwitcedula = $_POST['witcedula'];
        $rerwitdateissue = $_POST['witdate'];
        
        echo $rerdate;
        echo $rername;
        echo $reramount;
        echo $rerpayment;
        echo $rerremarks;

        echo $rerpayname;
        echo $rerpayadd;
        echo $rerpayissue;
        echo $rerpaycedula;
        echo $rerpaydateissue;
             
        // validate input
        $valid = true;

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO reimbursement (rerdate,rername,rerpayment,reramount,rerremarks,rerpayname,rerpayadd,rerpayissue,rerpaycedula,rerpaydateissue,rerwitname,rerwitadd,rerwitissue,rerwitcedula,rerwitdateissue) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($rerdate,$rername,$rerpayment,$reramount,$rerremarks,$rerpayname,$rerpayadd,$rerpayissue,$rerpaycedula,$rerpaydateissue,$rerwitname,$rerwitadd,$rerwitissue,$rerwitcedula,$rerwitdateissue));
            Database::disconnect();
            header("Location: ../reimbursement.php");
        }
    }
?>