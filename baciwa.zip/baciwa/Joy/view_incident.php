<?php 
include('php/login_success.php'); 
include('php/links.php');
?>


<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: incident.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM incident where incid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();

        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM organization where orgid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($data['orgid']));
        $dataOrg = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
		
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
	<?php include('header.php'); ?>

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Incident Monitoring</h1>
		</div>
	</div>

	<div class="container-fluid">
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="new_incident.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Create new Incident Report</a>
				<a href="incident.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Incident List</a>
			</div>
		</div>
		<div class="col-md-9 content">
			<div class="row" style="margin-top:15px">
				<div class="col-md-12"><strong style="font-size:24px">Incident Details</strong>
				<a class="btn btn-info btn-sm" style="margin-top:-10px;margin-left:5px;" href="update_incident.php?id=<?php echo $_GET['id'] ?>" data-toggle="tooltip" title="Update this incident info.">
					<span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
				</a>
				<hr>
				</div>
			</div>
			<script>
			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip(); 
			});
			</script>
				<div class="col-lg-9 main-content">
					<br />
                     
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td><strong>Date</strong></td>
									<td><?php echo $data['incdate'];?></td>					
								</tr>
								<tr>
									<td><strong>Organization</strong></td>
									<td><?php echo $dataOrg['orgname'];?></td>					
								</tr>

								<tr>
									<td><strong>Name</strong></td>
									<td><?php echo $data['incname'];?></td>					
								</tr>
								<tr>
									<td><strong>Type of Incident</strong></td>
									<td><?php echo $data['inctype'];?></td>					
								</tr>
								<tr>
									<td><strong>Discription of Incident</strong></td>
									<td><?php echo $data['incdesc'];?></td>					
								</tr
								<tr>
									<td><strong>Activity</strong></td>
									<td><?php echo $data['incact'];?></td>					
								</tr>							
							</tbody>
						</table>
					</div>
					
					<div class="row text-center">
				<div class="form-actions">
					<a class="btn btn-info" href="incident.php"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> &nbsp; Back</a>
				</div>
			</div>
		</div>
	</div>
</div>
	<?php include('footer.php'); ?>
</body>
</html>