<?php 
include('php/login_success.php'); 
include('php/links.php');
include 'database.php';

// User Input
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = isset($_GET['per-page']) && $_GET['per-page'] <= 50 ? (int)$_GET['per-page'] : 5;

// Positioning
$start = ($page > 1) ? ($page * $perPage) - $perPage : 0;

// Query
$pdo = Database::connect();
$organization = $pdo->prepare("
	SELECT SQL_CALC_FOUND_ROWS * 
	FROM organization 
	ORDER BY orgname 
	LIMIT {$start},{$perPage}
");
$organization->execute();

$organization = $organization->fetchAll(PDO::FETCH_ASSOC);

// Pages
$total = $pdo->query("SELECT FOUND_ROWS() as total")->fetch()['total'];
$pages = ceil($total / $perPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./jquery-timepicker-1.3.2/jquery.timepicker.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

  
	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jquery-timepicker-1.3.2/jquery.timepicker.min.css"></script>
	
</head>
<body>
<!-- Header (to edit see header.php) -->
<?php include('header.php'); ?>
	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>
	
	<div class="container-fluid">

		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>
			</div>		
		</div>	
			
		<div class="col-lg-7 main-content">
			
			<div class="row" style="border-bottom:solid 1px;margin-bottom:15px;">
				<div class="col-md-7">
					<h2>Organization List</h2>
				</div>
				<div class="col-md-5 text-right" style="padding-top:20px;">
					<a href="new_organization.php" class="btn btn-success btn-md"><span class="glyphicon glyphicon-plus-sign"></span> Add Organization</a>
				</div>
			</div>
			
			<div class='row'>
				<div class='col-md-12'>

					<div class="table-responsive">
						<table class="table table-hover">
							<thead>
								<tr class="alert-info">
									<th>Name</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									
									foreach ($organization as $row) {
										echo '<tr>';
										echo '<td>'. $row['orgname'] . '</td>';
										echo '<td class="text-center">
												<a class="btn btn-warning btn-md" href="update_organization.php?id='.$row['orgid'].'" data-toggle="tooltip" title="Update"><span class="glyphicon glyphicon-pencil"></span></a>
												<a class="btn btn-danger btn-md" href="delete_organization.php?id='.$row['orgid'].'" data-toggle="tooltip" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>
											  </td>';
										echo '</tr>';
									}
									Database::disconnect();
								?>
				
								<script>
									$(document).ready(function(){
										$('[data-toggle="tooltip"]').tooltip();
									});
									
									$(document).ready(function(){
										 $('.tooltip1').tooltip();
									});
									
									$(document).ready(function(){

									   $('.push').click(function(){
										  var essay_id = $(this).attr('value');

											$.ajax({
												type : 'post',
												url :  'organization_details.php', // in here you should put your query 
												data :  'post_id='+ essay_id, // here you pass your id via ajax .
														 // in php you should use $_POST['post_id'] to get this value 
												success : function(r){
													// now you can show output in your modal 
													$('#myModal').show();  // put your modal id 
													$('.something').show().html(r);
												}
											});
										});
									});
								</script>
							</tbody>
						</table>
					</div>
					
					
					<nav class="text-center">
						  <ul class="pagination">
							<?php if($page > 1){?>
								<li>
								  <a href="?page=<?php echo $page-1; ?>&per-page=<?php echo $perPage; ?>" aria-label="Previous">
									<span aria-hidden="true">&laquo;</span>
								  </a>
								</li>
							<?php }?>
							
							<?php for($x = 1; $x <= $pages; $x++) : ?>
								<li <?php if($page === $x){ echo 'class="active"'; }?> ><a href="?page=<?php echo $x; ?>&per-page=<?php echo $perPage; ?>"><?php echo $x; ?></a></li>
							<?php endfor; ?>
							
							<?php if($page < $pages){?>
								<li>
								  <a href="?page=<?php echo $page+1; ?>&per-page=<?php echo $perPage; ?>" aria-label="Next">
									<span aria-hidden="true">&raquo;</span>
								  </a>
								</li>
							<?php }?>
							
						  </ul>
					</nav>
					
				</div>
			</div>	
		</div>
	</div>
		
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>
</body>
</html>