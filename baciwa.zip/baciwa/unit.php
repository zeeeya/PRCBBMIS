<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Budget</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid content">
	<br>
	<div class="panel panel-primary">
		<div class="panel-heading content">
				<strong>Unit LIST&nbsp;&nbsp;&nbsp;</strong>
				<a type="button" class="btn btn-info btn-md text-center" data-toggle="modal" data-target="#addUnit" rel="tooltip" title="Add New Unit"><span class="glyphicon glyphicon-plus"></span><strong>&nbsp;New Unit</strong></a>
		</div>
		<div class="panel-body" style="margin:0 5%;">
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
						<tr class="alert-info">
							<th>Unit ID</th>
							<th>Unit Abbreviation</th>
							<th>Unit Name</th>
							<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
							include 'database.php';
							$pdo = Database::connect();
							$sql = 'SELECT * FROM unit ORDER BY unitdesc';
							foreach ($pdo->query($sql) as $row) {
							echo '<tr>';
								echo '<td>'. $row['unitid'] . '</td>';
								echo '<td>'. $row['unitabbr'] . '</td>';
								echo '<td>'. $row['unitdesc'] . '</td>';
								echo '<td class="text-center">
										<button type="button" class="btn btn-warning btn-md updateB" rel="tooltip" title="Update Item" data-toggle="modal" data-target="#updateModal" value="'.$row['unitid'].'"><span class="glyphicon glyphicon-pencil"></span></button>
										<button type="button" class="btn btn-danger btn-md deleteB" rel="tooltip" title="Delete Item" data-toggle="modal" data-target="#myModal" value="'.$row['unitid'].'"><span class="glyphicon glyphicon-trash"></span></button>
									  </td>';
								echo '</tr>';
							}
							Database::disconnect();
							?>
							
							<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip();
									$('.btn').tooltip();
								});
							</script>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
</div>

<?php
include('update_item.php');
include('new_unit.php');
include('delete_item.php');
include('footer.php'); 
?>
</body>
</html>