<?php 
include('php/login_success.php'); 
include('php/links.php');
?>


<?php
    require 'database.php';
    $id = null;
    echo $_GET['id'];
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( !empty($_POST)) {
        // keep track post values
        $id = $_POST['id'];
         
        // delete data
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM organization WHERE orgid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        Database::disconnect();
		header("Location: ./view_organization.php");
         
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
<!-- Header (to edit see header.php) -->
<?php include('header.php'); ?>

	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>


	<div class="container-fluid">
	
		<!-- side bar -->
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>		
			</div>		
		</div>
				
		<!--start of Content -->
				
		<div class="container col-lg-7 content">
			<h2>Remove Organization from the list?</h2>
			<hr />
			<br />
			                     
            <form class="form-horizontal" action="delete_organization.php" method="post">
                <input type="hidden" name="id" value="<?php echo $id;?>"/>
				<?php
					$pdo = Database::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "SELECT * FROM organization where orgid = ?";
					$q = $pdo->prepare($sql);
					$q->execute(array($id));
					$data = $q->fetch(PDO::FETCH_ASSOC);
					Database::disconnect();
					
					echo '<div class="alert alert-warning" role="alert">Proceed in deleting this organization: '.$data['orgname'].' ?</div>';
				?>
					<div class="form-actions text-right">
                        <button type="submit" class="btn btn-danger">Yes</button>
                        <a class="btn" href="view_organization.php">No</a>
                    </div>
            </form>
		</div><!-- end of class container-->
	</div>
	
	<!-- footer (to edit see footer.php) -->
	<?php include('./footer.php'); ?>

</body>
</html>
<?php /*

*/
?>