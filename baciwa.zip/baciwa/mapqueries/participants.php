<?php
require '../database.php'; 

if(isset($_POST['id'])){
	$db = Database::connect();
	$participants = $db->prepare("
		SELECT SQL_CALC_FOUND_ROWS * 
		FROM participants 
		WHERE schedid = '".$_POST['id']."'
		&& (treepatch LIKE '' && treeqty = 0)
	");
	$participants->execute();
	$participants = $participants->fetchAll(PDO::FETCH_ASSOC);
	$total = $db->query("SELECT FOUND_ROWS() as total")->fetch()['total'];

?>

	<select class="form-control" id= "participantSelection" name="field_4" required="required">
		<option value="" selected disabled>-- Select Activity Code --</option>
			<?php
				foreach ($participants as $participant){
					echo '<option value="'.$participant['partid'].'">'.$participant['partname'].'</option>';
				}
			?>
	</select>						

	
	<!-- script code for dynamic select -->
	<script>
		$(document).ready(function(){
			var totalRow = <?php echo $total?>;
			if(totalRow > 0){
				$('#participantSelection').change(function(){
					var d = "id="+$( "#participantSelection" ).val();
					console.log(d);
					$.ajax({
						url   : 'mapqueries/participantsdetails.php',
						data  : d,
						type : 'POST',
						success : function(data){
							$('#partnum').html(data);
							$('#participantdiv').html('');
						}
					})
				})
			}else{
				$('#participants').html('<input type="text" class="form-control" value="" name="field_5" readonly required="required">');
				$('#participantdiv').html('<div class="alert alert-warning" role="alert"><strong>Oops!</strong> All participants in this activity schedule has been assigned to a patch.</br> To change assigned patch click <a class="btn btn-sm btn-warning" href="patchregistration.php">Here!</a></div>');
			}
		})
	</script>
<?php
}else
	echo 'false';

?>
