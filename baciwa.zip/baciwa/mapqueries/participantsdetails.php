<?php
require '../database.php'; 

if(isset($_POST['id'])){
	$db = Database::connect();
	$participants = $db->prepare("
		SELECT * 
		FROM participants 
		WHERE partid = '".$_POST['id']."'
		LIMIT 1
	");
	
	$participants->execute();
	$data = $participants->fetch(PDO::FETCH_ASSOC);

?>
	<input type="text" class="form-control" value="<?php echo $data['partnum']; ?>" name="field_5" readonly >
<?php
}else
	echo 'false';

?>