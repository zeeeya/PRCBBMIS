<?php
require '../database.php'; 

if(isset($_POST['id'])){
	$db = Database::connect();
	$schedules = $db->prepare("
		SELECT * 
		FROM schedule 
		WHERE regid = '".$_POST['id']."'"
	);
	$schedules->execute();
	$schedules = $schedules->fetchAll(PDO::FETCH_ASSOC);
	
?>
	<select class="form-control" id= "scheduleSelection" name="field_3" required="required">
		<option value="" selected disabled>-- Select Activity Code --</option>
			<?php
				foreach ($schedules as $schedule){
					$option = $schedule['scheddate'].', ' .$schedule['schedtime'];
					echo '<option value="'.$schedule['schedid'].'">'.$option.'</option>';
				}
			?>
	</select>
	<!-- script code for dynamic select -->
	<script>
		$(document).ready(function(){
			$('#scheduleSelection').change(function(){
				var d = "id="+$( "#scheduleSelection" ).val();
				console.log(d);
				$.ajax({
					url   : 'mapqueries/participants.php',
					data  : d,
					type : 'POST',
					success : function(data){
						$('#participants').html(data);
						$('#partnum').html('<input type="text" class="form-control" value=""  name="field_5" readonly required="required">');
					}
				})
			})
		})
	</script>
<?php
}else
	echo 'false';

?>
