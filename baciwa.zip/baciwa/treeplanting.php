<?php 
include('php/login_success.php'); 
include('php/links.php');
include('database.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/leaflet.markercluster.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css' rel='stylesheet' />
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css' rel='stylesheet' />

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
		<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
		<style>
			#map 
			{ 	margin:3% 3%;
				width:95%; 
				height:70%; 
			}
		</style>


	 </head>
	<body>
	<?php include('header.php'); //nav bar and header?> 
	<script>
	
		$(document).ready(function() {
			$(".modal").on("hidden.bs.modal", function() {
				$('#registrationcode [value=""]').attr('selected',true);
				$('#schedule').html('<input type="text" class="form-control" name="field_3" required="required" value="" readonly >');
				$('#participants').html('<input type="text" class="form-control" name="field_4 value="" readonly required="required">');
				$('#partnum').html('<input type="text" class="form-control" value="" name="field_5 readonly required="required">');
				$("#patchNum").val('');
			});
		});
	</script>
	<!-- Modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="myModal">
		<div class="modal-dialog" style="margin-top:10%">
			<div class="modal-content">
				<div class="modal-header btn-success">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch</h4>
				</div>
				<div class="modal-body">
					<form action="php/updatesinglepatch.php	" method="POST">
					<div class="row">
						<div class="col-md-4"><label>Activity Code</label></div>
						<div class="col-md-7">
							<select class="form-control" id= "registrationcode" name="field_1" required="required">
								<option value="" selected disabled>-- Select Activity Code --</option>';
									<?php
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE regact LIKE 'Tree Planting'";
											foreach ($pdo->query($sql) as $row){
													$option = $row['regid'].': ' .$row['orgname'].' ';
													echo '<option value="'.$row['regid'].'">'.$option.'</option>';
											}
													
										Database::disconnect();
									?>
							</select>
						</div>
						
						<!-- script code for dynamic select -->
						<script>
							$(document).ready(function(){
								
								$('#registrationcode').change(function(){
									
									var d = "id="+$( "#registrationcode" ).val();
									console.log(d);
									$.ajax({
										url   : 'mapqueries/schedule.php',
										data  : d,
										type : 'POST',
										success : function(data){
											$('#schedule').html(data);
											$('#participants').html('<input type="text" class="form-control" value="" readonly required="required">');
											$('#partnum').html('<input type="text" class="form-control" value="" readonly required="required">');
										}
									})
								})
							})
						</script>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-4"><label>Activity Type</label></div>
						<div class="col-md-7">
							<input type="text" class="form-control" id="activity_type" value="Tree Planting" name="field_2" required="required" readonly >
						</div>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-4"><label>Schedule</label></div>
						<div class="col-md-7" id="schedule">
							<input type="text" class="form-control" name="field_3" required="required" value="" readonly >
						</div>
					</div>
					<br/>
					
					<div class="row">
						<div class="col-md-4"><label>Participants</label></div>
						<div class="col-md-7" id="participants">
							<input type="text" class="form-control" value="" name="field_4" required="required" readonly >
						</div>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-4"><label>No. of Participants</label></div>
						<div class="col-md-7" id="partnum">
							<input type="text" class="form-control" value="" name="field_5" required="required" readonly >
						</div>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-4"><label>Patch</label></div>
						<div class="col-md-7">
							<input type="text" id="patchInput" class="form-control" name="field_6" required="required" readonly >
						</div>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-4"><label>No. of Seed Planted</label></div>
						<div class="col-md-7">
							<input type="text" id="patchNum"class="form-control" pattern="[0-9]{1,5}" name="field_7" required="required" value="" title="Enter a digit(s) [0-9].">
						</div>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-11"  id="participantdiv"><!-- error message will be displayed here --></div>
					</div>
				</div>
				
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Save changes</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</form>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- end of modal -->
	
	<div class="container-fluid">
	
		<!-- <div style="margin-left:350px" id='map'></div> -->
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredtree.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			
			</div>
		</div>
		
		<div class="col-md-9">
			<br />
			<form  method="post" action="searching.php"  id="searchform"> 
			<div class="row">
			
				<div class="col-lg-12">
					<h3><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</h3>
					<hr/>
				</div><!-- /.col-lg-6 -->
				
				<div class="col-lg-12">
					
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Search Organization..." name="searchInput">
						<span class="input-group-btn">
						<button class="btn btn-default" type="submit">Go!</button>
					  </span>
					</div><!-- /input-group -->
				</div><!-- /.col-lg-6 -->
			</div>	
			</form>
			<div id='map'></div>
		</div>
	</div>
<style>
.map-legend ul {
  list-style: none;
  padding-left: 0;
  }
.map-legend .swatch {
  width:20px;
  height:20px;
  float:left;
  margin-right:10px;
  }
.leaflet-popup-close-button {
  display: none;
  }
.leaflet-popup-content-wrapper {
  pointer-events: none;
  }
</style>

<script src='php/treeplanting.php'></script>
	
<script>
// disable right clicking on map
document.oncontextmenu = function() {
    return false;
}

// Map box codes and functionality
L.mapbox.accessToken = 'pk.eyJ1Ijoiam95bWVyaWxsIiwiYSI6ImNpaWgwcW5ndTAycTR2dG0xZnlocHppbG4ifQ.XIsgAOt_JunkNd-8HmZ6-Q';
var map = L.mapbox.map('map', 'mapbox.satellite').setView([10.66, 123.148], 16);

var popup = new L.Popup({ autoPan: false });

  var statesLayer = L.geoJson(treepatches,  {
      style: getStyle,
      onEachFeature: onEachFeature
  }).addTo(map);

  function getStyle(feature) {
      return {
          weight: 2,
          opacity: 0.1,
          color: 'black',
          fillOpacity: 0.7,
          fillColor: getColor(feature.properties.density),
      };
  }

  // get color depending on population density value
  function getColor(d) {
      return d > 1000 ? '#004d1a' :
          d > 500  ? '#006622' :
          d > 200  ? '#009933' :
          d > 100  ? '#00cc44' :
          d > 50   ? '#00ff55' :
          d > 20   ? '#33ff77' :
          d > 10   ? '#66ff99' :
          '#ccffdd';
  }

  function onEachFeature(feature, layer) {
      layer.on({
          mousemove: mousemove,
          mouseout: mouseout,
          click: zoomToFeature,
		  mousedown: rightclick
      });
  }

  var closeTooltip;

  function mousemove(e) {
      var layer = e.target;

      popup.setLatLng(e.latlng);
       popup.setContent('<div class="marker-title"><span class="glyphicon glyphicon-tree-conifer" aria-hidden="true"></span>&nbsp;Click to view <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;participants in <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + layer.feature.properties.name + '</div>' +
          '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + layer.feature.properties.density + ' Trees Planted');

      if (!popup._map) popup.openOn(map);
      window.clearTimeout(closeTooltip);

      // highlight feature
      layer.setStyle({
          weight: 3,
          opacity: 0.3,
          fillOpacity: 0.9
      });

      if (!L.Browser.ie && !L.Browser.opera) {
          layer.bringToFront();
      }
  }

  function mouseout(e) {
      statesLayer.resetStyle(e.target);
      closeTooltip = window.setTimeout(function() {
          map.closePopup();
      }, 100);
  }
  
  function zoomToFeature(e) {
	 //map.fitBounds(e.target.getBounds());
	 var layer = e.target;
	 window.location = layer.feature.url;
  }

  function rightclick(e){
	var rightclick;
	a = window.event;
	if (a.which) rightclick = (a.which == 3);
	else if (a.button) rightclick = (a.button == 2);
	
	if(rightclick == true){
		var layer = e.target;
		$("#patchInput").val(layer.feature.properties.name);
		$("#myModal").modal();
	}
  }
  
  map.legendControl.addLegend(getLegendHTML());

  function getLegendHTML() {
    var grades = [0, 10, 20, 50, 100, 200, 500, 1000],
    labels = [],
    from, to;

    for (var i = 0; i < grades.length; i++) {
      from = grades[i];
      to = grades[i + 1];

      labels.push(
        '<li><span class="swatch" style="background:' + getColor(from + 1) + '"></span> ' +
        from + (to ? '&ndash;' + to : '+')) + '</li>';
    }

    return '<span>Trees Planted</span><ul>' + labels.join('') + '</ul>';
  }

</script>

<?php
include('footer.php'); 
?>

</body>
</html>