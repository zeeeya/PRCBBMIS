<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
	
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: registration.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM schedule where schedid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
		
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM registration where regid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($data['regid']));
        $dataReg = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
		
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM organization where orgid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($dataReg['orgid']));
        $dataOrg = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
    }
	

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSS import Files -->
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/sidebar.css">
  <link rel="stylesheet" href="./jquery-timepicker-1.3.2/jquery.timepicker.min.css">

  
  <!-- JQuery and Javascript File -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script type="text/javascript" src="./js/bootstrap.min.js"></script>
  <script type="text/javascript" src="./jquery-timepicker-1.3.2/jquery.timepicker.min.css"></script>
  
	<!-- Date picker-->
	<link rel="stylesheet" href="css/datepicker.css">
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">

</head>
<body>
<div>

    <div class="navbar navbar-default navbar-fixed-top" style= "z-index:99999"> <!-- navbar-fixed-top -->
      <div class="container">
        <div class="navbar-header">          	
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <a class="navbar-brand" href="home.php"><img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" /></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href=" <?php  echo($Home) ?>">HOME</a></li>
            <li><a href=" <?php  echo($Registration) ?>">REGISTRATION</a></li>
            <li><a href=" <?php  echo($Budget) ?>">BUDGET</a></li>
            <li><a href=" <?php  echo($Liquidation) ?>">LIQUIDATION</a></li>
            <li><a href=" <?php  echo($Miscellaneous) ?>">MISCELLANEOUS</a></li>
            <li><a href=" <?php  echo($Report) ?>">REPORTS</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
        	<li><a href=" <?php echo($Signup) ?>"><span class="glyphicon glyphicon-user"></span> Add Account</a></li>
        	<li><a href=" <?php echo($Logout) ?>"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      	  </ul>
          
        </div>
      </div>
    </div>

    <div class="jumbotron home-header">
    	<table>
        	<tr>
            	<td><img src="img/baciwa_thesis.png" alt="thesis-logo"/></td>
            	<td>
        			<h1>Bacolod City Water District</h1> 
  					<p>Planting Activity Management System</p>        
                </td>                
            </tr>
  		</table> 
	</div>

</div>

	<div class="container-fluid main-wrapper">

		<div class="row">
			<div class="container-fluid menu-title">
			<h1>Registration</h1>
			</div>
			<div class="row">
				<div class="col-lg-3 menu-sidebar">
					<!-- side bar -->
					<div class="sidebar-nav">
						  <div class="navbar navbar-default" role="navigation" >
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							  </button>
							  <span class="visible-xs navbar-brand" style="padding-top:16px;">Menu</span>
							</div>
							<div class="navbar-collapse collapse sidebar-navbar-collapse">
							  <ul class="nav navbar-nav">
								<li><a href="view_organization.php">Register an Organization</a></li>
								<li><a href="new_registration.php">Register New Activity</a></li>
								<li><a href="registration.php">View Registration List</a></li>
							  </ul>
							</div><!--/.nav-collapse -->
						  </div>
					</div>
				</div>
				
				<!--start of Content -->
				
				<div class="container col-lg-9 main-content">
					<div class="col-lg-12">
						<div class="row">
							<h2 style="margin-left:10px;">Participants</h2>
							<br />
						</div>
						
						<div class="row">
							<form class="form-horizontal" role="form" action='./php/participantsCreate.php?id=<?php echo $_GET['id'] ?>' method="POST">
								
								<p>Organization Name: <strong><?php echo $dataOrg['orgname'];?></strong></p>
								<p>Schedule: <strong> <strong><?php echo $data['scheddate'].', '.$data['schedtime']; ?></strong></p>
								<br />
								<div class="col-lg-7 forms">

									<!-- Participants Name -->
									<div class="form-group">
										<label for="inputDate">Participants Name </label>
										<input type="text" class="form-control" required="required" id="inputDate" name="participantsname" placeholder="Enter Name">
										<!-- <input type="text" id="inputSchedule" > -->
									</div>

									<!-- No. of Participants -->
									<div class="form-group">
										<label for="inputTimeStart">No. of Participants</label>
										<input type="text" class="form-control" required="required" id="inputTimeStart" name="noofparticipants" placeholder="Enter Number">
									</div>

									<div class="form-actions text-right forms">
										<button type="submit" class="btn btn-success">Add Participants</button>
										<a class="btn" href="./view_participants.php?id=<?php echo $_GET['id'] ?>">Back</a>
									</div>
									
								</div>
							</form>		
							
						</div>
						
							
							
							
					</div><!-- end of class span10 offset1-->
				</div><!-- end of class container-->
			</div>
		</div>
	</div>

</body>
</html>