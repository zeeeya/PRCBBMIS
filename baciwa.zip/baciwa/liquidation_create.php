	<?php 
include('php/login_success.php'); 
include('php/links.php');
require 'database.php';
?>

<?php
	$id = $_GET['id'];
	
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM budget where budcode = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();

	function getParticipantsNo($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM schedule WHERE regid = '".$id."'";
		
		$total_no_of_participants = 0;
		foreach ($pdo->query($sql) as $dataSched) {
			$sql = 'SELECT * FROM participants WHERE schedid = '.$dataSched['schedid'];
				foreach ($pdo->query($sql) as $dataPart) {
					$total_no_of_participants += $dataPart['partnum'];
				}
			}
		Database::disconnect();
			
		if($total_no_of_participants > 0){
			return $total_no_of_participants;
		}else{
			return '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;"><strong>Attention! </strong>Please enter participants <a href="view_schedule.php?id='.$_GET['id'].'" class="alert-link">Click Here!</a></div>';
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- Modals Section -->
<!-- Modal for error -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:10%">
		<div class="modal-content">
			<div class="modal-header btn-danger">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">System Error</h4>
			</div>
			<div class="modal-body content" id="errormodal">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
			</div>
		</div>
	</div>
</div>

<!-- Modal for adding items for liquidation -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:10%">
		<div class="modal-content">
			<div class="modal-header btn-info">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Add Item</h4>
			</div>
			<div class="modal-body content">
			
					<div id="errordisplay"></div>
					<!-- OR Number -->
					<div class="form-group row">
						<div class="col-xs-3"><label for="ornum">OR Number</label></div>
						<div class="col-xs-7">
							<input type="text" class="form-control" required="required" id="ornum" name="or_number">
						</div>
					</div>
					
					<!-- Store Name -->
					<div class="form-group row">
						<div class="col-xs-3"><label for="itemname">Store Name</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="itemname" name="item_name"></div>
					</div>

					<!-- Quantity 
					<div class="form-group row">
						<div class="col-xs-3"><label for="itemquantity">Quantity</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="itemquantity" name="item_quantity"></div>
					</div> -->
					
					<!-- Item Unit 
				<div class="form-group row">
				<div class="col-xs-3"><label class="control-label" for="itemunit">Item Unit</label></div>
				<div class="col-xs-7">
					<span class="input-group-btn">
						<select class="form-control" require="required" id="itemunit" name="itemunit" onChange="showUser(this.value)">
												<option selected="selected" disabled>-- Select Unit --</option>
											<?php
												$pdo = Database::connect();
												$sql = 'SELECT * FROM unit ORDER BY unitdesc';
												foreach ($pdo->query($sql) as $row) {
													echo '<option value="'. $row['unitdesc'] . '" >' . $row['unitdesc'] . '</option>';
												}
												Database::disconnect();
											?>
											</select>
					</div>		
				</div>		-->			
					<!-- Price -->
					<div class="form-group row">
						<div class="col-xs-3"><label for="itemprice">Price</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="itemprice" name="item_price"></div>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" id="addbutton">Add Items</button>
				<button type="button" class="btn btn-default" id="closebutton" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!-- end of modal section -->

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Liquidation</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid content">
	
	<div class="row">

	</div>
	<br />

	<div class='row'>
		<div class='col-md-12'>

					<div class="panel panel-primary">
						<div class="panel-heading">
							<div class="row">
								<div class="col-sm-9">
								<h3 class="panel-title">Activity Details</h3>
								</div>
								<div class="col-sm-3 text-right" id="clockDisplay"></div>
							</div>
						</div>
						
						
						<script type="text/javascript" language="javascript">
							function renderTime(){
								
								var currentTime = new Date();
								var diem = "AM";
								var month = currentTime.getMonth() + 1;
								var year = currentTime.getFullYear();
								var day = currentTime.getDate();
								var h = currentTime.getHours();
								var m = currentTime.getMinutes();
								var s = currentTime.getSeconds();
								
								if(h == 0){
									h=12;
								}else if(h > 12){
									h = h -12;
									diem = "PM";
								}
								
								if(h < 10){
									h = "0"+ h;
								}
								if(m < 10){
									m = "0"+ m;
								}
								if(s < 10){
									s = "0"+ s;
								}
								
								var myClock = document.getElementById('clockDisplay');
								myClock.textContent = "Date: " + month + "/" + day + "/" + year + ", " + h + ":" + m + ":" + s + " " + diem;
								
								setTimeout('renderTime()', 1000);
							}
							renderTime();
						</script>
						
						<div class="panel-body" id="registrationPanel">
							<?php
								$pdo = Database::connect();
								$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								//SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid
								$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE registration.regid = ?";
								$q = $pdo->prepare($sql);
								$q->execute(array($data['regid']));
								$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
								Database::disconnect();
							?>	

							
							<div class="table-responsive">
								<table class="table">
									<tbody>
										<tr>
											<td><strong>Registration Code</strong></td>
											<td><?php echo $data['regid'] ?></td>	
											<td><strong>Subject of the Budget</strong></td>
											<td><?php echo $data['budsub'] ?></td>	
										</tr>
										
										<tr>
											<td><strong>Organization</strong></td>
											<td><?php echo $dataOrg['orgname'] ?></td>						
											<td><strong>Address</strong></td>
											<td><?php echo $dataOrg['orgadd'] ?></td>					
										</tr>
										
										<tr>
											<td><strong>Type of Activity</strong></td>
											<td><?php echo $dataOrg['regact'] ?></td>					
											<td><strong>Organization Type</strong></td>
											<td><?php echo $dataOrg['orgtype'] ?></td>					
										</tr>
								
										<tr>
											<td style="vertical-align:text-top"><strong>No. of Participants</strong></td>
											<td><?php echo getParticipantsNo($dataOrg['regid']) ?></td>					
											<td><strong>Contact Person</strong></td>
											<td><?php echo $dataOrg['regcperson'] ?></td>					
										</tr>
										
										<tr>
											<td><strong>Contact Number</strong></td>
											<td><?php echo $dataOrg['regcnum'] ?></td>
											<td style="vertical-align:text-top"><strong>Remarks</strong></td>
											<td style="vertical-align:text-top"><?php echo $dataOrg['regmemo'] ?></td>					
										</tr>
										
										<tr>
											<td style="vertical-align:text-top"><strong>Schedule(s)</strong></td>
											<td style="vertical-align:text-top">
												<?php
													$pdo = Database::connect();
													$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
													$sql = "SELECT * FROM schedule WHERE regid = '".$data['regid']."'";
															
														foreach ($pdo->query($sql) as $row){
															echo $row['scheddate'].'<br />';
														}
														
													Database::disconnect();
												?>
											</td>
											<td></td>
											<td></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" >
			<div class="panel panel-primary">
			
				<div class="panel-heading">
					<h3 class="panel-title"><strong>Budget Proposal</strong></h3>
				</div>
				<div class="panel-body">

					<!-- Activity Code -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="budgetcode">Budget Code</label></div>
						<div class="col-xs-7">
							<input type="text" class="form-control" required="required" id="budgetcode" name="activity_budget" value="<?php echo $id ?>" readonly >
						</div>
					</div>
					
					<!-- Subject of the Budget -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="inputSubject">Budget Status</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="inputSubject" name="subject_budget" value="<?php echo $data['budstat']; ?>" readonly ></div>
					</div>

					<!-- Date Issue -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="inputDateIssue">Date Issue</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="inputDateIssue" name="dateissueb" placeholder="Date Issue" value='<?php echo date("m/d/Y"); ?>' readonly></div>
					</div>
										
					<div class="panel panel-info">
						<div class="panel-heading">
							<h3 class="panel-title">List of Item(s)</h3>
						</div>
						<div class="panel-body" id="registrationPanel">
							
							<div class="row">
								<div class="col-md-12">
									<table class="table table-bordered">
										<thead>
											<tr>
												<th class="col-sm-2">Code</th>
												<th class="col-sm-4">Name</th>
												<th class="col-sm-2">Quantity</th>
												<th class="col-sm-2">Unit</th>
												<th class="col-sm-2">Price</th>
											</tr>
										</thead>
										<tbody>
											
												<?php
													$pdo = Database::connect();
													$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
													$sql = "SELECT * FROM itembudget WHERE budcode = '".$id."'";
													$total = 0;	
													foreach ($pdo->query($sql) as $row){
														echo '<tr><td>'.$row['itembudid'].'</td>';
														echo '<td>'.$row['itemname'].'</td>';
														echo '<td>'.$row['itemquantity'].'</td>';
														echo '<td>'.$row['itemunit'].'</td>';
														echo '<td>'.$row['itemprice'].'</td></tr>';
														$total = $total + $row['itemprice'];
													}
													
													Database::disconnect();
												?>
											
										</tbody>
									</table>
								</div>
							</div>
							
							
						</div>
					</div>
				</div>
			</div>

		</div>
		<div class="col-sm-6" >
			<div class="panel panel-primary">
			  <div class="panel-heading">
				<h3 class="panel-title"><strong>Purchased Items</strong></h3>
			  </div>
			  <div class="panel-body">
				<div class="col-md-12">
					<div class="form-group row">
						<div class="col-xs-5"><label for="ornum">Subject of the Liquidation</label></div>
						<div class="col-xs-7">
							<input type="text" class="form-control" required="required" id="subject" name="subject">
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<button type="button" class="btn btn-info btn-md col-sm-12" style="margin-bottom:10px;" data-toggle="modal" data-target="#addModal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Add Item</button>
				</div>
				
				
				<div class="row">
					<div class="col-md-12">
						<table class="table table-bordered" id="myTable">
							<thead>
								<tr>
									<th class="col-sm-3">OR No.</th>
									<th class="col-sm-5">Store Name</th>
									<th class="col-sm-3">Amount</th>
									<th class="col-sm-1"></th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			  </div>
			</div>
		</div>
	</div>
	
<div class="row">
	<div class="col-md-12">
		<!-- Subject of the Budget -->
		<div class="panel panel-primary">
			<div class="panel-body">
				<form class="form-inline text-right" role="form">	
					<div class="form-group col-sm-12">
						<label for="total">Total Budgeted Items:</label>
						<input type="text" class="form-control text-right" id="totalBudget" value="<?php echo sprintf('%.2f', $total); ?>" readonly>
					</div>
					<div class="form-group col-sm-12">
						<label for="total">Total Liquidated Items:</label>
						<input type="text" class="form-control text-right" id="totalLiquidation" value="0.00" readonly>
					</div>		
					<div class="form-group col-sm-12">
						<label for="total">Total Money Spent:</label>
						<input type="text" class="form-control text-right" id="totalMoney" value="0.00" readonly>
					</div>								
				</form>
			</div>
		</div>
	</div>
</div>	
	<div id="display"></div><!-- display query -->
	
	<div class="row text-center">
		<div class="col-md-12">
			<a type="button" class="btn btn-success" id="saveButton">Liquidate</a>
			<a type="button" class="btn btn-info" href="view_liquidation.php">Back</a>
		</div>
	</div>
	<!-- Tooltip -->
<script>
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();
		$('.btn').tooltip();
		
		$('#closebutton').click(function(){
			$('#errordisplay').html('');
		});
		$('#addbutton').click(function(){
			var a = $( "#ornum" ).val();
			var b = $( "#itemname" ).val();
			var q = $( "#itemprice" ).val();
			
			if(!a || 0 === a.trim().length){
				data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Please enter OR Number</div><br/>';
				$('#errordisplay').html(data);
			}else if(!b || 0 === b.trim().length){
				data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Please enter Item Name</div><br/>';
				$('#errordisplay').html(data);
			}else if(!$.isNumeric(q) || 0 > q){
				data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Please enter correct price value</div><br/>';
				$('#errordisplay').html(data);
			}else{
				
				if(!itemExist(b)){				
					var table = document.getElementById("myTable");
					var row = table.insertRow(1);
					
					var cell1 = row.insertCell(0);
					var cell2 = row.insertCell(1);
					var cell3 = row.insertCell(2);
					var cell4 = row.insertCell(3);
					
					cell1.innerHTML = a;
					cell2.innerHTML = b;
					cell3.innerHTML = q;
					cell4.innerHTML = '<button class="btn btn-default btn-xs removeItem"><span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span></button>';
					
					cleardata();
				}else{
					data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Item already exist</div><br/>';
					$('#errordisplay').html(data);
				}
			}
		});
		
		//POST jquery process
		
	});
	
	//function to delete items in the selected row
	$(document).on('click', 'button.removeItem', function () { // <-- changes
		$(this).closest('tr').remove();
		$("#totalLiquidation").val(getTotal());
		getGrandTotal();
		
		return false;
	 });
	 
	function cleardata(){
		$("#ornum").val("");
		$("#itemname").val("");
		$("#itemprice").val("");
		
		//clear message error
		$('#errordisplay').html('');
		
		//get the total value in the table
		$("#totalLiquidation").val(getTotal());
		
		//get the total money
		getGrandTotal();
	}
	
	function itemExist(itemName){
	
		var size = document.getElementById("myTable").rows.length;
		var exist = false;
		for(var i = 0;i < size;i++){
			var d = document.getElementById("myTable").rows[i].cells[1].innerHTML;
			if(d === itemName)
				exist = true;
		}
		
		return exist;
	}
	
	function getTotal(){
		
		var size = document.getElementById("myTable").rows.length;
		var total = 0;

		if(size > 0)
			for(var i = 1;i < size;i++){
				var d = document.getElementById("myTable").rows[i].cells[2].innerHTML;
				total += parseFloat(d);
			}
		
		return parseFloat(total).toFixed(2);
	}
	
	function getGrandTotal(){
		totalbudget = $("#totalBudget").val();
		totalliquidation = parseFloat($("#totalLiquidation").val());
		total = totalbudget - totalliquidation;
		
		$("#totalMoney").val(parseFloat(total).toFixed(2));
	}
	
	//Getting the data from the table
	function storeTblValues()
	{
		var TableData = new Array();

		$('#myTable tr').each(function(row, tr){
			TableData[row]={
				"or_number" : $(tr).find('td:eq(0)').text()
				, "name" :$(tr).find('td:eq(1)').text()
				, "price" : $(tr).find('td:eq(2)').text()
			}    
		}); 
		TableData.shift();  // first row will be empty - so remove
		return TableData;
	}

	$(document).ready(function(){
		$('#saveButton').click(function(){
			
			var TableData, bcode, ltotal, gtotal;
			TableData = JSON.stringify(storeTblValues());
			subject = $('#subject').val();
			bcode = $('#budgetcode').val();
			ltotal = $('#totalLiquidation').val();
			gtotal = $('#totalMoney').val();
			
			if(ltotal <= 0){
				data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Total Liquidated Item is less than or equal zero</div><br/>';
				$('#display').html(data);
			}else if(!subject || 0 === subject.trim().length){
				data = 	'<div class="alert alert-danger" role="alert" style="margin-bottom:0px;"><strong>Error! </strong>Total Subject for liquidation is required</div><br/>';
				$('#display').html(data);		
			}else{
				$.ajax({
					url   : 'php/liquidationCreate.php',
					data  : {pTableData: TableData, budgetcode: bcode, liquidationTotal: ltotal, total: gtotal, subject: subject},
					type : 'POST',
					success : function(data){
						$('#display').html(data);
						window.location = "view_liquidation.php";
					}
				})
			}
			
		})
	})
</script>

<div class="row">
<form class="form-horizontal" role="form" action='./php/liquidationCreate.php' method="POST">
	<?php
	include('footer.php'); 
	?>
</div>
</body>
</html>