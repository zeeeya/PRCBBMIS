<?php

include_once 'database.php';

// Query for bugdet approval
$pdo = Database::connect();
$notification = $pdo->prepare("
	SELECT SQL_CALC_FOUND_ROWS * 
	FROM budget
	WHERE budstat LIKE 'Pending'
");
$notification->execute();
$notification = $notification->fetchAll(PDO::FETCH_ASSOC);
$total_budget_pending = $pdo->query("SELECT FOUND_ROWS() as total")->fetch()['total'];

//query for liquidation received
$notification = $pdo->prepare("
	SELECT SQL_CALC_FOUND_ROWS * 
	FROM liquidation
	WHERE liqstat LIKE 'For Approval'
");
$notification->execute();
$notification = $notification->fetchAll(PDO::FETCH_ASSOC);
$total_liquidation_received = $pdo->query("SELECT FOUND_ROWS() as total")->fetch()['total'];
?>
<!-- NAV BAR -->
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home.php">
        <img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" />
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active"><a href=" <?php  echo($Home) ?>">HOME</a></li>
            <li><a href=" <?php  echo($Registration) ?>">REGISTRATION</a></li>
            <li class="dropdown menus">
				<a href="#" data-toggle="dropdown">BUDGET</a>
				<ul class="dropdown-menu submenus">
					<li><a href="unit.php">UNITS</a></li>
					<li><a href="item.php">ITEM</a></li>
					<li><a href=" <?php  echo($Budget) ?> " >VIEW BUDGET LIST</a></li>
				</ul>
			</li>
            <li><a href=" <?php  echo($Liquidation) ?>">LIQUIDATION</a></li>
            <li class="dropdown menus">
				<a href="#" data-toggle="dropdown">MISCELLANEOUS</a>
				<ul class="dropdown-menu submenus">
					<li><a href="new_reimbursement.php">REIMBURSEMENT EXPENSE</a></li>
					<li><a href="new_incident.php" >INCIDENT MONITORING</a></li>
				</ul>
			</li>
            <li><a href=" <?php  echo($Report) ?>">REPORTS</a></li>
          </ul>
		<ul class="nav navbar-nav navbar-right">
			<?php if($_SESSION['login_username'] === 'manager'){?>
				<!-- notification section -->
				<li class="dropdown notification-container">
					<a href="#" data-toggle="dropdown"><h4><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></h4></a>
					
					<?php if($total_budget_pending > 0 || $total_liquidation_received > 0){?>
						<span class="label label-danger notification-counter" id="count"><?php echo ((int)$total_budget_pending + (int)$total_liquidation_received); ?></span>
						<ul class="dropdown-menu notif">
							
							<?php if($total_liquidation_received > 0){ ?>
								<li><a role="menuitem" tabindex="-1" href="liquidation.php"><?php echo $total_liquidation_received; ?> Liquidation need <br/>to be received.</a></li>
							<?php } ?>
							
							<?php if($total_budget_pending > 0){ ?>
								<li class="divider"></li>
								<li><a role="menuitem" tabindex="-1" href="view_budget.php"><?php echo $total_budget_pending; ?> Activity Budget is <br/>waiting to be approved</a></li>
							<?php } ?>
							
						</ul>
					<?php } ?>
				</li>
			<?php }?>
		<!-- <li><a href=" <?php //echo($Signup) ?>"><span class="glyphicon glyphicon-user"></span> Add Account</a></li> -->
			<li><a href=" <?php echo($Logout) ?>"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>


			
			<style>
				.notification-container {
					position: relative;
					top: 0;
					left: 0;
				}

				.notification-counter {   
					position: absolute;
					top: 25px;
					left: 30px;
					
					background-color: rgba(212, 19, 13, 1);
					color: #fff;
					border-radius: 3px;
					padding: 3px 3px 3px 3px;
					font: 10px Verdana;
				}
				
				h4{
					margin: 0;
				}
			</style>
		</ul>
    </div>
  </div>
</nav>

<!-- JUMBOTRON -->
<div class="container-fluid header">
	<div class="row" style="margin-top:3%">
		<div class="col-md-1" style="margin-right:0px">
        	<img src="img/baciwa_thesis.png" alt="thesis-logo" id="logo"/>
		</div>
        <div class="col-md-8" style="margin-left:0px">
		<span style="font-size:64px">Bacolod City Water District</span><br>
		<span style="font-size:22px;padding-top:0px">Environment and Water Resource Sewerage and Sanitation Management Division</span>
		<br>
	<!--	<span style="font-size:23x;padding-top:0px">Planting Activity Management System</span> -->
		</div>
	</div>
</div>	