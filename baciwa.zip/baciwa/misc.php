<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">          	
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <a class="navbar-brand" href="home.php"><img src="img/baciwa_logo.png" id="brand-image" alt="Baciwa Logo" /></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="#">HOME</a></li>
            <li><a href="#">REGISTRATION</a></li>
            <li><a href="#">BUDGET</a></li>
            <li><a href="#">LIQUIDATION</a></li>
            <li><a href="#">MISCELLANEOUS</a></li>
            <li><a href="#">REPORTS</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
        	<li><a href="#"><span class="glyphicon glyphicon-user"></span> Add Account</a></li>
        	<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      	  </ul>
          
        </div>
      </div>
    </nav>
    
    <div class="jumbotron home-header">
    	<table>
        	<tr>
            	<td><img src="img/baciwa_thesis.png" alt="thesis-logo"/></td>
            	<td>
        			<h1>Bacolod City Water District</h1> 
  					<p>Planting Activity Management System</p>        
                </td>                
            </tr>
  		 
	</div>
</body>
</html>