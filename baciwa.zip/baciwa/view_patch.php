<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />

</head>
<body>
	<?php require 'database.php'; ?>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		
		
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredregistration.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			</div>
		</div>
	
		<div class="col-md-9">
			<br/>
			<div class="panel panel-primary">				
				<div class="panel-heading content">List of Participants in <?php echo $_GET['patch']; ?></div>
				<div class="panel-body">
						
						<div class="table-responsive">
							<table class="table table-hover">
								<thead>
									<tr>
										<th>Date</th>
										<th>Organization</th>
										<th>Participants</th>
										<th>No. of Participants</th>
										<th>Trees Planted</th>
									</tr>
								</thead>
								<tbody>
											<?php
											
											$pdo = Database::connect();
											$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
											$sql = 'SELECT * FROM participants INNER JOIN schedule ON participants.schedid = schedule.schedid WHERE treepatch = "'.$_GET['patch'].'"';
											foreach ($pdo->query($sql) as $row) {
													echo '<tr>';
													
													
													//query organization name
													$id = $row['regid'];
													$sqlQuery = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE regid = ?";
													$q = $pdo->prepare($sqlQuery);
													$q->execute(array($id));
													$data = $q->fetch(PDO::FETCH_ASSOC);
													
													echo '<td>'. $row['scheddate'] . '</td>';
													echo '<td>'. $data['orgname'] . '</td>';
													echo '<td>'. $row['partname'] . '</td>';
													echo '<td>'. $row['partnum'] . '</td>';
													echo '<td>'. $row['treeqty'] .'</td>';
													echo '</tr>';
											}
											Database::disconnect();
											?>
								<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip(); 
									$('.btn').tooltip();
								});
								</script>
								</tbody>
							</table>
						</div>		
				</div>
			</div>
		</div>
	</div>

<?php
include('footer.php'); 
?>
</body>
</html>