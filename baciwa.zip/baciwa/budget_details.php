<?php 
include('php/login_success.php'); 
include('php/links.php');
require 'database.php';
?>

<?php
	$id = $_GET['id'];
	
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM budget where budcode = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();

	function getParticipantsNo($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM schedule WHERE regid = '".$id."'";
		
		$total_no_of_participants = 0;
		foreach ($pdo->query($sql) as $dataSched) {
			$sql = 'SELECT * FROM participants WHERE schedid = '.$dataSched['schedid'];
				foreach ($pdo->query($sql) as $dataPart) {
					$total_no_of_participants += $dataPart['partnum'];
				}
			}
		Database::disconnect();
			
		if($total_no_of_participants > 0){
			return $total_no_of_participants;
		}else{
			return '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;"><strong>Attention! </strong>Please enter participants <a href="view_schedule.php?id='.$_GET['id'].'" class="alert-link">Click Here!</a></div>';
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- Modal for error -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:10%">
		<div class="modal-content">
			<div class="modal-header btn-danger">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">System Error</h4>
			</div>
			<div class="modal-body content" id="errormodal">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
			</div>
		</div>
	</div>
</div>


<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Budget</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid content">
	
	<div class="row">
		<div class="col-sm-12" id="dateDisplay"></div>
		<div class="col-sm-12" id="clockDisplay"></div>
	</div>
	<br />
	<script type="text/javascript" language="javascript">
		function renderTime(){
			
			var currentTime = new Date();
			var diem = "AM";
			var month = currentTime.getMonth() + 1;
			var year = currentTime.getFullYear();
			var day = currentTime.getDate();
			var h = currentTime.getHours();
			var m = currentTime.getMinutes();
			var s = currentTime.getSeconds();
			
			if(h == 0){
				h=12;
			}else if(h > 12){
				h = h -12;
				diem = "PM";
			}
			
			if(h < 10){
				h = "0"+ h;
			}
			if(m < 10){
				m = "0"+ m;
			}
			if(s < 10){
				s = "0"+ s;
			}
			
			var myClock = document.getElementById('clockDisplay');
			myClock.textContent = "Time: " + h + ":" + m + ":" + s + " " + diem;
			
			var myDate = document.getElementById('dateDisplay');
			myDate.textContent = "Date: " + month + "/" + day + "/" + year;
			setTimeout('renderTime()', 1000);
		}
		renderTime();
	</script>
	<div class="row">
		<div class="col-sm-6" >
			<div class="panel panel-primary">
			
				<div class="panel-heading">
					<h3 class="panel-title"><strong>Budget Proposal</strong></h3>
				</div>
				<div class="panel-body">

					<!-- Activity Code -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="regOption">Registration Code</label></div>
						<div class="col-xs-7">
							<input type="text" class="form-control" required="required" id="regOption" name="activity_budget" value="<?php echo $data['regid']; ?>" readonly >
						</div>
					</div>
					
					<!-- Subject of the Budget -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="inputSubject">Subject of the Budget</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="inputSubject" name="subject_budget" value="<?php echo $data['budsub']; ?>" readonly ></div>
					</div>

					<!-- Date Issue -->
					<div class="form-group row">
						<div class="col-xs-4"><label for="inputDateIssue">Date Issue</label></div>
						<div class="col-xs-7"><input type="text" class="form-control" required="required" id="inputDateIssue" name="dateissueb" placeholder="Date Issue" value='<?php echo date("m/d/Y"); ?>' readonly></div>
					</div>
										
					<div class="panel panel-info">
						<div class="panel-heading">
							<h3 class="panel-title">Registration Details</h3>
						</div>
						<div class="panel-body" id="registrationPanel">
							<?php
								$pdo = Database::connect();
								$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
								//SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid
								$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid WHERE registration.regid = ?";
								$q = $pdo->prepare($sql);
								$q->execute(array($data['regid']));
								$dataOrg = $q->fetch(PDO::FETCH_ASSOC);
								Database::disconnect();
							?>	

							
							<div class="table-responsive">
								<table class="table">
									<tbody>
										<tr>
											<td><strong>Organization</strong></td>
											<td><?php echo $dataOrg['orgname'] ?></td>					
										</tr>
									
										<tr>
											<td><strong>Address</strong></td>
											<td><?php echo $dataOrg['orgadd'] ?></td>					
										</tr>
										
										<tr>
											<td><strong>Type of Activity</strong></td>
											<td><?php echo $dataOrg['regact'] ?></td>					
										</tr>
								
										<tr>
											<td><strong>Organization Type</strong></td>
											<td><?php echo $dataOrg['orgtype'] ?></td>					
										</tr>
								
										<tr>
											<td style="vertical-align:text-top"><strong>No. of Participants</strong></td>
											<td><?php echo getParticipantsNo($dataOrg['regid']) ?></td>					
										</tr>
										
										<tr>
											<td><strong>Contact Person</strong></td>
											<td><?php echo $dataOrg['regcperson'] ?></td>					
										</tr>
										
										<tr>
											<td><strong>Contact Number</strong></td>
											<td><?php echo $dataOrg['regcnum'] ?></td>					
										</tr>
										
										<tr>
											<td style="vertical-align:text-top"><strong>Remarks</strong></td>
											<td style="vertical-align:text-top"><?php echo $dataOrg['regmemo'] ?></td>					
										</tr>
										
										<tr>
											<td style="vertical-align:text-top"><strong>Schedule(s)</strong></td>
											<td style="vertical-align:text-top">
												<?php
													$pdo = Database::connect();
													$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
													$sql = "SELECT * FROM schedule WHERE regid = '".$data['regid']."'";
															
														foreach ($pdo->query($sql) as $row){
															echo $row['scheddate'].'<br />';
														}
														
													Database::disconnect();
												?>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							
							
							
						</div>
					</div>
				</div>
			</div>

		</div>
		<div class="col-sm-6" >
			<div class="panel panel-success">
			  <div class="panel-heading">
				<h3 class="panel-title"><strong>Items</strong></h3>
			  </div>
			  <div class="panel-body">
					
				<div class="row">
					<div class="col-md-12">
						<table class="table table-bordered" id="myTable">
							<thead>
								<tr>
									<th class="col-sm-2">Code</th>
									<th class="col-sm-4">Name</th>
									<th class="col-sm-2">Quantity</th>
									<th class="col-sm-2">Unit</th>
									<th class="col-sm-2">Price</th>
								</tr>
							</thead>
							<tbody>
								
									<?php
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM itembudget WHERE budcode = '".$id."'";
										$total = 0;	
										foreach ($pdo->query($sql) as $row){
											echo '<tr><td>'.$row['itembudid'].'</td>';
											echo '<td>'.$row['itemname'].'</td>';
											echo '<td>'.$row['itemquantity'].'</td>';
											echo '<td>'.$row['itemunit'].'</td>';
											echo '<td>'.$row['itemprice'].'</td></tr>';
											$total = $total + $row['itemprice'];
										}
										
										Database::disconnect();
									?>
								
							</tbody>
						</table>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<!-- Subject of the Budget -->
						<form class="form-inline text-right" role="form">
							<div class="form-group">
								<label for="total">Total Amount in Php.</label>
								<input type="text" class="form-control" id="total" value="<?php echo number_format($total,2); ?>"readonly>
							</div>
						</form>
					</div>
				</div>
				
			  </div>
			</div>
		</div>
	</div>
	<div class="row text-center">
		<div class="col-md-12">
			<?php
				$pdo = Database::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "SELECT * FROM budget WHERE budcode = ?";
				$q = $pdo->prepare($sql);
				$q->execute(array($id));
				$x = $q->fetch(PDO::FETCH_ASSOC);
				Database::disconnect();


				if($_SESSION['login_username'] === 'manager' && $x['budstat'] !== 'Approved'){
				$vars = array('id' => $id, 'status' => 1);
				$querystring = http_build_query($vars);
				$url = "php/budgetstatusUpdate.php?" . $querystring;
				echo '<a type="button" class="btn btn-primary" id="approveButton" style="margin-right:3px;" href="'.$url.'">Approve</a>';
				
				$vars = array('id' => $id, 'status' => 0);
				$querystring = http_build_query($vars);
				$url = "php/budgetstatusUpdate.php?" . $querystring;				
				echo '<a type="button" class="btn btn-warning" id="deniedButton" href="'.$url.'">Deny</a>';
			}
			?>
			<a type="button" class="btn btn-info" href="view_budget.php">Back</a>
		</div>
	</div>


	<!-- Tooltip -->
<script>
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();
		$('.btn').tooltip();
	});
</script>

<div class="row">
	<?php
	include('footer.php'); 
	?>
</div>
</body>
</html>