<?php 
include('php/login_success.php'); 
include('php/links.php');
?>
<?php
	function viewBudgetByStatus($status){
	include 'database.php';
				
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = 'SELECT * FROM budget INNER JOIN registration ON budget.regid = registration.regid WHERE budstat LIKE "'.$status.'"' ;
		echo '<table class="table table-hover">';
			echo '<thead>
				<tr>
					<th>Subject for the Budget</th>
					<th>Organization</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
				</thead>';
			foreach ($pdo->query($sql) as $row) {
				echo '<tbody>
			        <tr>';
						echo '<td>'.$row['budsub'].'</td>';
					  
						//query organization name
						$id = $row['orgid'];
						$sqlQuery = "SELECT * FROM organization where orgid = ?";
						$q = $pdo->prepare($sqlQuery);
						$q->execute(array($row['orgid']));
						$data = $q->fetch(PDO::FETCH_ASSOC);
   
						echo '<td>'. $data['orgname'] . '</td>';
						echo '<td>'.$row['budstat'].'</td>';
						echo '<td>';
							if($row['budstat'] === 'Denied'){
								echo '<a class="btn btn-primary btn-md" href="update_budgetdetails.php?id='.$row['budcode'].'" data-toggle="tooltip" title="Update Budget Proposal"><span class="glyphicon glyphicon-edit" style="margin-right:10px"></span><strong>Update</strong></a>&nbsp;';								
							}else{
								echo '<a class="btn btn-warning btn-md" href="budget_details.php?id='.$row['budcode'].'" data-toggle="tooltip" title="View Budget Proposal"><span class="glyphicon glyphicon-edit" style="margin-right:10px"></span><strong>View</strong></a>&nbsp;';
							}
						echo '<button type="button" class="btn btn-danger btn-md deleteB" rel="tooltip" title="Delete Budget Proposal" data-toggle="modal" data-target="#myModal" value="'.$row['budcode'].'"><span class="glyphicon glyphicon-trash"></span></button>
							 </td>';											  
					echo 	'</tr>';
					echo '</tbody>';
				}
		echo '</table>';
		Database::disconnect();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Budget</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid">
	
	<div class="col-md-3">
		<!-- side bar -->
		<div class="list-group side_bar">
			<a href="budget.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Create a Budget Proposal</a>
		</div>		
	</div>
	
	<div class="col-md-9 content">
		<h2>Budget Proposal List</h2>
		<hr />
		<br />
					
			<div class='container-fluid'>
				<div class='row'>
					<div class='col-md-12'>
						<ul class="nav nav-tabs">
							<li class="active"><a data-toggle="tab" href="#pending">Pending</a></li>
							<li><a data-toggle="tab" href="#approved">Approved</a></li>
							<!-- For revision only exist to secretary -->
							<?php if($_SESSION['login_username'] !== 'manager') {?>
								<li><a data-toggle="tab" href="#received">For Revision</a></li>
							<?php } ?>
						</ul>
						<br/>
						<div class="tab-content">
							<div id="pending" class="tab-pane fade in active">
								<?php viewBudgetByStatus("Pending"); ?>
							</div>
							<div id="approved" class="tab-pane fade">
								<?php viewBudgetByStatus("Approved"); ?>
							</div>
							<div id="received" class="tab-pane fade">
								<?php viewBudgetByStatus("Denied"); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>
<div id="display">
</div>
<!-- Status: Done, Pending, Cancelled, Postponed -->
<script>
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip(); 
		$('.btn').tooltip();
		
		$('.deleteB').click(function(){
		
			a = $(this).val();
			console.log(a);
			
			$.ajax({
				url   : 'php/budgetDelete.php',
				data  : {id: a},
				type : 'POST',
				success : function(data){
					window.location = "view_budget.php";
				}
			})
			
		});
	});
</script>
<?php
include('footer.php'); 
?>
												   
</body>
</html>