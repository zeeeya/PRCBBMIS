<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: registration.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM registration where regid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
		
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM organization where orgid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($data['orgid']));
        $dataOrg = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
		
    }
?>

<?php
	function getParticipantsNo(){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM schedule WHERE regid = '".$_GET['id']."'";
		
		$total_no_of_participants = 0;
		foreach ($pdo->query($sql) as $dataSched) {
			$sql = 'SELECT * FROM participants WHERE schedid = '.$dataSched['schedid'];
			foreach ($pdo->query($sql) as $dataPart) {
				$total_no_of_participants += $dataPart['partnum'];
			}
		}
		Database::disconnect();
		
		if($total_no_of_participants > 0){
			echo $total_no_of_participants;
		}else{
			echo '<div class="alert alert-warning" role="alert" style="margin-bottom:0px;"><strong>Attention! </strong>Please enter participants <a href="view_schedule.php?id='.$_GET['id'].'" class="alert-link">Click Here!</a></div>';
		}
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Planting Activity Management System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS import Files -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/custom_style.css">

	<!-- JQuery and Javascript File -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
	<?php include('header.php'); ?>

	<!-- PAGE TITLE -->
	<div class="container-fluid page_title_container">
		<div>
			<h1>Registration</h1>
		</div>
	</div>

	<div class="container-fluid">
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_organization.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Register an Organization</a>
				<a href="new_registration.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;Register New Activity</a>
				<a href="registration.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;&nbsp;View Registration List</a>
				<a href="schedule_list.php" class="list-group-item"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;&nbsp;View Schedule List</a>
			</div>
		</div>
		<div class="col-md-9 content">
			<div class="row" style="margin-top:15px">
				<div class="col-md-12"><strong style="font-size:24px">Registration Details</strong>
				<a class="btn btn-info btn-sm" style="margin-top:-10px;margin-left:5px;" href="update_registration.php?id=<?php echo $_GET['id'] ?>" data-toggle="tooltip" title="Update this registration info.">
					<span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
				</a>
				<hr>
				</div>
			</div>
			<script>
			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip(); 
			});
			</script>
			<br>
			<div>
				<div class="table-responsive">
					<table class="table">
						<tbody>
							<tr>
								<td><strong>Organization</strong></td>
								<td><?php echo $dataOrg['orgname'];?></td>					
							</tr>
							<tr>
								<td><strong>Address</strong></td>
								<td><?php echo $dataOrg['orgadd'];?></td>					
							</tr>
							<tr>
								<td><strong>Type of Activity</strong></td>
								<td><?php echo $data['regact'];?></td>					
							</tr>
							<tr>
								<td><strong>Organization Type</strong></td>
								<td><?php echo $dataOrg['orgtype'];?></td>					
							</tr>
							<tr>
								<td style="vertical-align:text-top"><strong>No. of Participants</strong></td>
								<td><?php getParticipantsNo(); ?></td>					
							</tr>
							<tr>
								<td><strong>Contact Person</strong></td>
								<td><?php echo $data['regcperson'];?></td>					
							</tr>							
							<tr>
								<td><strong>Contact Number</strong></td>
								<td><?php echo $data['regcnum'];?></td>					
							</tr>
							<tr>
								<td style="vertical-align:text-top"><strong>Remarks</strong></td>
								<td style="vertical-align:text-top"><?php echo $data['regmemo'];?></td>					
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="row text-center">
				<div class="form-actions">
					<a class="btn btn-info" href="registration.php"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> &nbsp; Back</a>
					<a class="btn btn-info" href="view_schedule.php?id=<?php echo $_GET['id'] ?>">View Schedule &nbsp;<span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span></a>
				</div>
			</div>
		</div>
	</div>
	<?php include('footer.php'); ?>
</body>
</html>

