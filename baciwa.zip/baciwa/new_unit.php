<!-- Modal -->
<div class="modal fade" id="addUnit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document" style="margin-top:5%;">
		<div class="modal-content">
			<div class="modal-header btn-info">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Unit</h4>
			</div>
			
			<form class="form-horizontal" role="form" action='./php/unitCreate.php' method="POST">
			
			<div class="modal-body content" style="margin:0 20px;">
				
				<!-- Unit Abbreviation -->
				<div class="form-group">
					<label for="inputName">Unit Abbreviation</label>
					<input type="text" class="form-control" required id="inputName" name="unitabbr" placeholder="Unit Abbreviation">
				</div>	
									
				<!-- Unit Name -->
				<div class="form-group">
					<label for="inputUnit">Unit Description</label>
					<input type="text" class="form-control" required="required" id="inputUnit" name="unitdesc" placeholder="Unit Name"
				</div>
								
				
			</div>
			
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Save</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
			
			</form>
		</div>
	</div>
</div>