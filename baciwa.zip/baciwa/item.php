<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Budget</h1>
	</div>
</div>

<!-- MAIN PAGE -->
<div class="container-fluid content">
	<br>
	<div class="panel panel-primary">
		<div class="panel-heading content">
				<strong>ITEM LIST&nbsp;&nbsp;&nbsp;</strong>
				<a type="button" class="btn btn-info btn-md text-center" data-toggle="modal" data-target="#addItem" rel="tooltip" title="Add New Items"><span class="glyphicon glyphicon-plus"></span><strong>&nbsp;New</strong></a>
		</div>
		<div class="panel-body" style="margin:0 5%;">
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
						<tr class="alert-info">
							<th>Item Code</th>
							<th>Item Name</th>
							<th>Item Unit</th>
							<th>Item Price</th>
							<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
							include 'database.php';
							$pdo = Database::connect();
							$sql = 'SELECT * FROM item ORDER BY itemname';
							foreach ($pdo->query($sql) as $row) {
							echo '<tr>';
								echo '<td>'. $row['itemcode'] . '</td>';
								echo '<td>'. $row['itemname'] . '</td>';
								echo '<td>'. $row['itemunit'] . '</td>';
								echo '<td>Php&nbsp;'. number_format((float)($row['itemprice']), 2, '.', '') . '</td>';
								echo '<td class="text-center">
										<button type="button" class="btn btn-warning btn-md updateB" rel="tooltip" title="Update Item" data-toggle="modal" data-target="#updateModal" value="'.$row['itemcode'].'"><span class="glyphicon glyphicon-pencil"></span></button>
										<button type="button" class="btn btn-danger btn-md deleteB" rel="tooltip" title="Delete Item" data-toggle="modal" data-target="#myModal" value="'.$row['itemcode'].'"><span class="glyphicon glyphicon-trash"></span></button>
									  </td>';
								echo '</tr>';
							}
							Database::disconnect();
							?>
							
							<script>
								$(document).ready(function(){
									$('[data-toggle="tooltip"]').tooltip();
									$('.btn').tooltip();
								});
							</script>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
</div>

<?php
include('update_item.php');
include('new_item.php');
include('delete_item.php');
include('footer.php'); 
?>
</body>
</html>