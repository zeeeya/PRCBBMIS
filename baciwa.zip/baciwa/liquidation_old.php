<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Liquidation</h1>
	</div>
</div>

	<div class="container-fluid main-wrapper">
		<div class="col-md-3">
		<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_liquidation.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;View Liquidation</a>
				<a href="liquidation.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;New Liquidation</a>
			</div>
		</div>

		<!-- start sang body of Liquidation -->
		<div class="col-lg-9 content">
			<div class="row">
				<h2 style="margin-left:10px;">New Liquidation</h2>
				<br />
			</div>						
						
			<div class="row">
				<form class="form-horizontal" role="form" action='./php/liquidationCreate.php' method="POST">
					<div class="row col-md-10">
						<div class="panel panel-default panel-primary">
							<div class="panel-heading">
								<h4>Profile Information</h4>
							</div>
						
							<div class="panel-body" style="padding-left:30px;">
							<div class="col-lg-11 forms">
								
								<!-- Subject of the Budget -->
									<div class="form-group">
										<label for="inputSubject">Subject of the Liquidation</label>
										<input type="text" class="form-control" required="required" id="inputSubject" name="subjectLiquidation" placeholder="Subject of the Liquidation">
									</div>
									<!-- Activity -->
									<div class="form-group">
										<label class="control-label" for="inputActivity">Activity</label>
										<select class="form-control" required="required" id="inputActivity" name="activity_liquidation">
											<option></option>
											<option value="Tree Planting">Tree Planting</option>
											<option value="Mangrove Planting">Mangrove Planting</option>
										</select>
									</div>

									<!-- Date Issue -->
									<div class="form-group">
										<label for="inputDateIssueL">Date Issue</label>
										<input type="text" class="form-control" required="required" id="inputDateIssueL" name="dateissueL" placeholder="Date Issue">
									</div>
									<!-- Load jQuery and bootstrap datepicker scripts -->
									<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputDateIssueL').datepicker({
												format: "mm/dd/yyyy"
											});  
										
										});
									</script>
									
									<!-- Date of activity -->
									<div class="form-group">
										<label for="inputDateActivityL">Date of activity</label>
										<input type="text" class="form-control" required="required" id="inputDateActivityL" name="dateactivityL" placeholder="Date of activity">
									</div>
									<!-- Load jQuery and bootstrap datepicker scripts -->
									<script src="js/jquery-1.9.1.min.js"></script>
									<script src="js/bootstrap-datepicker.js"></script>
									<script type="text/javascript">
										// When the document is ready
										$(document).ready(function () {
											
											$('#inputDateActivityL').datepicker({
												format: "mm/dd/yyyy"
											});  
										
										});
									</script>
									
									<!-- Status -->
									<div class="form-group">
										<label class="control-label" for="inputStatusL">Status</label>
										<select class="form-control" required="required" id="inputStatusL" name="status_liquidation">
											<option></option>
											<option value="Done">Done</option>
											<option value="Pending}">Pending</option>
											<option value="Cancelled">Cancelled</option>
											<option value="Postponed">Postponed</option>
										</select>
									</div>
									
									
									<!-- Remarks -->
									<div class="form-group">
										<label for="inputProfileRemark">Remarks:</label>
										<textarea class="form-control" id="inputProfileRemark" rows="6" name="remarks_liquidation" placeholder="Any Remarks?"></textarea>
									</div>								
								
								</div>
						</div>
						</div>
						</div>
						
						<!-- start sang Items na content-->
						<br />
						<div class="row col-md-10">
						<div class="panel panel-default panel-primary">
							<div class="panel-heading">
								<h4>Liquidated Item(s)</h4>
							</div>
						
							<div class="panel-body" style="padding-left:30px;">
							<div class="col-lg-11 forms">

							<a href="" class="btn btn-success btn-md"><span class="glyphicon glyphicon-plus-sign"></span> Add Items</a>
								
								<!-- start sang table -->
								<div class='container-fluid'>
									<div class='row'>
									<div class='col-md-12'>
							
								<div class="table-responsive">
									<table class="table table-hover">
										<thead>
											<tr>
												<th>Item Id</th>
												<th>Item Name</th>
												<th>Quantity</th>
												<th>Price</th>
											</tr>
										</thead>
										<tbody>
											<!-- <?php
											include 'database.php';
											$pdo = Database::connect();
											$sql = 'SELECT * FROM registration ORDER BY regid DESC';
											foreach ($pdo->query($sql) as $row) {
													echo '<tr>';
													echo '<td>'. $row['regid'] . '</td>';
													echo '<td>'. $row['regact'] . '</td>';
													echo '<td>'. $row['regname'] . '</td>';
													echo '<td>'. $row['regsdate'] . '</td>';
													echo '<td>'. $row['regstat'] . '</td>';
													echo '<td>
															<a class="btn btn-primary btn-md" href="view_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="View Details"><span class="glyphicon glyphicon-book"></span></a>
															<a class="btn btn-warning btn-md" href="update_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="Update"><span class="glyphicon glyphicon-pencil"></span></a>
															<a class="btn btn-danger btn-md" href="delete_registration.php?id='.$row['regid'].'" data-toggle="tooltip" title="Delete"><span class="glyphicon glyphicon-trash"></span></a>
														  </td>';
													echo '</tr>';
											}
											Database::disconnect();
											?> 
											
											<script>
											$(document).ready(function(){
												$('[data-toggle="tooltip"]').tooltip();   
											});
											</script>
											
											-->

										</tbody>
									</table>
								</div>
								
								
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
				</div>
								<!-- end sang table of items -->
								
									
								</div>
							</div>
							
							<div class="form-actions text-center forms">
								<button type="submit" class="btn btn-success">Create</button>
							</div>
					 </form>
					</div><!-- end of class span10 offset1-->
				</div><!-- end of class container-->
			</div>
		</div>
	</div>

<?php include('./footer.php'); ?>
</body>
</html>