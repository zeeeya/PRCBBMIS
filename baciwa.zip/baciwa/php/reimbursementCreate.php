<?php
     
    require '../database.php';
 
    if ( !empty($_POST)) {

		$liqcode = $_POST['liqcode'];
		
        // keep track post values
        $rerdate = $_POST['dateissue'];
        $rername = $_POST['name'];
        $reramount = $_POST['amt'];
        $rerpayment = $_POST['payment'];
        $rerremarks = $_POST['remark'];

        $rerpayname  = $_POST['payname'];
        $rerpayadd = $_POST['payadd'];
        $rerpayissue = $_POST['payissue'];
        $rerpaycedula = $_POST['paycedula'];
        $rerpaydateissue = $_POST['paydate'];

        $rerwitname  = $_POST['witname'];
        $rerwitadd = $_POST['witadd'];
        $rerwitissue = $_POST['witissue'];
        $rerwitcedula = $_POST['witcedula'];
        $rerwitdateissue = $_POST['witdate'];
        /*
        echo $rerdate;
        echo $rername;
        echo $reramount;
        echo $rerpayment;
        echo $rerremarks;

        echo $rerpayname;
        echo $rerpayadd;
        echo $rerpayissue;
        echo $rerpaycedula;
        echo $rerpaydateissue;
        */
        // validate input
        $valid = true;

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO reimbursement (rerdate,rername,rerpayment,reramount,rerremarks,rerpayname,rerpayadd,rerpayissue,rerpaycedula,rerpaydateissue,rerwitname,rerwitadd,rerwitissue,rerwitcedula,rerwitdateissue, liqcode) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($rerdate,$rername,$rerpayment,$reramount,$rerremarks,$rerpayname,$rerpayadd,$rerpayissue,$rerpaycedula,$rerpaydateissue,$rerwitname,$rerwitadd,$rerwitissue,$rerwitcedula,$rerwitdateissue, $liqcode));
            Database::disconnect();
            header("Location: ../reimbursement.php");
        }
    }
?>