<?php
    require '../database.php';
 
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: ../registration.php");
    }
     
    if ( !empty($_POST)) {
        // keep track validation errors
        $nameError = null;
        $emailError = null;
        $mobileError = null;
         
        // keep track post values
		$regact = $_POST['activity'];
		$regperson = $_POST['person'];
		$regnum = $_POST['number'];
		$regstat = $_POST['status'];
		$regsrem = $_POST['remark2'];
         
        // validate input
        $valid = true;
         
        // update data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE registration set regact = ?, regcperson=?, regcnum=?, regstat=?, regmemo=? WHERE regid = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($regact, $regperson, $regnum, $regstat, $regsrem, $id));
            Database::disconnect();
            header("Location: ../registration.php");
        }
    }
?>