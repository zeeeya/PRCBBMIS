<?php
    require '../database.php';
	
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
		if($_GET['status'])
			$status = 'Approved';
		else
			$status = 'Denied';
		
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE budget SET budstat = ? WHERE budcode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($status, $id));
        Database::disconnect();
        header("Location: ../view_budget.php");		
		
    }else {
        header("Location: ../view_budget.php");
    }
     
?>