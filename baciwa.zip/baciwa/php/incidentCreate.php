<?php

    require '../database.php';
 
    if ( !empty($_POST)) {

		
        // keep track post values
		$incdate = $_POST['incdate'];
		$orgid = $_POST['incorg'];
		$incname = $_POST['name'];
		$incadd = $_POST['add'];
		$inctype = $_POST['type'];
		//$regstat = $_POST['status'];
		$incdesc = $_POST['desc'];
		$incact = $_POST['act'];
		
		//echo 'Activity: '.$regact."<br>";;
		//echo 'Organization ID: '.$orgid."<br>";;
		//echo 'Contact Person: '.$regcperson."<br>";;
		//echo 'Contact Number: '.$regcnum."<br>";;
		//echo 'Remarks: '.$regmemo."<br>";;
		//echo 'No. of Participants: '.$partnum."<br>";;
        // validate input
        $valid = true;
    
        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO incident (incdate,orgid,incname,incadd,inctype,incdesc,incact) values(?, ?, ?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($incdate,$orgid,$incname,$incadd,$inctype,$incdesc,$incact));
            Database::disconnect();
            header("Location: ../incident.php");
        }
    
	}
	
?>