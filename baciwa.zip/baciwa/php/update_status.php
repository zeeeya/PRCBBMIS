<?php

//echo $_GET['id'];
//echo $_POST['optradio'.$_GET['id']];

    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
		$id = $_GET['id'];
		$partstat = $_POST['optradio'.$id];

        // validate input
        $valid = true;
		
		//echo 'ID:'.$id.', Participants:'.$partname.', No. of Partipants:'.$partnum.', Schedule ID:'.$schedid.', Registration ID:'.$registrationid;
		
        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE participants SET partstat = ? WHERE partid = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($partstat, $id));
            Database::disconnect();
            header("Location: ../schedule_list.php");
        }
    }else
            header("Location: ../schedule_list.php");
?>