
<?php
    require '../database.php';
    $id = $_POST['delid'];
	
    if ( !empty($id)) {
		echo $id;
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM item WHERE itemcode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        Database::disconnect();
		header("Location: ../item.php");
    }else{
		header("Location: ../item.php");
	}
    
?>
