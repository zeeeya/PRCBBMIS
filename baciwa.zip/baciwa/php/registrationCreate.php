<?php


    require '../database.php';
 
    if ( !empty($_POST)) {

		
        // keep track post values
		$regact = $_POST['activity'];
		$orgid = $_POST['orgname'];
		$regcperson = $_POST['person'];
		$regcnum = $_POST['number'];
		//$regstat = $_POST['status'];
		$regmemo = $_POST['remark'];
		$partnum = 0;
		
		//echo 'Activity: '.$regact."<br>";;
		//echo 'Organization ID: '.$orgid."<br>";;
		//echo 'Contact Person: '.$regcperson."<br>";;
		//echo 'Contact Number: '.$regcnum."<br>";;
		//echo 'Remarks: '.$regmemo."<br>";;
		//echo 'No. of Participants: '.$partnum."<br>";;
        // validate input
        $valid = true;
    
        // insert data
        if ($valid) {
			
			date_default_timezone_set("Asia/Taipei");
			$regid = '00-'.date("mdYhis");
			
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO registration (regid, regact, orgid, regcperson, regcnum, regmemo, partnum) values(?, ?, ?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($regid, $regact, $orgid, $regcperson, $regcnum, $regmemo, $partnum));
            Database::disconnect();
			
			if(isset($_POST)==true && empty($_POST)==false):

			$SCHED_ARR=$_POST['SCHED_ARR'];			
			$STIME_ARR=$_POST['STIME_ARR'];
			$ETIME_ARR=$_POST['ETIME_ARR'];

			foreach($SCHED_ARR as $a => $b){
				//echo $SCHED_ARR[$a].', '.$STIME_ARR[$a].', '.$ETIME_ARR[$a];
				
				$pdo = Database::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "INSERT INTO schedule (regid, scheddate, schedtime, schedend) values(?, ?, ?, ?)";
				$q = $pdo->prepare($sql);
				$q->execute(array($regid, $SCHED_ARR[$a], $STIME_ARR[$a], $ETIME_ARR[$a]));
				Database::disconnect();			
				header("Location: ../registration.php");
			}
			
			
			endif;

        }
    
	}
	
?>