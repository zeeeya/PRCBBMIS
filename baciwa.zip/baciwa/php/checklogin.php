<?php
include('connect.php');
$tbl_name="user"; // Table name 

session_start();
{
    $user=mysql_real_escape_string($_POST['username']);
    $pass=mysql_real_escape_string($_POST['password']);
    $fetch=mysql_query("SELECT id FROM `$tbl_name` WHERE 
                         username='$user' and password='$pass'");
    $count=mysql_num_rows($fetch);
    if($count!="")
    {
    $_SESSION['login_username']=$user;
    header("Location:../home.php"); 
    }
    else
    {
       header('Location:wrong_password.php');
	   
    }

}
?>