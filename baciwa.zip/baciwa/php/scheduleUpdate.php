<?php
     
    require '../database.php';
	
	$regid = $_GET['id'];
	$schedid = $_POST['modalscheduleid'];
	$scheddate = $_POST['modalSchedule'];
	$schedtime = $_POST['modalTimestart'];
	$schedend = $_POST['modalTimeend'];
		
	//echo $registrationid.', '.$schedid.', '.$scheddate.', '.$schedtime.', '.$schedend;

    if ( !empty($schedid)) {

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE schedule SET regid = ?, scheddate = ?, schedtime = ?, schedend = ? WHERE schedid = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($regid, $scheddate, $schedtime, $schedend, $schedid));
		Database::disconnect();
		header("Location: ../view_schedule.php?id=".$regid);
        
    }else{
		header("Location: ../view_schedule.php?id=".$regid);
	}
?>