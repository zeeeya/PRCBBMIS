<?php 
	require '../database.php';

	$id = $_POST['field_4'];
	$patch = $_POST['field_6'];
	$patchQty = $_POST['field_7'];

	echo $id."<br/>";
	echo $patch."<br/>";
	echo $patchQty."<br/>";

	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "UPDATE participants SET treepatch = ?, treeqty = ? WHERE partid = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($patch, $patchQty, $id));
	Database::disconnect();
	if($_POST['field_2'] === 'Tree Planting')
		header("Location: ../treeplanting.php");
	else
		header("Location: ../mangroveplanting.php");
?>