	<?php
    require '../database.php';
	
    $id = $_POST['id'];
    echo $id.'<br>';
	
    
	if ( !empty($id)) {
	 
		// delete from liquidation table
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM liquidation WHERE liqcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		
		// delete from liquidation table
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM liquidationitem WHERE liqcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		
		header("Location: ../liquidation_view.php");

    }else
		header("Location: ../liquidation_view.php");

?>