<?php
     
    require '../database.php';

    if ( !empty($_POST)) {

		$tableData = stripcslashes($_POST['pTableData']);
		date_default_timezone_set("Asia/Taipei");

		// Decode the JSON array
		
		//liquidation code
		$liquidationcode = '02-'.date("mdYhis");
		//budget code
		$budgetcode = $_POST['budgetcode'];
		//date
		$date = date("m/d/Y").'';
		//total liquidation
		$ltotal = $_POST['liquidationTotal'];
		//total money spent
		$total = $_POST['total'];
		$status = 'For Approval';
		$subject = $_POST['subject'];
		
		//echo $liquidationcode.', '.$budgetcode.', '.$date.', '.$ltotal.', '.$total.'<br />';
		//1. save the liquidation record
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "INSERT INTO liquidation (liqcode, budcode, liqdate, liqamnt, liqtotal, liqstat, liqsub) values(?, ?, ?, ?, ?, ?, ?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($liquidationcode, $budgetcode, $date, $ltotal, $total, $status, $subject));
        Database::disconnect();
		
		
		//2. save liquidation items
		$tableData = json_decode($tableData,TRUE);
		
		foreach($tableData as $item) { //foreach element in $arr
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO liquidationitem (liqitmor, liqitmname, liqitmprc, liqcode) values(?, ?, ?, ?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($item['or_number'], $item['name'], $item['price'], $liquidationcode));
			Database::disconnect();
			
		}
		
		//3. change budget status to "DONE"
		
		foreach($tableData as $item) { //foreach element in $arr
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "UPDATE budget set budstat = ? WHERE budcode = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array('Done', $budgetcode));
			Database::disconnect();
		}

		echo '<div class="alert alert-success" role="alert" style="margin-bottom:0px;"><span class="glyphicon glyphicon-ok" aria-hidden="true" style="margin-right:10px"></span>Budget successfully liquidated.</div><br />';
    }
	
	
?>