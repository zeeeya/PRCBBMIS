<?php
    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
		$name = $_POST['itemname'];
		$price = $_POST['itemprice'];
		$unit = $_POST['itemunit'];

         
        // validate input
        $valid = true;

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO item (itemname, itemunit, itemprice) values(?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($name,$unit,$price));
            Database::disconnect();
            header("Location: ../item.php");
        }
    }
?>