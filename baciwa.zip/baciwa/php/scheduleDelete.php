	<?php
    require '../database.php';
	
	$registrationid = $_GET['id'];
    $id = $_POST['deleteschedid'];
    echo $_GET['id'].'<br>';
	    
	if ( !empty($id)) {
	 
		// delete data
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM schedule WHERE schedid = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		header("Location: ../view_schedule.php?id=".$registrationid);

    }else
		header("Location: ../view_schedule.php?id=".$registrationid);
?>