<?php
     
    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
		$subjectliquidation = $_POST['subjectLiquidation'];
		$activityliquidation = $_POST['activity_liquidation'];
		$dateissueliquidation = $_POST['dateissueL'];
		$dateactivityliquidation = $_POST['dateactivityL'];
		$statusliquidation = $_POST['status_liquidation'];
		$remarksliquidation = $_POST['remarks_liquidation'];
         
        // validate input
        $valid = true;

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO liquidation (subjectliquidation,activityliquidation,dateissueliquidation,dateactivityliquidation,statusliquidation,remarksliquidation) values(?, ?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($subjectliquidation,$activityliquidation,$dateissueliquidation,$dateactivityliquidation,$statusliquidation,$remarksliquidation));
            Database::disconnect();
            header("Location: ../view_liquidation.php");
        }
    }
?>