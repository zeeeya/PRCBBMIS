<?php
include('../database.php');

function sum($treepatch) {
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = 'SELECT * FROM participants WHERE treepatch = "'.$treepatch.'"';
	$x = 0;

	foreach ($pdo->query($sql) as $row){
		$x += $row['treeqty'];
	}
	
	return $x;
}

function w_sum($treepatch) {
	$pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = 'SELECT * FROM witheredtrees WHERE wtpatch = "'.$treepatch.'"';
	$x = 0;

	foreach ($pdo->query($sql) as $row){
		$x += $row['wtnum'];
	}
		
	return $x;
}

//Connecting to tree table
$pdo = Database::connect();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = 'SELECT * FROM tree';
$i = 0;
echo 'var d = [';
foreach ($pdo->query($sql) as $row){
	if($i < 31)
		echo ($row['treeqty'] + sum($row['treepatch']) - w_sum($row['treepatch'])).',';
	else
		echo ($row['treeqty'] + sum($row['treepatch']) - w_sum($row['treepatch']));
	
	$i++;
}
echo '];';

echo 'var patches = {"type":"FeatureCollection","features":[
{
	"type":"Feature",
	"properties":{
		"name":"Patch006",
		"density":d[5],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch006"
	},
	"geometry":{
		"coordinates":[[[122.907756,10.606603],[122.907032,10.607799],[122.906678,10.607584],[122.906976,10.606429],[122.907169,10.606213],[122.907756,10.606603]]],
		"type":"Polygon"
	},
	"id":"0b8edf6bddf034dcdb8faa72760b9825"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch023",
		"density":d[22],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch023"
	},
	"geometry":{
		"coordinates":[[[122.912083,10.60615],[122.911372,10.605746],[122.910683,10.606851],[122.911428,10.607294],[122.912083,10.60615]]],
		"type":"Polygon"
	},
	"id":"0f8fd41b9115917e69086d484096b55a"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch026",
		"density":d[25],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch026"
	},
	"geometry":{
		"coordinates":[[[122.908757,10.604157],[122.90925,10.604468],[122.909964,10.603461],[122.909567,10.603176],[122.908757,10.604157]]],
		"type":"Polygon"
	},
	"id":"142640a6bcdbae1b1f3091194d94e2fe"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch024",
		"density":d[23],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch024"
	},
	"geometry":{
		"coordinates":[[[122.91285,10.606588],[122.912155,10.607703],[122.911434,10.607289],[122.912088,10.60615],[122.91285,10.606588]]],
		"type":"Polygon"
	},
	"id":"16b584e4da775a83a6abee2986a06ebd"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch020",
		"density":d[19],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch020"
	},
	"geometry":{
		"coordinates":[[[122.909224,10.605976],[122.908494,10.605512],[122.90925,10.604468],[122.909948,10.604905],[122.909224,10.605976]]],
		"type":"Polygon"
	},
	"id":"17f4bdf6efd551258a3ca095ec763e0d"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch001",
		"density":d[0],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch001"
	},
	"geometry":{
		"coordinates":[[[122.906332,10.608987],[122.906681,10.607584],[122.907029,10.6078],[122.906332,10.608987]]],
		"type":"Polygon"
	},
	"id":"1d6d4223e7ff1cb8adf619dd01dbd444"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch008",
		"density":d[7],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch008"
	},
	"geometry":{
		"coordinates":[[[122.908518,10.60707],[122.907759,10.608233],[122.908454,10.60867],[122.909181,10.607484],[122.908518,10.60707]]],
		"type":"Polygon"
	},
	"id":"24868a7bcf07b73093d56518acf6cd81"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch015",
		"density":d[14],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch015"
	},
	"geometry":{
		"coordinates":[[[122.910683,10.606856],[122.909975,10.607958],[122.909181,10.607489],[122.909886,10.606379],[122.910683,10.606856]]],
		"type":"Polygon"
	},
	"id":"3469aa8dab596a3a6f4a1aa997e24d35"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch011",
		"density":d[10],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch011"
	},
	"geometry":{
		"coordinates":[[[122.9105,10.608844],[122.910747,10.608401],[122.911943,10.60905],[122.911697,10.609477],[122.9105,10.608844]]],
		"type":"Polygon"
	},
	"id":"34d3bc2d945ece661ad6bea8b63635f4"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch016",
		"density":d[15],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch016"
	},
	"geometry":{
		"coordinates":[[[122.911434,10.607291],[122.910742,10.608401],[122.90998,10.607958],[122.910677,10.606856],[122.911434,10.607291]]],
		"type":"Polygon"
	},
	"id":"4a41b163d281f7abd671cae4a36d4def"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch012",
		"density":d[11],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch012"
	},
	"geometry":{
		"coordinates":[[[122.907169,10.606208],[122.907759,10.606598],[122.908499,10.605512],[122.907968,10.605174],[122.907464,10.605849],[122.907169,10.606208]]],
		"type":"Polygon"
	},
	"id":"4cc96279144ebf4f74067309055ce902"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch030",
		"density":d[29],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch030"
	},"geometry":{
		"coordinates":[[[122.91138,10.605739],[122.912083,10.60615],[122.912777,10.604995],[122.91204,10.604568],[122.91138,10.605739]]],
		"type":"Polygon"
	},
	"id":"4ff5286956fb35cafca1096b4155900d"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch014",
		"density":d[13],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch014"
	},
	"geometry":{
		"coordinates":[[[122.909183,10.607487],[122.908515,10.607073],[122.909226,10.605973],[122.909883,10.606379],[122.909183,10.607487]]],
		"type":"Polygon"
	},
	"id":"534813e9f4135a9fc7b440906717c9d3"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch019",
		"density":d[18],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch019"
	},
	"geometry":{
		"coordinates":[[[122.907974,10.605174],[122.908494,10.605512],[122.90925,10.604468],[122.908757,10.604162],[122.907974,10.605174]]],
		"type":"Polygon"
	},
	"id":"5705ee62f6de384a6bb00de2f4d99efe"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch002",
		"density":d[1],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch002"
	},
	"geometry":{
		"coordinates":[[[122.906327,10.608995],[122.907019,10.609414],[122.907754,10.608233],[122.907035,10.6078],[122.906327,10.608995]]],
		"type":"Polygon"
	},
	"id":"5a1d0cea8f212d8479916868e93b4c9c"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch005",
		"density":d[4],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch005"
	},
	"geometry":{
		"coordinates":[[[122.909261,10.609155],[122.909942,10.609546],[122.909567,10.610284],[122.908633,10.610226],[122.909261,10.609155]]],
		"type":"Polygon"
	},
	"id":"6de6a7f25dad69ec8f40043d2f142d24"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch003",
		"density":d[2],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch003"
	},
	"geometry":{
		"coordinates":[[[122.907756,10.608235],[122.907024,10.609416],[122.907748,10.609846],[122.908456,10.608668],[122.907756,10.608235]]],
		"type":"Polygon"
	},
	"id":"7ce797a06e8721f2796dc8d2ebf1d7c7"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch032",
		"density":d[31],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch032"
	},
	"geometry":{
		"coordinates":[[[122.912861,10.606588],[122.913553,10.605454],[122.914019,10.605712],[122.913306,10.606846],[122.912861,10.606588]]],
		"type":"Polygon"
	},
	"id":"806cbd7b58fa365be495cf18341dffad"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch021",
		"density":d[20],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch021"
	},
	"geometry":{
		"coordinates":[[[122.91057,10.605285],[122.909878,10.606377],[122.909224,10.605971],[122.909948,10.604905],[122.91057,10.605285]]],
		"type":"Polygon"
	},
	"id":"81805de671418276efadb29730634aa2"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch007",
		"density":d[6],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch007"
	},
	"geometry":{
		"coordinates":[[[122.907032,10.6078],[122.907754,10.606601],[122.908515,10.607073],[122.907754,10.608233],[122.907032,10.6078]]],
		"type":"Polygon"
	},
	"id":"8ad09916c52577a8aad90615340a3191"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch018",
		"density":d[17],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch018"
	},
	"geometry":{
		"coordinates":[[[122.911493,10.608807],[122.912158,10.6077],[122.912608,10.607974],[122.911938,10.60905],[122.911493,10.608807]]],
		"type":"Polygon"
	},
	"id":"935cbf6fe623256962dab4c82ed88a9d"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch013",
		"density":d[12],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch013"
	},
	"geometry":{
		"coordinates":[[[122.908515,10.607073],[122.907756,10.606603],[122.908497,10.605512],[122.909229,10.605976],[122.908515,10.607073]]],
		"type":"Polygon"
	},
	"id":"94f7005d1cfbc38bb13968821e0d3dba"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch031",
		"density":d[30],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch031"
	},
	"geometry":{
		"coordinates":[[[122.912855,10.606593],[122.912088,10.606145],[122.912775,10.605],[122.913553,10.605449],[122.912855,10.606593]]],
		"type":"Polygon"
	},
	"id":"967b0a104f72dcf0b8bc0440aa5f2fa0"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch027",
		"density":d[26],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch027"
	},
	"geometry":{
			"coordinates":[[[122.91065,10.603941],[122.909942,10.604905],[122.90925,10.604468],[122.909969,10.603471],[122.91065,10.603941]]],
			"type":"Polygon"
	},
	"id":"9817a63c9053dd4249ea47575bf6a458"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch017",
		"density":d[16],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch017"
	},
	"geometry":{
		"coordinates":[[[122.912153,10.6077],[122.911434,10.607294],[122.910742,10.608396],[122.911493,10.608802],[122.912153,10.6077]]],
		"type":"Polygon"
	},
	"id":"a0fe085f2c86bbaec45c2e7543a8ea39"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch025",
		"density":d[24],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch025"
	},
	"geometry":{
		"coordinates":[[[122.912158,10.607703],[122.912608,10.607977],[122.913306,10.606856],[122.91285,10.606593],[122.912158,10.607703]]],
		"type":"Polygon"
	},
	"id":"b3e54a49bd8e22f0eeb30af5642cef1d"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch029",
		"density":d[28],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch029"
	},
	"geometry":{
		"coordinates":[[[122.910581,10.605285],[122.91138,10.605744],[122.91204,10.604576],[122.911262,10.604204],[122.910581,10.605285]]],
		"type":"Polygon"
	},
	"id":"c4697082f4748976282f2f99edc5e63c"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch004",
		"density":d[3],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch004"
	},
	"geometry":{
		"coordinates":[[[122.908454,10.608668],[122.907747,10.609847],[122.908361,10.610224],[122.908633,10.610226],[122.909258,10.609155],[122.908454,10.608668]]],
		"type":"Polygon"
	},
	"id":"c799ba40d5be2e6d95a53774f53da822"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch028",
		"density":d[27],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch028"
	},
	"geometry":{
		"coordinates":[[[122.910575,10.60529],[122.911262,10.604204],[122.91065,10.603935],[122.909953,10.604905],[122.910575,10.60529]]],
		"type":"Polygon"
	},
	"id":"ca12ea380f5cc29313078b111c9e8acb"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch010",
		"density":d[9],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch010"
	},
	"geometry":{
		"coordinates":[[[122.909969,10.607958],[122.910742,10.608401],[122.9105,10.608844],[122.90991,10.608544],[122.910259,10.608955],[122.909945,10.609546],[122.909258,10.609153],[122.909969,10.607958]]],
		"type":"Polygon"
	},
	"id":"dd4a8a88910be70c7e78e9dd237b5639"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch009",
		"density":d[8],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch009"
	},
	"geometry":{
		"coordinates":[[[122.909175,10.607489],[122.908454,10.608668],[122.909258,10.60915],[122.909975,10.607958],[122.909175,10.607489]]],
		"type":"Polygon"
	},
	"id":"e08e6aa71c86cb24eed661bdd9eb7f26"
},{
	"type":"Feature",
	"properties":{
		"name":"Patch022",
		"density":d[21],
		"stroke":"#000000",
		"stroke-width":4,
		"stroke-opacity":1,
		"fill":"#63b6e5",
		"fill-opacity":0.20000000298023224,
		"url": "view_patch.php?patch=Patch022"
	},
	"geometry":{
		"coordinates":[[[122.909881,10.606379],[122.910677,10.606851],[122.911372,10.605746],[122.910573,10.605285],[122.909881,10.606379]]],
		"type":"Polygon"
	},
	"id":"f59700b61a37746a6171cb0e03fba6e9"
}
],"id":"nazercalumpiano.oi73pah3"
}';

?>
