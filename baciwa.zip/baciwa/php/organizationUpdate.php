<?php
    require '../database.php';
 
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: ../view_organization.php");
    }
     
    if ( !empty($_POST)) {       
        // keep track post values
		$orgname = $_POST['orgname'];
		$orgtype = $_POST['orgtype'];
		$orgadd = $_POST['orgadd'];
		$orgcperson = $_POST['orgcperson'];
		$orgcnum = $_POST['orgcnum'];
         
        // validate input
        $valid = true;
         
        // update data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE organization set orgname = ?, orgtype =?, orgadd=?, orgcperson=?, orgcnum=? WHERE orgid = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($orgname, $orgtype, $orgadd, $orgcperson, $orgcnum, $id));
            Database::disconnect();
			echo 'update succesful?';
            header("Location: ../view_organization.php");
        }
    }
?>