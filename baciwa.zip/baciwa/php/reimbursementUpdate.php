<?php
    require '../database.php';
 
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }
     
    if ( null==$id ) {
        header("Location: ../reimbursement.php");
    }
     
    if ( !empty($_POST)) {
        // keep track validation errors
        $nameError = null;
        $emailError = null;
        $mobileError = null;
         
        // keep track post values
		$rerdate = $_POST['date'];
        $rername = $_POST['name'];
        $reramount = $_POST['amt'];
        $rerpayment = $_POST['payment'];
        $rerremarks = $_POST['remark'];

        $rerpayname  = $_POST['payname'];
        $rerpayadd = $_POST['payadd'];
        $rerpayissue = $_POST['payissue'];
        $rerpaycedula = $_POST['paycedula'];
        $rerpaydateissue = $_POST['paydate'];

        $rerwitname  = $_POST['witname'];
        $rerwitadd = $_POST['witadd'];
        $rerwitissue = $_POST['witissue'];
        $rerwitcedula = $_POST['witcedula'];
        $rerwitdateissue = $_POST['witdate'];
         
        // validate input
        $valid = true;
         
        // update data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE reimbursement set rerid = ?, rername=?, reramount=?, rerpayment=?, rerremarks=?, rerpayname=?, rerpayadd=?, rerpayissue=?, rerpaycedula=?, rerpaydateissue=?, rerwitname=?, rerwitadd=?, rerwitissue=?, rerwitcedula=?, rerwitdateissue=? WHERE rerid = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($rerdate, $rername, $reramount, $rerpayment, $rerremarks, $rerpayname, $rerpayadd, $rerpayissue, $rerpaycedula, $rerpaydateissue, $rerwitname, $rerwitadd, $rerwitissue, $rerwitcedula, $rerwitdateissue, $id));
            Database::disconnect();
            header("Location: ../reimbursement.php");
        }
    }
?>