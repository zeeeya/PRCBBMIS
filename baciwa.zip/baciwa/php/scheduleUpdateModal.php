<?php 
	$id = $_POST['id'];

	if( !empty($id)){
		
		include('../database.php');
						
		//Getting the REGISTRATION ID from SCHEDULE Table
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT scheddate, schedtime, schedend FROM schedule WHERE schedid = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data = $q->fetch(PDO::FETCH_ASSOC);
		echo '<input type="hidden" class="form-control" value="'.$id.'" name="modalscheduleid">';
		echo '<div class="form-group"><label for="modalDate">Scheduled Date</label><input type="text" class="form-control" required="required" id="modalDate" name="modalSchedule" placeholder="Enter Date!" value="'.$data['scheddate'].'"></div>';
		echo '<div class="form-group"><label for="modalTimeStart">Time Start</label><input type="text" class="form-control" required="required" id="modalTimeStart" name="modalTimestart" placeholder="Time Start!" value="'.$data['schedtime'].'"></div>';
		echo '<div class="form-group"><label for="modalTimeEnd">Time End</label><input type="text" class="form-control" required="required" id="modalTimeEnd" name="modalTimeend" placeholder="Time End!" value="'.$data['schedend'].'"></div>';
	
	}else{
		echo 'No selected schedule';
	}
	
?>
