<?php
    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
		$date = $_POST['date'];
		$patch = $_POST['patch'];
		$number = $_POST['number'];
		$cause = $_POST['cause'];
		
        // validate input
        $valid = true;

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO witheredtrees (wtdate, wtpatch, wtnum, wtcause) values(?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($date, $patch, $number, $cause));
            Database::disconnect();
            header("Location: ../treeplanting.php");
        }
    }
?>