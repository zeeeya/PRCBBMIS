<?php

	require '../database.php';
	
	$id = $_POST['id'];			
	$patch = $_POST['p'];
	$treeqty = $_POST['treeqty'];
	
	foreach($id as $a => $b){
		//echo $id[$a].', '.$patch[$a].', '.$treeqty[$a].'<br/>';
		
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE participants SET treepatch = ?, treeqty = ? WHERE partid = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($patch[$a], $treeqty[$a], $id[$a]));
		Database::disconnect();			
		header("Location: ../patchsuccess.php");
		
	}
?>