<?php
    require '../database.php';
	
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
		if($_GET['status'] == 1)
			$status = 'Received';
		else if($_GET['status'] == 0)
			$status = 'Denied';
		else
			$status = 'For Approval';
		
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE liquidation SET liqstat = ? WHERE liqcode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($status, $id));
        Database::disconnect();
        header("Location: ../liquidation.php");		
		
    }else {
        header("Location: ../liquidation.php");
    }
     
?>