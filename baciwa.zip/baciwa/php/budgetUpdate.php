<?php
     
    require '../database.php';
	
	if(isset($_GET['id'])){
		$id = $_GET['id']; //budget code
		$tableData = stripcslashes($_POST['pTableData']); //item in the table
		$totalamount = $_POST['totalamount'];
		$status = 'Pending';
		$tableData = json_decode($tableData,TRUE);
		
		//delete budget item WHERE id == $id;
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM itembudget WHERE budcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		
		//insert the updated items in the table
		foreach($tableData as $item) { //foreach element in $arr
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO itembudget (itemname, itemquantity, itemunit, itemprice, budcode) values(?, ?, ?, ?, ?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($item['name'], $item['quantity'], $item['unit'], $item['price'], $id));
			Database::disconnect();
		}
		
		//update the status and total budget in the TABLE:Budget
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE budget SET budstat = ?, budamount = ? WHERE budcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($status, $totalamount, $id));
		Database::disconnect();
		
	}
	/*
	echo 'Budget Code: '.$budgetcode.'<br>';
	echo 'Subject of the budget: '.$subject.'<br>';
	echo 'Date Issue: '.$dateissue.'<br>';
	echo 'Registration Code: '.$regcode.'<br>';
	echo 'Total Amount: '.$totalamount.'<br>';
	echo 'Status: '.$status.'<br>';
	foreach($tableData as $item) { //foreach element in $arr
		echo $item['id'].', '.$item['name'].', '.$item['quantity'].', '.$item['unit'].', '.$item['price'].'<br>'; //etc
	}
	*/
	/*
    if ( !empty($_POST)) {

		$tableData = stripcslashes($_POST['pTableData']);
		date_default_timezone_set("Asia/Taipei");

		// Decode the JSON array
		$budgetcode = '01-'.date("mdYhis");
		
		$subject = $_POST['subject'];
		$dateissue = $_POST['dateissue'];
		$regcode = $_POST['regcode'];
		$totalamount = $_POST['totalamount'];
		$status = 'Pending';
		$tableData = json_decode($tableData,TRUE);

		//insert data to budget table
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "INSERT INTO budget (budcode, budsub, buddate, regid, budamount, budstat) values(?, ?, ?, ?, ?, ?)";
        $q = $pdo->prepare($sql);
        $q->execute(array($budgetcode, $subject, $dateissue, $regcode, $totalamount, $status));
        Database::disconnect();

		//insert each item to itembudget table
		foreach($tableData as $item) { //foreach element in $arr
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO itembudget (itemname, itemquantity, itemunit, itemprice, budcode) values(?, ?, ?, ?, ?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($item['name'], $item['quantity'], $item['unit'], $item['price'], $budgetcode));
			Database::disconnect();
		}

		//header("Location: ../view_budget.php");
        
    }
	*/
?>