<?php
     
    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
		$orgname = $_POST['orgname'];
		$orgtype = $_POST['orgtype'];
		$orgadd = $_POST['orgadd'];
		$orgcperson = $_POST['orgcperson'];
		$orgcnum = $_POST['orgcnum'];
				         
        // validate input
        $valid = true;

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO organization (orgname, orgtype, orgadd, orgcperson, orgcnum) values(?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($orgname, $orgtype, $orgadd, $orgcperson, $orgcnum));
            Database::disconnect();
            header("Location: ../new_registration.php");
        }
    }
?>