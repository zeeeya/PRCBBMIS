<?php 
	$id = $_POST['id'];

	if( !empty($id)){
		
		include('../database.php');
						
		//Getting the REGISTRATION ID from ITEM Table
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM item WHERE itemcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data = $q->fetch(PDO::FETCH_ASSOC);
		echo '<input type="hidden" class="form-control" value="'.$id.'" name="id">';
		echo '<div class="form-group">
				<label for="modalName">Item Name</label>
				<input type="text" class="form-control" required="required" id="modalName" name="name" placeholder="Enter Item" value="'.$data['itemname'].'">
			  </div>';
		echo '<div class="form-group">
				<label for="modalUnit">Unit</label>
				<input type="text" class="form-control" required="required" id="modalUnit" name="unit" placeholder="Enter Item Unit" value="'.$data['itemunit'].'">
			  </div>';
		echo '<div class="form-group">
				<label for="modalPrice">Price</label>
				<input type="text" class="form-control" required="required" id="modalPrice" name="price" placeholder="Enter Price" value="'.number_format((float)($data['itemprice']), 2, '.', '').'">
			  </div>';
	
	}else{
		echo 'No selected item';
	}
	
?>
