<?php
     
    require '../database.php';
	
	$registrationID = $_GET['id'];
	
	if( !empty($registrationID)){

		if ( !empty($_POST)) {

			// keep track post values
			$partname = $_POST['participantsname'];
			$partnum = $_POST['noofparticipants'];
			$schedid = $_POST['scheduleid'];
			$partstat = 'Pending';

			 echo $partname.'<br>';
			 echo $partnum.'<br>';
			 echo $schedid.'<br>';
			 
			// validate input
			$valid = true;
			
			// insert data
			if ($valid) {
				$pdo = Database::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "INSERT INTO participants (partname, partnum, schedid, partstat) values(?, ?, ?, ?)";
				$q = $pdo->prepare($sql);
				$q->execute(array($partname, $partnum, $schedid, $partstat));
				Database::disconnect();
				header("Location: ../view_schedule.php?id=".$registrationID);
			}else{
				header("Location: ../view_schedule.php?id=".$registrationID);
			}
		}else{
			header("Location: ../view_schedule.php?id=".$registrationID);
		}
	}
	
	echo $_GET['id'];
?>