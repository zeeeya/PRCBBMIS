	<?php
    require '../database.php';
	
    $id = $_POST['id'];
    echo $id.'<br>';
	
    
	if ( !empty($id)) {
	 
		// delete from budget table
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM budget WHERE budcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		
		// delete from budget table
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM itembudget WHERE budcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		
		//header("Location: ../view_budget.php");

    }else
		//header("Location: ../view_budget.php");

?>