<?php

    require '../database.php';
 
    if ( !empty($_POST)) {

		
        // keep track post values
		$markerid = $_POST['mapmark'];
		$orgid = $_POST['maporg'];
		$schedid = $_POST['mapsched'];
		$partnum = $_POST['partnum'];
		$treesnum = $_POST['trees'];
		
		//echo 'Activity: '.$regact."<br>";;
		//echo 'Organization ID: '.$orgid."<br>";;n 
		//echo 'Contact Person: '.$regcperson."<br>";;
		//echo 'Contact Number: '.$regcnum."<br>";;
		//echo 'Remarks: '.$regmemo."<br>";;
		//echo 'No. of Participants: '.$partnum."<br>";;
        // validate input
        $valid = true;
    
        // insert data
        //if ($valid) {
        //    $pdo = Database::connect();
        //    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       //     $sql = "INSERT INTO map_activity (mapid, markerid,orgid,schedid,partnum,treesnum) values(?, ?, ?, ?, ?, ?)";
        //    $q = $pdo->prepare($sql);
        //    $q->execute(array($mapid,$mapmark, $maporg,$mapsched,$partnum,$trees));
        //    Database::disconnect();
        //    header("Location: ../treeplanting.php");
        //}

        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO map_activity (markerid,orgid,schedid,partnum,treesnum) values(?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($markerid, $orgid,$schedid,$partnum,$treesnum));
            Database::disconnect();
            header("Location: ../treeplanting.php");
        }
    
	}
	
?>