<?php
     
    require '../database.php';
	
	$itemcode = $_POST['id'];
	$itemname = $_POST['name'];
	$itemunit = $_POST['unit'];
	$itemprice = $_POST['price'];
		
	//echo $itemcode.', '.$itemname.', '.$itemunit.', '.$itemprice;

    if ( !empty($itemcode)) {

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE item SET itemname = ?, itemunit = ?, itemprice = ? WHERE itemcode = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($itemname, $itemunit, $itemprice, $itemcode));
		Database::disconnect();
		header("Location: ../item.php");
        
    }else{
		header("Location: ../item.php");
	}
?>