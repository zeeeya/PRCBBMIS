<?php
     
    require '../database.php';

    if ( !empty($_POST)) {

		$tableData = stripcslashes($_POST['pTableData']);
		date_default_timezone_set("Asia/Taipei");

		// Decode the JSON array
		
		//liquidation code
		$liquidationcode = $_POST['liquidationcode'];
		//budget code
		$budgetcode = $_POST['budgetcode'];
		//date
		$date = date("m/d/Y").'';
		//total liquidation
		$ltotal = $_POST['liquidationTotal'];
		//total money spent
		$total = $_POST['total'];
		$subject = $_POST['subject'];
		
		//echo $liquidationcode.', '.$budgetcode.', '.$date.', '.$ltotal.', '.$total.'<br />';
		//1. update the liquidation record
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE liquidation set liqdate = ?, liqamnt = ?, liqtotal = ?, liqsub = ? WHERE liqcode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($date, $ltotal, $total, $subject, $liquidationcode));
        Database::disconnect();
		
		//2. delete liquidated items and replace new
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM liquidationitem WHERE liqcode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($liquidationcode));
        Database::disconnect();
		
		//3. save liquidation items
		$tableData = json_decode($tableData,TRUE);
		
		foreach($tableData as $item) { //foreach element in $arr
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO liquidationitem (liqitmor, liqitmname, liqitmprc, liqcode) values(?, ?, ?, ?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($item['or_number'], $item['name'], $item['price'], $liquidationcode));
			Database::disconnect();
		}
		
		echo '<div class="alert alert-success" role="alert" style="margin-bottom:0px;"><span class="glyphicon glyphicon-ok" aria-hidden="true" style="margin-right:10px"></span>Budget Liquidation Updated.</div><br />';
    }
	
	
?>