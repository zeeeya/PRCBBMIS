<?php
     
    require '../database.php';
 
    if ( !empty($_POST)) {

        // keep track post values
		$id = $_GET['id'];
		$partname = $_POST['participantsname'];
		$partnum = $_POST['noofparticipants'];
		$schedid = $_POST['scheduleid'];
		$registrationid = $_POST['registrationid'];

        // validate input
        $valid = true;
		
		//echo 'ID:'.$id.', Participants:'.$partname.', No. of Partipants:'.$partnum.', Schedule ID:'.$schedid.', Registration ID:'.$registrationid;
		
        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE participants SET partname = ?, partnum = ?, schedid = ? WHERE partid = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($partname, $partnum, $schedid, $id));
            Database::disconnect();
            header("Location: ../view_schedule.php?id=".$registrationid);
        }
    }
?>