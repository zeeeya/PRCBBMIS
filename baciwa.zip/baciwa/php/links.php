<?php

$Home = './home.php';
$Registration = './registration.php';
$Budget = './view_budget.php';
$Liquidation = './liquidation.php';
$Miscellaneous = '#';
$Report = 'reports.php';
$Signup = '#';
$Logout = './php/logout.php';

?>