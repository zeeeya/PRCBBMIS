
<?php
    require 'database.php';
    $id = $_POST['delid'];
	
    if ( !empty($id)) {
		echo $id;
		$pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM liquidation WHERE liqcode LIKE ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($id));
        Database::disconnect();
		header("Location: ./liquidation.php");
    }else{
		header("Location: ./liquidation.php");
	}
    
?>
