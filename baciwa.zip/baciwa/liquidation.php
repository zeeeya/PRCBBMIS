<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Planting Activity Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="./css/custom_style.css">

</head>
<body>
<?php include('header.php'); //nav bar and header?> 

<!-- PAGE TITLE -->
<div class="container-fluid page_title_container">
	<div>
		<h1>Liquidation</h1>
	</div>
</div>

	<div class="container-fluid main-wrapper">
		<div class="col-lg-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="view_liquidation.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Create Liquidation</a>
				<a href="liquidation.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp;View Liquidation</a>
			</div>
		</div>

				<div class="col-lg-9 main-content">
					<h2>Liquidation List</h2>
					<hr />
					<br />
					
						<div class='container-fluid'>
							<div class='row'>
								<div class='col-md-12'>
									<!-- make this a function -->
									<?php
									function viewLiquidationByStatus($status){
										include 'database.php';
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = 'SELECT * FROM liquidation INNER JOIN budget ON liquidation.budcode = budget.budcode WHERE budstat = "Done" AND liqstat = "'.$status.'"';
										echo '<table class="table table-striped">';
										echo '<thead>
												<tr>
													<th>Liquidation Code</th>
													<th>Subject for the Budget</th>
													<th>Status</th>
													<th>Action</th>
												</tr>
											  </thead>';
										foreach ($pdo->query($sql) as $row) {
											echo '<tbody>
													<tr>';
													echo '<td>'.$row['liqcode'].'</td>';
													echo '<td>'.$row['budsub'].'</td>';
													echo '<td>'.$row['liqstat'].'</td>';
													echo '<td>';
													if($row['liqstat'] === 'For Approval'){
														echo	'<a class="btn btn-primary btn-md" href="liquidation_update.php?id='.$row['liqcode'].'" data-toggle="tooltip" title="Update the liquidation for this activity"><span class="glyphicon glyphicon-edit" style="margin-right:10px"></span><strong>Edit</strong></a>
																<a class="btn btn-warning btn-md" href="liquidationViewApproval.php?id='.$row['liqcode'].'" data-toggle="tooltip" title="View/Update Budget Proposal"><span class="glyphicon glyphicon-folder-open" style="margin-right:10px"></span><strong>View</strong></a>
																<button type="button" class="btn btn-danger btn-md delB" rel="tooltip" title="Delete Liquidation" data-toggle="modal" data-target="#myModal" value="'.$row['liqcode'].'"><span class="glyphicon glyphicon-trash"></span></button>';
													}else{
														echo '<a class="btn btn-warning btn-md" href="liquidationViewApproval.php?id='.$row['liqcode'].'" data-toggle="tooltip" title="View/Update Budget Proposal"><span class="glyphicon glyphicon-folder-open" style="margin-right:10px"></span><strong>View</strong></a>';	
													}
													echo '</td>';											  
											echo 	'</tr>';
											echo '</tbody>';
										}
										echo '</table>';
										Database::disconnect();
									}
									?>
									
								<!-- tab pane -->	
								<ul class="nav nav-tabs">
								  <li class="active"><a data-toggle="tab" href="#home">For Approval</a></li>
								  <li><a data-toggle="tab" href="#menu1">Received</a></li>
									<?php if($_SESSION['login_username'] !== 'manager'){ ?>
										<li><a data-toggle="tab" href="#menu2">Denied</a></li>
									<?php } ?>
								</ul>

								<div class="tab-content">
								  <div id="home" class="tab-pane fade in active">
									<br />
									<?php viewLiquidationByStatus('For Approval')?>
								  </div>
								  <div id="menu1" class="tab-pane fade">
									<br />
									<?php viewLiquidationByStatus('Received')?>
								  </div>
								  <div id="menu2" class="tab-pane fade">
									<br />
									<?php viewLiquidationByStatus('Denied')?>
								  </div>
								</div>
								<script>
									$(document).ready(function(){
										$('[data-toggle="tooltip"]').tooltip(); 
										$('.btn').tooltip();
									});
								</script>
								</div>
							</div>
						</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document" >
    <div class="modal-content" style="margin-top:10%;">
      <div class="modal-header btn-danger">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Delete Liquidation</h4>
      </div>
	  
	  <form class="form-horizontal" action="liquidation_delete.php" method="post">
      
	  <div class="modal-body content">
		<input type="hidden" name="delid" id="deleteTextField" value="<?php echo $id;?>"/>
		<div class="alert alert-danger" role="alert">Are you sure you want to remove this liquidation from the system?</div>
      </div>
	  
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
	  
	  </form>
    </div>
  </div>
</div>

	
<script>
$(document).ready(function(){
	$('.delB').click(function(){
		var value = $( this ).val();
		console.log(value);
		$('#deleteTextField').val(value);
	}); 
});
</script>	
	
<?php include('./footer.php'); ?>
</body>
</html>