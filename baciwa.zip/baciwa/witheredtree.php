<?php 
include('php/login_success.php'); 
include('php/links.php');
include('database.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/leaflet.markercluster.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css' rel='stylesheet' />
		<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css' rel='stylesheet' />

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
		<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
		<link href='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.css' rel='stylesheet' />
		<style>
			#map 
			{ 	margin:3% 3%;
				width:95%; 
				height:70%; 
			}
		</style>


	 </head>
	<body>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		<!-- <div style="margin-left:350px" id='map'></div> -->
	
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredtree.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			
			</div>

		</div>
		
		<div class="col-md-9">
			<br />

			<div class="col-md-12">
				<h4><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp;Assign Patch</h4>
				<hr/>
			</div>
			
			<div class="col-md-12">
				<div class="panel panel-primary">
				  <div class="panel-heading">
					<h3 class="panel-title">Monitor Withered Trees</h3>
				  </div>
				  <div class="panel-body">
						<form class="form-horizontal" role="form" action="php/witheredsave.php" method="POST">
						  <div class="form-group">
							<label class="control-label col-sm-3" for="date">Date:</label>
							<div class="col-sm-9">
							  <input type="date" class="form-control" id="date" name="date" placeholder="Enter Date" required="required">
							</div>
						  </div>
						  
							<!-- Activity Code -->
							<div class="form-group row">
								<div class="col-xs-3 text-right"><label for="patch">Patch No.:</label></div>
								<div class="col-xs-9">
									<select class="form-control" required="required" id="patch" name="patch" required="required">
										<option value="Patch_01" selected >Patch_01</option>';
										<option value="Patch_02"  >Patch_02</option>';
										<option value="Patch_03"  >Patch_03</option>';
										<option value="Patch_04"  >Patch_04</option>';
										<option value="Patch_05"  >Patch_05</option>';
										<option value="Patch_06"  >Patch_06</option>';
										<option value="Patch_07"  >Patch_07</option>';
										<option value="Patch_08"  >Patch_08</option>';
										<option value="Patch_09"  >Patch_09</option>';
										<option value="Patch_10"  >Patch_10</option>';
										<option value="Patch_11"  >Patch_11</option>';
										<option value="Patch_12"  >Patch_12</option>';
										<option value="Patch_13"  >Patch_13</option>';
										<option value="Patch_14"  >Patch_14</option>';
										<option value="Patch_15"  >Patch_15</option>';
									</select>
								</div>
							</div>

							<div class="form-group">
								<label class="control-label col-sm-3" for="number">No. of Withered Trees:</label>
								<div class="col-sm-9">
								<input type="text" class="form-control" id="number" name="number" placeholder="No. of Withered trees" required="required">
								</div>
							</div>
							
							<div class="form-group">
								<label class="control-label col-sm-3" for="cause">Cause of death</label>
								<div class="col-sm-9">
								<input type="text" class="form-control" id="cause" name="cause" placeholder="Cause of death" required="required">
								</div>
							</div>						
							
							<div class="form-group">
								<div class="col-sm-offset-3 col-sm-9">
									<button type="submit" class="btn btn-info">Submit</button>
								</div>
							</div>
						</form>			  
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include('footer.php'); 
?>

</body>
</html>