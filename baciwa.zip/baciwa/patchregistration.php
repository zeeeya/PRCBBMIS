<?php 
include('php/login_success.php'); 
include('php/links.php');
?>

<html lang="en">
<head>
	<title>Planting Activity Management System</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	  
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

		<link rel="stylesheet" href="./css/custom_style.css">
		
		<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />

</head>
<body>
	<?php require 'database.php'; ?>
	<?php include('header.php'); //nav bar and header?> 
	
	<div class="container-fluid">
	
		
		
		<div class="col-md-3">
			<!-- side bar -->
			<div class="list-group side_bar">
				<a href="treeplanting.php" class="list-group-item"><span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>&nbsp;&nbsp;Tree Planting Map</a>
				<a href="mangroveplanting.php" class="list-group-item"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span>&nbsp;&nbsp; Mangrove Planting Map</a>
				<a href="patchregistration.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp; Assign Patch to Organization</a>
				<a href="witheredtree.php" class="list-group-item"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>&nbsp;&nbsp; Log Withered Trees</a>
			</div>
		</div>
	
		<div class="col-md-9">
			<br/>
			<div class="col-md-12">
				<h4><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;&nbsp;Assign Patch</h4>
				<hr/>
			</div>
			<div class="col-md-12">
				<form method="POST" action="php/updatepatch.php">
					<!-- Panel for Activity Details -->
					<div class="panel panel-primary">
						<div class="panel-heading">Activity Details</div>
						<div class="panel-body">
							<label for="registrationcode">Please choose the desired activity code to process: </label>
							<select class="form-control" id= "registrationcode" name="registration_code">
								<option value="" selected disabled>-- Select Activity Code --</option>';
									<?php
										$pdo = Database::connect();
										$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
										$sql = "SELECT * FROM registration INNER JOIN organization ON registration.orgid = organization.orgid ";
											foreach ($pdo->query($sql) as $row){
													$option = $row['regid'].': ' .$row['orgname'].': ' .$row['regact'];
													echo '<option value="'.$row['regid'].'">'.$option.'</option>';
											}
													
										Database::disconnect();
									?>
							</select>
							<div class="col-md-12" id="activity_container">
								
							</div>
							
							<script>
								$(document).ready(function(){
									$('#registrationcode').change(function(){
										
										var d = "id="+$( "#registrationcode" ).val();
										console.log(d);
										$.ajax({
											url   : 'patchregistrationdetails.php',
											data  : d,
											type : 'POST',
											success : function(data){
												$('#activity_container').html(data);
												document.getElementById("myBtn").disabled = false;
											}
										})
									})
								})
							</script>
						</div>
					</div>
				
					<div class="col-md-12 text-center">
						<button type="submit" class="btn btn-primary" id="myBtn" disabled>&nbsp;Save Changes&nbsp;</button>
					</div>
				
				</div>

				</form>
		</div>
	</div>

<?php
include('footer.php'); 
?>
</body>
</html>