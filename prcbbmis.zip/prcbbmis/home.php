<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="./css/custom_style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.theme.mis.css">
</head>
<body>

<?php 
	
	include('header.php');
	include ('footer.php');

?>

</body>
</html>